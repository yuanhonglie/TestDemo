package com.cybertron.hanzitrace.utils;

public class SearchItem {
	
	public int grade;
	
	public int order;
	
	public String ch;
	
	public SearchItem(int g,int o,String c){
		this.grade = g;
		this.order = o;
		this.ch = c;
	}
	
	@Override
	public String toString() {
		return ch+"|"+grade+","+order;
	}
}
