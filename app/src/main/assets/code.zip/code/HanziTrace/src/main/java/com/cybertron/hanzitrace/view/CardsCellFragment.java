package com.cybertron.hanzitrace.view;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.SimpleAdapter;

import com.cybertron.hanzitrace.R;

/**
 * 装载单词列表的fragment
 * 
 * @author Administrator
 * 
 */
public class CardsCellFragment extends Fragment {

	private GridView mGridView;

	private ArrayList<String> hanziData;		// 单词数据

	private int numColumns;		// 单行显示个数
	
	private int grade;		// 年级
	
	private int group;		// 组
	
	private int page; 		// 页

	private OnCardsCellItemClickListener mCardsCellItemClickListener;

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mCardsCellItemClickListener = (OnCardsCellItemClickListener) activity;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Bundle bundle = getArguments();
		if (bundle != null) {
			hanziData = bundle.getStringArrayList("hanziData");
			numColumns = bundle.getInt("numColumns");
			grade = bundle.getInt("grade");
			group = bundle.getInt("group");
			page = bundle.getInt("page");
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View root = inflater.inflate(R.layout.cards_cell, container, false);
		init(root);
		return root;
	}

	private void init(View root) {
		mGridView = (GridView) root.findViewById(R.id.cells_gv);
		mGridView.setSelector(new ColorDrawable(Color.TRANSPARENT));
		mGridView.setNumColumns(numColumns);
		if (hanziData != null && hanziData.size() > 0) {
			ArrayList<HashMap<String, String>> hanziMapsData = new ArrayList<HashMap<String, String>>();
			for (int i = 0; i < hanziData.size(); i++) {
				HashMap<String, String> maps = new HashMap<String, String>();
				maps.put("hanzi", hanziData.get(i));
				hanziMapsData.add(maps);
			}

			SimpleAdapter mAdapter = new SimpleAdapter(this.getActivity(),
					hanziMapsData, R.layout.cards_cell_item,
					new String[] { "hanzi" }, new int[] { R.id.cells_gv_item });
			mGridView.setAdapter(mAdapter);
			mGridView.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					String hanzi = hanziData.get(position);
					if (mCardsCellItemClickListener != null) {
						mCardsCellItemClickListener.onCellItemClick(grade,group,page,position,hanzi);
					}
				}
			});
		}
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onStart() {
		super.onStart();
	}

	@Override
	public void onResume() {
		super.onResume();
	}

	@Override
	public void onPause() {
		super.onPause();
	}

	@Override
	public void onStop() {
		super.onStop();
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	@Override
	public void onDetach() {
		super.onDetach();
	}

	public interface OnCardsCellItemClickListener {
		public void onCellItemClick(int grade, int group, int page, int position, String ch);
	}

}
