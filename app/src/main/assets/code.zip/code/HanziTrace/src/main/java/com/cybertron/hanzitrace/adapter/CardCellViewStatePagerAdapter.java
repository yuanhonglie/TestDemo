package com.cybertron.hanzitrace.adapter;

import java.util.ArrayList;
import java.util.List;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.Log;
import android.view.ViewGroup;

import com.cybertron.account.book.Book;
import com.cybertron.hanzitrace.GroupItem;
import com.cybertron.hanzitrace.view.HanziStudyFragment;

public class CardCellViewStatePagerAdapter extends FragmentStatePagerAdapter{
	private static final String TAG = "CardCellViewPagerAdapter";
	private ArrayList<GroupItem> mGroupItems;
	
	private List<Book> mBooks;
	
	private String mPhrasePath;
	
	public CardCellViewStatePagerAdapter(FragmentManager fm, ArrayList<GroupItem> groupItemList, List<Book> mDictBooks, String phrasepath) {
		super(fm);
		mGroupItems = groupItemList;
		mBooks = mDictBooks;
		mPhrasePath = phrasepath;
	}

	@Override
	public Fragment getItem(int position) {
		GroupItem groupItem = mGroupItems.get(position);
		Fragment mStudydFragment = HanziStudyFragment.newInstance(groupItem,mBooks,mPhrasePath);
		return mStudydFragment;
	}

	@Override
	public Object instantiateItem(ViewGroup arg0, int position) {
		return super.instantiateItem(arg0, position);
	}
	
	@Override
	public int getCount() {
		return mGroupItems.size();
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		super.destroyItem(container, position, object);
		Log.i(TAG, "destroyItem: position = " + position);
	}
	

}
