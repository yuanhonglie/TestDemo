package com.cybertron.hanzitrace.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cybertron.hanzitrace.GroupItem;
import com.cybertron.hanzitrace.R;
import com.cybertron.hanzitrace.parse.HZFlashParser;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersGridView;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersSimpleAdapter;

public class StickyGridAdapter extends BaseAdapter implements StickyGridHeadersSimpleAdapter {

	private List<GroupItem> list;		// 所有小组分组后汉字的集合
	
	private LayoutInflater mInflater;
	
	private Typeface mTypeface;
	
	private StickyGridHeadersGridView mGridView;
	
	private int selectposition = -1;
	
	private Context mContext;
	
	public StickyGridAdapter(Context context, List<GroupItem> list, StickyGridHeadersGridView gridview, String ttflocalpath) {
		this.list = list;
		this.mContext = context;
		this.mGridView = gridview;
		mInflater = LayoutInflater.from(context);
		mTypeface = Typeface.createFromFile(ttflocalpath);
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder mViewHolder;
		if (convertView == null) {
			mViewHolder = new ViewHolder();
			convertView = mInflater.inflate(R.layout.cards_cell_item, null);
			mViewHolder.mTextView = (TextView) convertView.findViewById(R.id.cells_gv_item);
			mViewHolder.mImageViewFlag = (ImageView) convertView.findViewById(R.id.cells_gv_item_flag);
			convertView.setTag(mViewHolder);
		} else {
			mViewHolder = (ViewHolder) convertView.getTag();
		}
		mViewHolder.mTextView.setTypeface(mTypeface);
		mViewHolder.mTextView.setText(list.get(position).getHanzi());
		
		try {
			boolean isexistflash = HZFlashParser.getInstance().isExistFlash(list.get(position).getHanzi());
			if(isexistflash){
				mViewHolder.mImageViewFlag.setVisibility(View.VISIBLE);
			}else{
				mViewHolder.mImageViewFlag.setVisibility(View.GONE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(position == selectposition){
			mViewHolder.mTextView.setPressed(true);
		}else{
			mViewHolder.mTextView.setPressed(false);
		}
		return convertView;
	}
	

	@Override
	public View getHeaderView(int position, View convertView, ViewGroup parent) {
		HeaderViewHolder mHeaderHolder;
		if (convertView == null) {
			mHeaderHolder = new HeaderViewHolder();
			convertView = mInflater.inflate(R.layout.header, parent, false);
			mHeaderHolder.mTextView = (TextView) convertView.findViewById(R.id.header);
			convertView.setTag(mHeaderHolder);
		} else {
			mHeaderHolder = (HeaderViewHolder) convertView.getTag();
		}

		int group = list.get(position).getGroup();
		
		String sAgeFormat = mContext.getResources().getString(R.string.hanzi_group); 
		mHeaderHolder.mTextView.setText(String.format(sAgeFormat, (group + 1)));
		
		if(mGridView.getStickiedHeader() == convertView && headerListener != null){
			headerListener.onPerformHeader(convertView,group);
		}
		return convertView;
	}

	public static class ViewHolder {
		public TextView mTextView;
		public ImageView mImageViewFlag;
	}

	public static class HeaderViewHolder {
		public TextView mTextView;
	}

	@Override
	public long getHeaderId(int position) {
		return list.get(position).getGroup();
	}

	public void setGroupItems(List<GroupItem> mGroupItems) {
		list = mGroupItems;
		notifyDataSetChanged();
	}
	
	private onPerformHeaderListener headerListener;
	
	public void setOnPerformHeaderListener(onPerformHeaderListener listener){
		headerListener = listener;
	}
	
	public interface onPerformHeaderListener{
		public void onPerformHeader(View view,int group);
	}
	
	/**
	 *	设置item选中的位置 
	 * @param position
	 */
	public void setSelectPosition(int position) {
		selectposition = position;
		notifyDataSetChanged();
	}
	


}
