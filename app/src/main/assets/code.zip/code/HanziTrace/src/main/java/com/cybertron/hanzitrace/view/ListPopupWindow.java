package com.cybertron.hanzitrace.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.cybertron.hanzitrace.R;

/**
 * 年级分组浮窗
 * @author Administrator
 *
 */
public class ListPopupWindow extends PopupWindow {

	private ListView mListView;

	private Context mContext;

	private View view;

	private String[] data;
	
	private int curGroup;
	
	private int listW, listH, itemH;
	
	public ListPopupWindow(Context context){
		super(context);
	}
	
	@SuppressWarnings("deprecation")
	public ListPopupWindow(Context context, String[] gradedata, int group) {
		LayoutInflater inflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		view = inflate.inflate(R.layout.select_list_pop, null);
		this.data = gradedata;
		this.mContext = context;
		this.curGroup = group;
		
		Resources r = context.getResources();
		listW = (int) r.getDimension(R.dimen.hz_title_bar_grade_width);
		listH = (int) r.getDimension(R.dimen.hz_title_bar_list_height);
		itemH = (listH-9)/6;
		
		this.setWidth(listW);
		this.setHeight(listH);
		this.setContentView(view);
		this.setFocusable(true);
		this.setBackgroundDrawable(new BitmapDrawable());
		this.setOutsideTouchable(true);
		setPopupContentView(view);
	}

	class ListAdapter extends BaseAdapter{

		@Override
		public int getCount() {
			return data.length;
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if(convertView == null){
				holder = new ViewHolder();
				LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = layoutInflater.inflate(R.layout.select_list_pop_item, null);
				convertView.setMinimumHeight(itemH);
				holder.mTitle = (TextView) convertView.findViewById(R.id.select_list_item);
				convertView.setTag(holder);
			}else{
				holder = (ViewHolder) convertView.getTag();
			}
			holder.mTitle.setText(data[position]);
			return convertView;
		}
	}
	
	public static class ViewHolder{
		public TextView mTitle;
	}
	

	private onListItemClickListener mClickListener;
	
	public void setListItemClickListener(onListItemClickListener listener){
		mClickListener = listener;
	}
	
	public interface onListItemClickListener{
		public void onListItemClick(AdapterView<?> parent, View view,int position, long id);
	}

	public void setPopupContentView(View v) {
		mListView = (ListView) v.findViewById(R.id.select_list);	
		mListView.setAdapter(new ListAdapter());
		mListView.setSelection(curGroup);
		mListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
				mClickListener.onListItemClick(parent, view, position, id);
			}
		});
	}
	
}
