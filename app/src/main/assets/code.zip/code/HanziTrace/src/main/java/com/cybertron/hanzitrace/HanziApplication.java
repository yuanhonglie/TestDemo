package com.cybertron.hanzitrace;

import android.app.Application;

public class HanziApplication extends Application {
	@Override
	public void onCreate() {
		super.onCreate();
	}
}
