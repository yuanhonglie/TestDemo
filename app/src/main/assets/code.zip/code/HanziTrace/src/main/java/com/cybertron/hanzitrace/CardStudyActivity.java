package com.cybertron.hanzitrace;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cybertron.account.book.Book;
import com.cybertron.account.util.FileUtils;
import com.cybertron.account.util.ListUtils;
import com.cybertron.account.util.StorageUtils;
import com.cybertron.hanzitrace.adapter.CardCellViewStatePagerAdapter;
import com.cybertron.hanzitrace.parse.HZFlashParser;
import com.cybertron.hanzitrace.view.HorizontalListView;
import com.cybertron.hanzitrace.view.SpringbackViewPager;

public class CardStudyActivity extends FragmentActivity implements OnItemClickListener{
	
	private ArrayList<GroupItem> GroupItemList;		// 当前小组汉字的集合
	
	private GroupItem mCurGroupItem;		// 当前汉字
	
	/** 当前汉字在组内的位置下标(所在页的起始下标 + 在页中具体的位置)**/
	private int curGroupIndex ;
	
	/** 组内汉字总数**/
	private int totalGroupCells; 
	
	private HorizontalListView mHorizontalListView; 
	
	private CharListAdapter mCharListAdapter;

	private SpringbackViewPager springbackViewPager;
	
	private List<Book> mDictBooks;
	
	private String mTtfPath,mPhrasePath;
	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cards_study);
		if(getIntent() != null){
			Bundle bundle = getIntent().getExtras();
			mCurGroupItem = (GroupItem) bundle.getSerializable("curgroupitem");
			GroupItemList = (ArrayList<GroupItem>) bundle.getSerializable("groupitemlist");
			
			curGroupIndex = mCurGroupItem.getGroupIndex();
			totalGroupCells = GroupItemList.size();
			
			mDictBooks = bundle.getParcelableArrayList("dictbook");
			mTtfPath = bundle.getString("ttfpath");
			mPhrasePath = bundle.getString("phrasepath");
		}
		
		springbackViewPager = (SpringbackViewPager) findViewById(R.id.card_study_viewpager);
		
		mHorizontalListView = (HorizontalListView) findViewById(R.id.cardcell_study_listview);
		mHorizontalListView.setOnItemClickListener(this);
		
		mCharListAdapter = new CharListAdapter(this);
		mHorizontalListView.setAdapter(mCharListAdapter);
		
		springbackViewPager.setFocusable(true);
		springbackViewPager.setOnPageChangeListener(mPageChangeListener);
		
		CardCellViewStatePagerAdapter pagerAdapter = new CardCellViewStatePagerAdapter(getSupportFragmentManager(),GroupItemList,mDictBooks,mPhrasePath);
		springbackViewPager.setAdapter(pagerAdapter);
		springbackViewPager.setViewPagerCount(totalGroupCells);
		springbackViewPager.setCurrentPageIndex(curGroupIndex);
		springbackViewPager.setCurrentItem(curGroupIndex);
		
		if(!StorageUtils.IsDiskSpaceAvailable()){		//磁盘空间已满
			Toast.makeText(this, getResources().getString(R.string.alert_out_of_space), Toast.LENGTH_SHORT).show();
		}
	}
	
	OnPageChangeListener mPageChangeListener = new OnPageChangeListener() {

		@Override
		public void onPageScrollStateChanged(int arg0) {

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		@Override
		public void onPageSelected(int position) {
			springbackViewPager.setCurrentPageIndex(position);
			selectCharByIndex(position, true);
		}
	};

	protected void selectCharByIndex(int index) {
		selectCharByIndex(index, true);
	}

	private void selectCharByIndex(int index, boolean scrollToItem) {
		if (scrollToItem) {
			mHorizontalListView.setSelection(index);
		}
		mCharListAdapter.highlight(index);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			exitApp();
			return false;
		}
		return false;
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	protected void exitApp() {
		finish();
		overridePendingTransition(R.anim.popup_enter, R.anim.popup_exit);
	}
	
	public class CharListAdapter extends BaseAdapter {
		private int mSelection = -1;
		private Context mContext;
		private Typeface mTypeface;
		
		public CharListAdapter(Context ctx) {
			mContext = ctx;
			if (!TextUtils.isEmpty(mTtfPath) && FileUtils.exists(mTtfPath)) {
				mTypeface = Typeface.createFromFile(mTtfPath);
			}
		}

		public void setSelection(int selection) {
			mSelection = selection;
		}
		
		public int getSelection() {
			return mSelection;
		}
		
		public void highlight(int selection) {
			highlight(selection, true);
		}
		
		public void highlight(int selection, boolean update) {
			setSelection(selection);
			if (update) {
				notifyDataSetChanged();
			}
		}
		
		public void clearHighlight() {
			highlight(-1);
		}
		
		public boolean haveHighlight() {
			return mSelection != -1;
		}
		
		@Override
		public int getCount() {
			return ListUtils.isEmpty(GroupItemList) ? 0 : GroupItemList.size();
		}

		@Override
		public GroupItem getItem(int position) {
			return ListUtils.isEmpty(GroupItemList) ? null : GroupItemList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder mViewHolder;
			if (convertView == null) {
				mViewHolder = new ViewHolder();
				convertView = LayoutInflater.from(mContext).inflate(R.layout.simple_char_cell_item, null);
				mViewHolder.mCharacter = (TextView) convertView.findViewById(R.id.gv_item_char);
				mViewHolder.mFlashFlag = (ImageView) convertView.findViewById(R.id.gv_item_flag);
				mViewHolder.mCharacter.setTypeface(mTypeface);
				convertView.setTag(mViewHolder);
			} else {
				mViewHolder = (ViewHolder) convertView.getTag();
			}
			
			mViewHolder.mCharacter.setText(GroupItemList.get(position).getHanzi());
			
			try {
				boolean isexistflash = HZFlashParser.getInstance().isExistFlash(GroupItemList.get(position).getHanzi());
				if(isexistflash){
					mViewHolder.mFlashFlag.setVisibility(View.VISIBLE);
				}else{
					mViewHolder.mFlashFlag.setVisibility(View.GONE);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			if(position == mSelection){
				mViewHolder.mCharacter.setSelected(true);
			}else{
				mViewHolder.mCharacter.setSelected(false);
			}
			return convertView;
		}
		
		class ViewHolder {
			public TextView mCharacter;
			public ImageView mFlashFlag;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		ItemClick(position);
	}

	private void ItemClick(int position) {
		springbackViewPager.setCurrentPageIndex(position);
		springbackViewPager.setCurrentItem(position);		
	}
	
}
