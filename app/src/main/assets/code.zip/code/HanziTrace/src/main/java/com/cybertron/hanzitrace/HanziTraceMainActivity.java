package com.cybertron.hanzitrace;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.util.EncodingUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.cybertron.account.CyberConst;
import com.cybertron.account.book.Book;
import com.cybertron.account.book.BookUtils;
import com.cybertron.account.datacheck.DataCheckUtil;
import com.cybertron.account.receiver.DataCheckReceiver;
import com.cybertron.account.receiver.DataCheckReceiver.DataCheckReceiverListener;
import com.cybertron.account.util.ActivityUtil;
import com.cybertron.account.util.ListUtils;
import com.cybertron.account.util.StorageUtils;
import com.cybertron.api.CybConfig;
import com.cybertron.api.CybHelper;
import com.cybertron.dicts.util.DictDBHelper;
import com.cybertron.hanzitrace.adapter.StickyGridAdapter;
import com.cybertron.hanzitrace.adapter.StickyGridAdapter.onPerformHeaderListener;
import com.cybertron.hanzitrace.parse.Char;
import com.cybertron.hanzitrace.parse.HZDataParser;
import com.cybertron.hanzitrace.parse.HanZiHelper;
import com.cybertron.hanzitrace.parse.newdb.HZDataParserDb;
import com.cybertron.hanzitrace.utils.SearchItem;
import com.cybertron.hanzitrace.utils.StaticFinalUtil;
import com.cybertron.hanzitrace.view.EditTextWithDel;
import com.cybertron.hanzitrace.view.HanziStudyFragment;
import com.cybertron.hanzitrace.view.ListPopupWindow;
import com.cybertron.hanzitrace.view.ListPopupWindow.onListItemClickListener;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersGridView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class HanziTraceMainActivity extends FragmentActivity
		implements View.OnClickListener, OnItemClickListener, onPerformHeaderListener {

	private String[] gradedata; // 默认年级数据

	private String[] groupdata; // 汉字按每页 N 个分组数据

	private int mCurrentGroup = 0; // 当前小组

	private int mGrade = 0; // 年级

	private HZDataParser mDataParser;

	private EditTextWithDel mTextWithDel; // 输入框

	private TextView gradeView, groupView, searchView;

	private ListPopupWindow mGradeListPopupWindow; // 年级选择浮窗

	private ListPopupWindow mGroupListPopupWindow; // 分组选择浮窗

	private StickyGridHeadersGridView mGridView;

	private StickyGridAdapter mStickyGridAdapter;

	private List<GroupItem> mGroupItemsList; // 年级所有汉字集合封装数据

	private String gradechars;// 年级所有汉字集合原始数据

	private CybHelper mCybHelper;

	private String mUserName;

	private String mUserId;

	private DataCheckUtil mDataCheckUtil;

	private InputMethodManager imm;

	private List<Book> mDictBooks;

	private String ttflocalpath;

	private Book phraseBk;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.handzi_trace_main);

		if (!login()) {
			finish();
			return;
		}

		checkData();

		if (mDataParser == null) {
			finish();
			return;
		}
		gradedata = getResources().getStringArray(R.array.grades);

		int searchRecultOrder = -1;
		if (this.getIntent() != null) {
			 String searchHz = this.getIntent().getStringExtra("ai_hanzi");
			if (!TextUtils.isEmpty(searchHz)) {
				SearchItem result = searchWord(searchHz);
				if (result == null) {
					showToast(R.string.search_without_word);
					finish();
					return;
				}
				findViewById(R.id.root_parent).setVisibility(View.GONE);
				openHanziFragment(result);
				return;
			} else {
				initCardsCellFragmentsData(0);
			}
		}

		if (mGroupItemsList != null) {
			initBar();
			mGridView.setSelector(new ColorDrawable(Color.TRANSPARENT));
			mGridView.setNumColumns(StaticFinalUtil.numColumns);
			mGridView.setOnItemClickListener(HanziTraceMainActivity.this);
			mStickyGridAdapter = new StickyGridAdapter(HanziTraceMainActivity.this, mGroupItemsList, mGridView,
					ttflocalpath);
			mStickyGridAdapter.setOnPerformHeaderListener(HanziTraceMainActivity.this);
			mGridView.setAdapter(mStickyGridAdapter);
			if (searchRecultOrder != -1) {
				scrollToGroupPosition(searchItemGroupPosition);
				mStickyGridAdapter.setSelectPosition(searchRecultOrder);
			}
		} else {
			finish();
		}

		imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		getServerBookCheck(mDataCheckUtil.getAppDatas());
		if (!StorageUtils.IsDiskSpaceAvailable()) { // 磁盘空间已满
			Toast.makeText(this, getResources().getString(R.string.alert_out_of_space), Toast.LENGTH_SHORT).show();
		}
	}

	private void openHanziFragment(SearchItem result) {
		Intent intent = this.getIntent();
		if (intent != null) {
			Bundle bundle = intent.getExtras();
			bundle.putParcelableArrayList("dictbooks", (ArrayList<? extends Parcelable>) mDictBooks);
			bundle.putParcelable("charphrasebook", phraseBk);
			bundle.putString("copyValue", result.ch);
			if (mDataParser != null) {
				List<Char> chars = mDataParser.getChars(result.ch.charAt(0));
				if (!ListUtils.isEmpty(chars)) {
					bundle.putString("valueSpell", chars.get(0).spell);
					FragmentManager fragmentManager = getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					HanziStudyFragment cardStudydFragment = new HanziStudyFragment();
					cardStudydFragment.setArguments(bundle);
					fragmentTransaction.add(R.id.fragment, cardStudydFragment);
					fragmentTransaction.commit();
				} else {
					showToast(R.string.search_without_word);
					finish();
				}
			} else {
				showToast(R.string.search_without_word);
				finish();
			}
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	/**
	 * 从服务器获取需要校验的数据
	 * 
	 * @param books
	 */
	private void getServerBookCheck(final List<Book> books) {
		new Thread() {
			public void run() {
				List<Book> updatebooks = new ArrayList<Book>();
				for (Book localbook : books) {
					Book serBook = BookUtils.getBookFromAce(localbook);
					if (serBook != null && localbook.getDate() != serBook.getDate()) {
						updatebooks.add(serBook);
					}
				}
				Message msg = Message.obtain();
				msg.what = 1;
				msg.obj = updatebooks;
				mHandler.sendMessage(msg);

			};
		}.start();
	}

	@SuppressLint("HandlerLeak")
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == 1) {
				List<Book> updatebook = (List<Book>) msg.obj;
				if (updatebook.size() > 0) {
					showDataUpdateDialog(updatebook);
				}
			}
		}
	};

	private void showDataUpdateDialog(final List<Book> updatebook) {
		Activity activity = HanziTraceMainActivity.this;
		if (new ActivityUtil(activity).isTopActivity("com.cybertron.hanzitrace")) {
			try {
				new AlertDialog.Builder(activity).setTitle(getResources().getString(R.string.update_title))
						.setMessage(getResources().getString(R.string.update_message))
						.setPositiveButton(getResources().getString(R.string.progress_ina), new OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog, int which) {
								mDataCheckUtil.startStoreDownload(HanziTraceMainActivity.this, updatebook);
							}
						}).setNegativeButton(getResources().getString(R.string.progress_nav), new OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog, int which) {

							}
						}).create().show();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void checkData() {
		if (mDataCheckUtil == null) {
			mDataCheckUtil = new DataCheckUtil(this, mUserName, mUserId, CyberConst.HANZIXUEXI);
		}
		if (mDataCheckUtil.DataExist()) {
			// initCyberHelper();
			HanZiHelper.newIntance(this, mDataCheckUtil.getAppDatas()).check();

			try {
				mDataParser = HZDataParser.getInstance();
				ttflocalpath = HanZiHelper.getIntance().getTtfPath();
				phraseBk = HanZiHelper.getIntance().getPhraseBook();
			} catch (Exception e) {
				e.printStackTrace();
			}

			mDictBooks = mDataCheckUtil.getAllBooks(mUserName, "cidian");
//			LightDictDBHelper.newInstance(this, mDictBooks);// 初始化词典
			DictDBHelper.newInstance(this,mDictBooks).check();
		} else {
			DataCheckReceiver.register(this, mReceiveListener);
			mDataCheckUtil.startCheckService(); // 从预置数据中恢复
		}
	}

	private DataCheckReceiverListener mReceiveListener = new DataCheckReceiverListener() {
		@Override
		public void onDataCheckComplete(Intent intent) {
			showToast(R.string.data_recover_over);
			checkData();
		}
	};

	private boolean login() {
		mCybHelper = CybHelper.getInstance(getApplicationContext());

		boolean isOk = false;

		if (!CybHelper.isAppInstalled(this)) {
			showToast(R.string.please_install_account_first);
			return isOk;
		}

		String msg = "login failed! ";
		JSONObject json = mCybHelper.login();
		if (json != null) {
			try {
				String status = json.getString(CybConfig.Accept.status);
				if (status.equals(CybConfig.Status.ok)) {
					mUserName = json.getString(CybConfig.Accept.uname);
					mUserId = json.getString(CybConfig.Accept.userid);
					msg = "login success! " + mUserName;
				} else if (status.equals(CybConfig.Status.illegalApp)) {
					msg += status;
				} else if (status.equals(CybConfig.Status.offLineTimeout)) {
					msg += status;
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
			Log.i("HanziTraceMainActivity", "login: " + msg);
		}
		isOk = !TextUtils.isEmpty(mUserName);
		if (!isOk) {
			showToast(R.string.login_failed);
		}
		return isOk;
	}

	private void showToast(int msgID) {
		Toast.makeText(this, getResources().getString(msgID), Toast.LENGTH_SHORT).show();
	}

	private void logout() {
		mCybHelper.logout();
	}

	private void initBar() {
		gradeView = (TextView) findViewById(R.id.toolbar_grade);
		groupView = (TextView) findViewById(R.id.toolbar_group);
		searchView = (TextView) findViewById(R.id.toolbar_search);
		mTextWithDel = (EditTextWithDel) findViewById(R.id.toolbar_edittext);
		mGridView = (StickyGridHeadersGridView) findViewById(R.id.asset_grid);

		gradeView.setOnClickListener(this);
		groupView.setOnClickListener(this);
		searchView.setOnClickListener(this);
		mTextWithDel.setOnClickListener(this);
		mTextWithDel.setOnEditorActionListener(new OnEditorActionListener() {

			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

				if (actionId == EditorInfo.IME_ACTION_SEARCH) {
					doSearch(mTextWithDel.getEditableText().toString());
				}
				return false;
			}

		});
	}

	/**
	 * 从assets 文件夹中获取文件并读取数据
	 * 
	 * @param fileName
	 * @return
	 */
	private String getFromAssets(String fileName) {
		String result = "";
		try {
			InputStream in = getResources().getAssets().open(fileName);
			// 获取文件的字节数
			int lenght = in.available();
			// 创建byte数组
			byte[] buffer = new byte[lenght];
			// 将文件中的数据读到byte数组中
			in.read(buffer);
			result = EncodingUtils.getString(buffer, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return replaceBlank(result);
	}

	/**
	 * 去掉换行，空格
	 * 
	 * @param str
	 * @return
	 */
	private String replaceBlank(String str) {
		String dest = "";
		if (str != null) {
			Pattern p = Pattern.compile("\\s*|\t|\r|\n");
			Matcher m = p.matcher(str);
			dest = m.replaceAll("");
		}
		return dest;
	}

	/**
	 * 初始化单个年级的数据
	 * 
	 * @param grade
	 */
	private void initCardsCellFragmentsData(int grade) {
		mGrade = grade;

		if (gradeView != null) {
			gradeView.setText(gradedata[grade]);
		}

		if (HZDataParser.isUseNewDb()) {
			HZDataParserDb parserDb = (HZDataParserDb) mDataParser;
			gradechars = parserDb.getCharsString(grade);
		} else {
			gradechars = getFromAssets("hanzi/" + grade + ".txt");
		}
		int totalChars = gradechars.length();

		int groupCounts = totalChars / StaticFinalUtil.GROUP_MAXCOLUMNS; // 当前年级汉字可以分成多少组
		if (totalChars > 0 && (totalChars % StaticFinalUtil.GROUP_MAXCOLUMNS) != 0) {
			groupCounts += 1;
		}
		if (groupCounts > 0) {
			mGroupItemsList = new ArrayList<GroupItem>();
			groupdata = new String[groupCounts];

			for (int i = 0; i < groupCounts; i++) {
				String sAgeFormat = getResources().getString(R.string.hanzi_group);
				groupdata[i] = String.format(sAgeFormat, (i + 1));
				initGroupCharsData(i); // 获取小组数据
			}
			if (mStickyGridAdapter != null) {
				mStickyGridAdapter.setGroupItems(mGroupItemsList);
				Log.i(this.getClass().getSimpleName(), "===Cur Group: " + mCurrentGroup);
				scrollToGroupPosition(mCurrentGroup);
				mStickyGridAdapter.setSelectPosition(-1);
			}

		} else {
			Toast.makeText(this, R.string.grade_no_data, Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * 初始化每一组中的所有汉字数据
	 * 
	 * @param group
	 */
	private void initGroupCharsData(int group) {
		int groupStartIndex = group * StaticFinalUtil.GROUP_MAXCOLUMNS; // 分组后组的起始位置下标
		for (int i = 0; i < StaticFinalUtil.GROUP_MAXCOLUMNS; i++) {
			int charIndex = groupStartIndex + i;
			if (charIndex >= gradechars.length()) {
				break;
			}
			String mchar = String.valueOf(gradechars.charAt(charIndex));
			if (mchar != null) {
				GroupItem mGroupItem = new GroupItem(mGrade, group, charIndex, mchar, i);
				mGroupItemsList.add(mGroupItem);
			}
		}
	}

	private int searchItemGroupPosition = 0;

	private boolean isSearchToGroup = false;

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.toolbar_grade:
			isSearchToGroup = false;
			if (mGradeListPopupWindow == null) {
				mGradeListPopupWindow = new ListPopupWindow(this, gradedata, -1);
				mGradeListPopupWindow.setListItemClickListener(new onListItemClickListener() {

					@Override
					public void onListItemClick(AdapterView<?> parent, View view, int position, long id) {
						initCardsCellFragmentsData(position);
						mGradeListPopupWindow.dismiss();
					}
				});
			}

			mGradeListPopupWindow.showAsDropDown(v);
			break;
		case R.id.toolbar_group:
			isSearchToGroup = false;

			mGroupListPopupWindow = new ListPopupWindow(this, groupdata, mCurrentGroup);
			mGroupListPopupWindow.setListItemClickListener(new onListItemClickListener() {

				@Override
				public void onListItemClick(AdapterView<?> parent, View view, int position, long id) {

					scrollToGroupPosition(position);
					mGroupListPopupWindow.dismiss();
				}
			});
			mGroupListPopupWindow.showAsDropDown(v);
			break;

		case R.id.toolbar_search:
			doSearch(mTextWithDel.getText().toString());
			break;
		}
	}

	private void doSearch(String searchHz) {
		if (TextUtils.isEmpty(searchHz)) {
			Toast.makeText(this, R.string.search_input_word, Toast.LENGTH_SHORT).show();
			return;
		}

		isSearchToGroup = true;

		SearchItem result = searchWord(searchHz);

		if (result == null) {
			Toast.makeText(this, R.string.search_without_word, Toast.LENGTH_SHORT).show();
			return;
		}

		if (result.grade != mGrade) {
			initCardsCellFragmentsData(result.grade);
		}

		searchItemGroupPosition = getCharGroup(result.order) - 1;

		scrollToGroupPosition(searchItemGroupPosition);
		mStickyGridAdapter.setSelectPosition(result.order);

		imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
	}

	private Cache cache = new Cache();

	/**
	 * 搜索汉字
	 * 
	 * @param word
	 * @return
	 */
	private SearchItem searchWord(String word) {

		SearchItem searchItem = null;

		try {
			searchItem = cache.get(word);

			if (searchItem == null) {

				List<SearchItem> searchItemList = new ArrayList<SearchItem>();
				for (int i = 0; i < 6; i++) {
					String hzdatas = null;
					if (HZDataParser.isUseNewDb()) {
						HZDataParserDb parserDb = (HZDataParserDb) mDataParser;
						hzdatas = parserDb.getCharsString(i);
					} else {
						hzdatas = getFromAssets("hanzi/" + i + ".txt");
					}
					if (hzdatas.contains(word)) {
						SearchItem item = new SearchItem(i, hzdatas.indexOf(word), word);
						searchItemList.add(item);
					}
				}

				if (searchItemList.size() > 0) {
					searchItem = searchItemList.get(0);
					cache.set(searchItemList);
				}
			} else {

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return searchItem;
	}

	private class Cache {

		String word;

		int current;

		List<SearchItem> items;

		public Cache() {
			reset();
		}

		public SearchItem get(String word) {
			SearchItem item = null;
			if (items != null) {
				if (this.word.equalsIgnoreCase(word)) {
					current = (current + 1) % items.size();
					return items.get(current);
				}
			}
			return item;
		}

		private void reset() {
			word = "";
			current = 0;
			items = null;
		}

		public void set(List<SearchItem> items) {
			this.items = items;
			current = 0;
			word = items.get(0).ch;
		}
	}

	/**
	 * 平滑滚动到小组
	 * 
	 * @param group
	 */
	protected void scrollToGroupPosition(int group) {
		final int scrollPosition = group * (StaticFinalUtil.GROUP_MAXCOLUMNS + StaticFinalUtil.numColumns)
				+ StaticFinalUtil.numColumns; // 需要滑动的指定条目的位置(gridview
												// 中的headview单独占一列 )

		Log.e(this.getClass().getSimpleName(), "====预计  ：group  " + group);
		mGridView.setSelection(scrollPosition); // 滑动到指定条目的位置
		mGridView.postDelayed(new Runnable() {

			@Override
			public void run() {
				mGridView.smoothScrollToPositionFromTop(scrollPosition, 100, 1);

			}
		}, 1);
	}

	/**
	 * 平滑滚动到指定条目位置
	 * 
	 * @param position
	 */
	protected void scrollToItemPosition(int position) {
		int group = getCharGroup(position);
		final int scrollposition = group * StaticFinalUtil.numColumns + position;
		mGridView.setSelection(scrollposition); // 滑动到指定条目的位置
		mGridView.postDelayed(new Runnable() {

			@Override
			public void run() {
				mGridView.smoothScrollToPositionFromTop(scrollposition, 100, 1);
			}
		}, 1);
	}

	/**
	 * 根据下标获取汉字所在的小组
	 * 
	 * @param charindex
	 * @return
	 */
	public int getCharGroup(int charindex) {
		int group = charindex / StaticFinalUtil.GROUP_MAXCOLUMNS;
		if (charindex % StaticFinalUtil.GROUP_MAXCOLUMNS != 0) {
			group += 1;
		}
		return group;
	}

	//
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		ActivityManager am = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
		ComponentName cn = am.getRunningTasks(1).get(0).topActivity;
		if (cn.getShortClassName().equals(".CardStudyActivity")) {
			Toast.makeText(this, R.string.invalid_click, Toast.LENGTH_SHORT).show();
			return;
		}

		if (mGroupItemsList != null && mGroupItemsList.size() > 0) {
			GroupItem mGroupItem = mGroupItemsList.get(position);
			int curGroup = mGroupItem.getGroup();
			ArrayList<GroupItem> mList = new ArrayList<GroupItem>();
			for (int i = 0; i < mGroupItemsList.size(); i++) {
				if (mGroupItemsList.get(i).getGroup() == curGroup) {
					mList.add(mGroupItemsList.get(i));
				}
			}
			try {
				Intent mIntent = new Intent();
				mIntent.setClass(this, CardStudyActivity.class);
				mIntent.putExtra("curgroupitem", mGroupItem);
				mIntent.putExtra("groupitemlist", mList);
				mIntent.putExtra("ttfpath", ttflocalpath);
				mIntent.putExtra("phrasepath", phraseBk.getLocalPath());
				mIntent.putParcelableArrayListExtra("dictbooks", (ArrayList<? extends Parcelable>) mDictBooks); // 词典资源
				startActivity(mIntent);
			} catch (Exception e) {
				Toast.makeText(this, getString(R.string.hz_data_incomplete), Toast.LENGTH_SHORT).show();
				;
				e.printStackTrace();
			}
			mStickyGridAdapter.setSelectPosition(-1);
		}
	}

	@Override
	public void onPerformHeader(View view, int group) {
		mCurrentGroup = group;
		if (isSearchToGroup) {
			Log.e("Hanzi", "===search group :" + searchItemGroupPosition + " , after group :" + mCurrentGroup);
			if (searchItemGroupPosition != mCurrentGroup) {
				scrollToGroupPosition(searchItemGroupPosition);
			} else {
				isSearchToGroup = false;
			}
		}

		if (groupView != null) {
			groupView.setText(groupdata[group]);
			groupView.invalidate();
		}
	}

	@Override
	public void finish() {
		super.finish();
		logout();
		DataCheckReceiver.unregister(this);
		try {
			Log.i("HAnzi", "==finish");
			HanZiHelper.getIntance().close();
//			LightDictDBHelper.getInstance().closeDatabase();
			DictDBHelper.getInstance().closeDatabase();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		System.exit(0);
	}
}
