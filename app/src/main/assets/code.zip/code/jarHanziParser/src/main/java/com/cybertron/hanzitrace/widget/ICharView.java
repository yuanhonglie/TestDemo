package com.cybertron.hanzitrace.widget;

import android.graphics.Bitmap;

import com.cybertron.hanzitrace.parse.Char;

/**
 * Created by Administrator on 2017/7/22.
 */

public interface ICharView {

    void setMode(StrokeDrawer.Mode m);

    void setColor(int color);

    void setWidth(int width);

    void setChar(Char c);

    Char getChar();

    void setScale(float scale);

    void setStrokeConfig(StrokeDrawer.StrokeConfig config);

    StrokeDrawer.StrokeConfig getStrokeConfig();

    void setEnableOriginal(boolean b);

    void setenableOutline(boolean b);

    void demonstrateOneStroke();

    void demonstrateAllStrokes();

    void pauseDemonstration();

    void resumeDemonstration();

    void resetDemonstration();

    void clearDemonstration();

    boolean isDemoStarted();

    boolean isDemoPlaying();

    boolean isDemoPaused();

    boolean isPractising();

    void practise();

    void stopAll();

    void stopPractise();

    boolean isDemonstrationMode();

    boolean isPractiseMode();

    boolean isAdvanceMode();

    Bitmap getUserInputBitmap();

    void setUsetInputBitmap(Bitmap bitmap);

    void setOnCompleteWritingListener(MagicCharView.OnCompleteWritingListener listener);

    void enableDebug(boolean enable);

    void skipDemoAudioMode(boolean skip);

    void setParams(MagicCharView.CharViewParams params);

    StringBuilder getLogMsg();
}
