package com.cybertron.hanzitrace.parse;

import java.util.List;

import com.cybertron.hanzitrace.parse.newdb.HZDataParserDb;

import android.content.Context;


public abstract class HZDataParser {
	public static final boolean ENABLE_NEW_DB = true; //true-使用新数据库中的描红数据
	public static final boolean SHOW_NEW_DATA = true; //true-允许显示DB中flag=2的数据
	
	//-------------------
	private static HZDataParser sParser = null;
	
	public static void initialize(Context context, String path, String keyStr) {
		if (sParser == null) {
			if (ENABLE_NEW_DB) {
				sParser = new HZDataParserDb(context, path, keyStr);
			} else {
				sParser = new HZDataParserBin(context, path, keyStr); 
			}
		}
	}
	
	private static void check() {
		if (sParser == null) {
			throw new RuntimeException("Please call HZDataParser.initialize() first!!");
		}
	}
	
	public static HZDataParser getInstance() {
		check();
		return sParser;
	}
	
	public void close() {
		sParser = null;
	}
	
	public static boolean isUseNewDb() {
		return ENABLE_NEW_DB;
	}
	
	public abstract Char getChar(char ch);
	
	/** 
	 根据字和拼音获取Char，有可能没有
	 */
	public abstract Char getChar(char ch, String spell);
	
	/** 
	 获取Char列表，有可能列表中只有一个，或者没有
	 */
	public abstract List<Char> getChars(char ch);
	
	public abstract Char getChar(int grade, int index);
	
	public abstract int getCount(int grade);
	
	public abstract boolean hasVoice(Char ch);
	
	public abstract byte[] getCharVoice(Char ch);
	
	public abstract List<String> getChars(int grade);
}
