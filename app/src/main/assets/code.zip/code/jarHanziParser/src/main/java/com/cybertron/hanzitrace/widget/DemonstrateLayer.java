package com.cybertron.hanzitrace.widget;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.Log;

import com.cybertron.hanzitrace.parse.newdb.NewStroke;

/**
 * Created by Administrator on 2017/8/2.
 */

public class DemonstrateLayer {
    private static final String TAG = "DemonstrateLayer";
    private Bitmap mDemoLayer;
    public DemonstrateLayer(Bitmap bitmap) {
        mDemoLayer = bitmap;
    }

    public synchronized void drawHighlightStroke(NewStroke stroke, Paint p1, Paint p2, float scale) {
        if (mDemoLayer == null || mDemoLayer.isRecycled()) {
            return;
        }
        Canvas canvas = new Canvas(mDemoLayer);
        stroke.drawOutline(canvas, p1, scale);
        stroke.drawContent(canvas, p2, scale);
    }

    public synchronized void drawOutline(NewStroke stroke, Paint paint, float scale) {
        if (mDemoLayer == null || mDemoLayer.isRecycled()) {
            return;
        }

        Canvas canvas = new Canvas(mDemoLayer);
        stroke.drawOutline(canvas, paint, scale);
    }

    public synchronized void setPixel(int x, int y, int color) {
        if (mDemoLayer != null && !mDemoLayer.isRecycled()) {
            mDemoLayer.setPixel(x, y, color);
        }
    }

    public synchronized void draw(Canvas canvas, float scale) {
        if (mDemoLayer != null && !mDemoLayer.isRecycled()) {
            if (scale >= NewStroke.MIN_SCALE_FACTOR) {
                canvas.drawBitmap(mDemoLayer, 0, 0, null);
            } else {
                float dstScale = scale/NewStroke.MIN_SCALE_FACTOR;
                Matrix matrix = new Matrix();
                matrix.setScale(dstScale, dstScale);
                canvas.drawBitmap(mDemoLayer, matrix, null);
            }
        }
    }

    public synchronized void clearDemoLayer(){
        if (mDemoLayer != null && !mDemoLayer.isRecycled()) {
            mDemoLayer.eraseColor(Color.TRANSPARENT);
        }
    }

    public synchronized void recycle() {
        if (mDemoLayer != null && !mDemoLayer.isRecycled()) {
            mDemoLayer.recycle();
        }
    }
}
