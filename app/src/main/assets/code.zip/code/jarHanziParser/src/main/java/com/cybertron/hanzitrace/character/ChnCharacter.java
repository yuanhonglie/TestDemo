package com.cybertron.hanzitrace.character;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Environment;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.cybertron.account.CyberConst;
import com.cybertron.account.util.ListUtils;

public class ChnCharacter implements Parcelable {
	public static final String CHAR_TEMP_DIR = CyberConst.TEMP_PATH + File.separator + "chnchar";
	private String ch;
	private String spell;
	private int type;
	private List<Phrase> phrases;
	
	public interface CharType {
		int recognize = 0;
		int write = 1;
	}
	
	public ChnCharacter() {
		phrases = new ArrayList<Phrase>();
	}
	
	public ChnCharacter(Parcel source) {
		this();
		ch 		= source.readString();
		spell 	= source.readString();
		type	= source.readInt();
		source.readTypedList(phrases, Phrase.CREATOR);
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(ch);
		dest.writeString(spell);
		dest.writeInt(type);
		dest.writeTypedList(phrases);
	}
	
	public String getChar() {
		return ch;
	}

	public void setChar(String ch) {
		this.ch = ch;
	}

	public String getSpell() {
		return spell;
	}

	public void setSpell(String spell) {
		this.spell = spell;
	}
	
	public List<Phrase> getPhrases() {
		return phrases;
	}
	
	public void setPhrases(List<Phrase> phrases) {
		this.phrases = phrases;
	}
	
	public List<ChnCharacter> getPhraseCharacters() {
		List<ChnCharacter> charList = new ArrayList<ChnCharacter>();
		if (!ListUtils.isEmpty(phrases)) {
			for (Phrase phrase : phrases) {
				charList.addAll(phrase.getPhrase());
			}
		}
		return charList;
	}
	
	public boolean hasPhrases() {
		return !ListUtils.isEmpty(phrases);
	}
	

	//静(jìnɡ); 夜(yè); 床(chuánɡ); 光(ɡuānɡ); 举(jǔ); 头(tóu); 望(wànɡ); 低(dī); 故(ɡù); 乡(xiānɡ);
	public static ChnCharacter valueOf(String str) throws Exception {
		if (TextUtils.isEmpty(str) || str.length() < 4) {
			throw new RuntimeException("illegel string : " + str);
		}
		
		ChnCharacter ch = null;
		String matchRegex = "(\\w)\\((\\w+)\\)";
		Pattern pattern = Pattern.compile(matchRegex);
		Matcher m = pattern.matcher(str);
		if (m.find()) {
			ch = new ChnCharacter();
			ch.setChar(m.group(1));
			ch.setSpell(m.group(2));
		}
		
		return ch;
	}

	public void setType(int type) {
		this.type = type;
	}
	
	public int getType() {
		return type;
	}
	
	public File getRecordFile() {
		return new File(CHAR_TEMP_DIR, ch+".amr");
	}

	public boolean hasRecordFile() {
		return getRecordFile().exists();
	}
	
	public File getUserStrokeFile() {
		return new File(CHAR_TEMP_DIR, ch+".stk");
	}
	
	public boolean hasStrokeFile() {
		return getUserStrokeFile().exists();
	}
	
	@Override
	public String toString() {
		return ch + "|" + spell + "|" + phrases;
	}
	
	public String toJSONString() {
		JSONObject json = toJSONObject();
		return json.toString();
	}
	
	public JSONObject toJSONObject() {
		JSONObject json = new JSONObject();
		try {
			json.put(JsonField.character, ch);
			json.put(JsonField.spell, spell);
			json.put(JsonField.type, type);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json;
	}
	
	public static ChnCharacter fromJSONObject(JSONObject json) {
		if (json == null) return null;
		ChnCharacter character = null;
		try {
			String ch = json.isNull(JsonField.character) ? "" : json.getString(JsonField.character);
			String spell = json.isNull(JsonField.spell) ? "" : json.getString(JsonField.spell);
			int type = json.isNull(JsonField.type) ? 0 : json.getInt(JsonField.type);
			
			character = new ChnCharacter();
			character.setType(type);
			character.setChar(ch);
			character.setSpell(spell);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return character;
	}
	
	public static ChnCharacter fromJSONString(String jsonStr) {
		JSONObject json = null;
		try {
			json = new JSONObject(jsonStr);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return fromJSONObject(json);
	}
	
	public static String arrayToJSONString(List<ChnCharacter> charList) {
		JSONArray jArray = new JSONArray();
		for (ChnCharacter ch : charList) {
			jArray.put(ch.toJSONObject());
		}
		return jArray.toString();
	}
	
	public static List<ChnCharacter> fromJSONArray(JSONArray jArray) {
		List<ChnCharacter> charList = new ArrayList<ChnCharacter>();
		if (jArray == null) return charList;
		try {
			for (int i = 0 ; i < jArray.length() ; i++) {
				JSONObject object = jArray.getJSONObject(i);
				ChnCharacter cc = fromJSONObject(object);
				charList.add(cc);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return charList;
	}
	
	public static List<ChnCharacter> fromJSONArrayString(String jArrayString) {
		JSONArray jArray = null;
		try {
			jArray = new JSONArray(jArrayString);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return fromJSONArray(jArray);
	}
	
	
	@Override
	public int describeContents() {
		return 0;
	}

	public interface JsonField {
		String character 	= "character";
		String spell 		= "spell";
		String type 		= "type";
	}
	
	
	public static final Parcelable.Creator<ChnCharacter> CREATOR = new Creator<ChnCharacter>() {
		@Override
		public ChnCharacter createFromParcel(Parcel source) {
			return new ChnCharacter(source);
		}

		@Override
		public ChnCharacter[] newArray(int size) {
			return new ChnCharacter[size];
		}
	};
	
	@Override
	public boolean equals(Object o) {
		if (o instanceof ChnCharacter) {
			ChnCharacter c = (ChnCharacter) o;
			if (c.ch.equals(ch) && c.spell.equals(spell)) {
				return true;
			}
		}
		return false;
	}
}
