package com.cybertron.hanzitrace.character;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.cybertron.account.book.Book;

import android.content.Context;
import android.util.Log;

public class CharacterVoice {
	private static final String TAG = "CharacterVoice";
	private CharVoiceDbHelper dbHelper;
	
	public CharacterVoice(Context context, String path) {
		if (path==null || path.length()<=0) {
			path = NewCharCfg.CHAR_VOICE_DB_PATH;
		}
		dbHelper = new CharVoiceDbHelper(context, path);
	}
	
	public CharacterVoice(Context context, Book voiceFile) {
		String path = NewCharCfg.CHAR_VOICE_DB_PATH;
		if (voiceFile != null) {
			path = voiceFile.getLocalPath();
		}
		dbHelper = new CharVoiceDbHelper(context, path);
	}
	
	public String getCharacterVoiceFile(ChnCharacter ch) {
		boolean ret = saveCharacterVoiceFile(ch, NewCharCfg.DEFAULT_CHARACTER_VOICE_PATH);
		if (ret) {
			return NewCharCfg.DEFAULT_CHARACTER_VOICE_PATH;
		} else {
			return "";
		}
	}
	
	public boolean saveCharacterVoiceFile(ChnCharacter ch, String path) {
		Log.i(TAG, "saveCharacterVoiceFile spell = " + ch.getSpell());
		boolean ret = true;
		byte[] buffer = dbHelper.getReadVoiceBuffer(ch.getSpell());
		if (buffer != null) {
			File vfile = new File(path);
			if (vfile.exists()) {
				vfile.delete();
			} else {
				vfile.getParentFile().mkdirs();
			}
			
			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(vfile);
				fos.write(buffer);
				fos.flush();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				ret = false;
			} catch (IOException e) {
				e.printStackTrace();
				ret = false;
			} finally {
				try {
					if (fos != null) fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} else {
			ret = false;
		}
		
		return ret;
	}
	
	public String getCharacterSpellVoiceFile(ChnCharacter ch) {
		boolean ret = saveCharacterSpellVoiceFile(ch, NewCharCfg.DEFAULT_CHARACTER_VOICE_PATH);
		if (ret) {
			return NewCharCfg.DEFAULT_CHARACTER_VOICE_PATH;
		} else {
			return "";
		}
	}
	
	public boolean saveCharacterSpellVoiceFile(ChnCharacter ch, String path) {
		Log.i(TAG, "saveCharacterVoiceFile spell = " + ch.getSpell());
		boolean ret = true;
		byte[] buffer = dbHelper.getSpellVoiceBuffer(ch.getSpell());
		if (buffer != null) {
			File vfile = new File(path);
			if (vfile.exists()) {
				vfile.delete();
			} else {
				vfile.getParentFile().mkdirs();
			}
			
			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(vfile);
				fos.write(buffer);
				fos.flush();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				ret = false;
			} catch (IOException e) {
				e.printStackTrace();
				ret = false;
			} finally {
				try {
					if (fos != null) fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} else {
			ret = false;
		}
		
		return ret;
	}
	
	public byte[] getCharacterVoice(ChnCharacter ch) {
		return dbHelper.getReadVoiceBuffer(ch.getSpell());
	}
	
	public boolean hasSpellVoice(ChnCharacter ch) {
		return dbHelper.hasSpellVoice(ch.getSpell());
	}
	public boolean hasReadVoice(ChnCharacter ch) {
		return dbHelper.hasReadVoice(ch.getSpell());
	}
	public boolean hasVoice(ChnCharacter ch) {
		byte[] abuffer = getCharacterVoice(ch);
		return abuffer == null ? false : abuffer.length > 0;
	}
	
	//==================
	public boolean hasVoices(String spell) {
		return (dbHelper.hasSpellVoice(spell) || dbHelper.hasReadVoice(spell));
	}
	
	public byte[] getCharSpellVoice(String spell) {
		byte[] sbytes = dbHelper.getSpellVoiceBuffer(spell);
		if (sbytes == null) {//有些没有拼读语音，改用读音
			sbytes = dbHelper.getReadVoiceBuffer(spell);
		}
		return sbytes;
	}
}
