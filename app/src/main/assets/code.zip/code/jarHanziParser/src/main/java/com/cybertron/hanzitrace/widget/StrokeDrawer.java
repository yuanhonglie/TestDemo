package com.cybertron.hanzitrace.widget;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Point;
import android.util.Log;

import com.cybertron.hanzitrace.parse.CPoint;
import com.cybertron.hanzitrace.parse.Stroke;

public class StrokeDrawer {
	
	private static final String TAG = StrokeDrawer.class.getSimpleName();
	private float scale = -1;
	private Paint paint, outPaint;
	private Paint showPaint, outShowPaint;
	private Paint highlightPaint, outHighlightPaint;
	private Paint bgPaint, outBgPaint;
	private Paint userPaint;
	private Path path = new Path();
	private Path path2 = new Path();
	private int color = Color.BLUE;
	
	private int mStuffIndex = 0;
	private int mWidth, mHeight;
	private Bitmap mShowLayer;
	private Bitmap mPractiseLayer;
	private Bitmap mBgLayer;
	private Bitmap mUserStroke;
	private boolean isDisplayingUserStroke;
	private static final int STEP_SIZE = 2;
	private int ORIGIN_CHARECTER_WIDTH = 160;
	
	private Mode mode = Mode.m1;
	private StrokeConfig mConfig = StrokeConfig.demo;
	private OnLayerCreatedListener mListener;
	
	public enum Mode {
		m1,m2;
	}
	
	public enum StrokeConfig {
		
		demo(
				2,			//
				1,			//
				15,			//
				0xffa6e269,	//background color
				Color.BLUE, //highlight color
				Color.RED,	//demonstrate color
				Color.RED,	//
				20,
				30,
				0
				),

		demo_emu (
				8,			//
				6,			//
				25,			//
				Color.BLACK,//background color
				Color.BLUE, //highlight color
				Color.RED,	//demonstrate color
				Color.RED,	//
				10,
				50,
				0
		),

		write(
				8,			//
				6,			//
				30,			//
				0xff888888,	//background color
				Color.BLUE,	//highlight color
				Color.BLUE,  //demonstrate color
				Color.RED,	//
				10,
				50,
//				1400
                2000
				),
		write_p10(
				8,			//
				6,			//
				18,			//
				0xff888888,	//background color
				Color.BLUE,	//highlight color
				Color.BLUE,  //demonstrate color
				Color.RED,	//
				15,
				40,
				800
				),
		write_p16(
				8,			//
				6,			//
				18,			//
				0xff888888,	//background color
				Color.BLUE,	//highlight color
				Color.BLUE,  //demonstrate color
				Color.RED,	//
				15,
				30,
				800
				),

		advance(
				8,			//
				6,			//
				30,			//
				0xff888888,	//background color
				Color.BLUE,	//highlight color
				Color.RED,  //demonstrate color
				Color.RED,	//
				10,
				50,
				500
				);
		
		public int contentWidth, outlineWidth, userWidth;
		public int bgColor, highlightColor, demoColor, userColor;
		public int drawInterval, dotsPerDraw, testBlockSize;
		private StrokeConfig(int content, int outline, int user, int bgColor, int highlightColor, int demoColor, int userColor) {
			this(content, outline, user, bgColor, highlightColor, demoColor, userColor, 0, 0, 0);
		}

		private StrokeConfig(int content, int outline, int user, int bgColor, int highlightColor, int demoColor, int userColor, int interval, int dotsPerDraw, int blockSize) {
			this.contentWidth = content;
			this.outlineWidth = outline;
			this.userWidth = user;
			this.bgColor = bgColor;
			this.highlightColor = highlightColor;
			this.demoColor = demoColor;
			this.userColor = userColor;
			this.drawInterval = interval;
			this.dotsPerDraw = dotsPerDraw;
			this.testBlockSize = blockSize;
		}
	}
	
	public void setMode(Mode m) {
		mode = m;
	}
	
	public StrokeDrawer() {
		paint = new Paint();
		paint.setAntiAlias(true);  
		paint.setStyle(Style.STROKE);  
		paint.setStrokeWidth(1);  
		paint.setColor(Color.BLACK);
		
		outPaint = new Paint(paint);
		outPaint.setStrokeWidth(6);  
		
		highlightPaint = new Paint(paint);
		highlightPaint.setColor(0xff90e6cd);
		outHighlightPaint = new Paint(outPaint);
		outHighlightPaint.setColor(0xff90e6cd);
		
		bgPaint = new Paint(paint);
		bgPaint.setColor(0xff7d7373);
		outBgPaint = new Paint(outPaint);
		outBgPaint.setColor(0xff7d7373);
		
		showPaint = new Paint(paint);
		showPaint.setColor(Color.BLUE);
		outShowPaint = new Paint(outPaint);
		outShowPaint.setColor(Color.BLUE);
		
		userPaint = new Paint();
		userPaint.setStyle(Style.STROKE);
		userPaint.setStrokeJoin(Join.ROUND);
		userPaint.setStrokeCap(Cap.ROUND);
		userPaint.setAntiAlias(true);
		userPaint.setColor(Color.RED);
		userPaint.setStrokeWidth(30);
	}
	
	public void setStrokeConfig(StrokeConfig config) {
			mConfig = config;
			Log.i(TAG, "setStrokeConfig --> ");
			allocLayers();

			paint.setStrokeWidth(config.contentWidth);  
			outPaint.setStrokeWidth(config.outlineWidth);
			
			highlightPaint.setStrokeWidth(config.contentWidth);
			highlightPaint.setColor(config.highlightColor);
			outHighlightPaint.setStrokeWidth(config.outlineWidth);
			outHighlightPaint.setColor(config.highlightColor);
			
			bgPaint.setStrokeWidth(config.contentWidth);
			bgPaint.setColor(config.bgColor);
			outBgPaint.setStrokeWidth(config.outlineWidth);
			outBgPaint.setColor(config.bgColor);
			
			showPaint.setStrokeWidth(config.contentWidth);
			showPaint.setColor(config.demoColor);
			outShowPaint.setStrokeWidth(config.outlineWidth);
			outShowPaint.setColor(config.demoColor);
			
//			if (StrokeConfig.write == config) {
//				userPaint.setStrokeWidth(20);
//			} else {
				userPaint.setStrokeWidth(config.userWidth);
//			}
	}
	
	public void setColor(int color) {
		outPaint.setColor(color);
	}
	
	public void setScale(float scale) {
		if (scale < 0.5) return;
		this.scale = scale;
    }
	
	public float getScale() {
		return scale;
	}
	
	public void setStrokeWidth(int width) {
		paint.setStrokeWidth(width);
		bgPaint.setStrokeWidth(width);
		showPaint.setStrokeWidth(width);
		highlightPaint.setStrokeWidth(width);
	}
	
	public void drawOriginal(Canvas canvas, Stroke stroke) {
		drawOriginal(canvas, stroke, paint);
	}
	
	public void drawOriginal(Canvas canvas, Stroke stroke, Paint paint) {
		if (stroke == null) {
			return ;
		}
		for (int j=0; j<stroke.getCount()-1; j++) {
			Point p1 = stroke.get(j).scale(scale);
			Point p2 = stroke.get(j+1).scale(scale);
			canvas.drawLine(p1.x, p1.y, p2.x, p2.y, paint);
		}
	}
	
	public void drawOutline(Canvas canvas, Stroke stroke) {
//		drawOutline1(canvas, stroke);
//		drawOutline2(canvas, stroke);
//		drawOutline3(canvas, stroke);
		if (mode == Mode.m1) {
			drawOutline4(canvas, stroke);
			drawOutline5(canvas, stroke);
		}
		else if (mode == Mode.m2) {
			drawOutline6(canvas, stroke);
		}
	}
	
	private void drawOutline1(Canvas canvas, Stroke stroke) {
		for (int j=0; j<stroke.getCount()-3; j++) {
			CPoint p1 = stroke.get(j).scale(scale);
			CPoint p2 = stroke.get(j+1).scale(scale);
			CPoint p3 = stroke.get(j+2).scale(scale);
			CPoint p4 = stroke.get(j+3).scale(scale);
			canvas.drawLine(p1.x, p1.y, p3.x, p3.y, outPaint);
			canvas.drawLine(p2.x, p2.y, p4.x, p4.y, outPaint);
		}
	}
	
	private void drawOutline2(Canvas canvas, Stroke stroke) {
		for (int j=0; j<stroke.getCount()-5; j++) {
			CPoint p1 = stroke.get(j).scale(scale);
			CPoint p2 = stroke.get(j+1).scale(scale);
			CPoint p3 = stroke.get(j+2).scale(scale);
			CPoint p4 = stroke.get(j+3).scale(scale);
			CPoint p5 = stroke.get(j+4).scale(scale);
			CPoint p6 = stroke.get(j+5).scale(scale);
			
			CPoint p13 = p1.average(p3);
			CPoint p35 = p3.average(p5);
			CPoint p24 = p2.average(p4);
			CPoint p46 = p4.average(p6);
			
			canvas.drawLine(p13.x, p13.y, p35.x, p35.y, outPaint);
			canvas.drawLine(p24.x, p24.y, p46.x, p46.y, outPaint);
		}
	}
	
	private void drawOutline3(Canvas canvas, Stroke stroke) {
		for (int j=0; j<stroke.getCount()-3; j++) {
			CPoint p1 = stroke.get(j).scale(scale);
			CPoint p2 = stroke.get(j+1).scale(scale);
			CPoint p3 = stroke.get(j+2).scale(scale);
			CPoint p4 = stroke.get(j+3).scale(scale);
			
			CPoint p13 = p1.average(p3);
			CPoint p24 = p2.average(p4);
			
			path.reset();
			path.moveTo(p1.x, p1.y);
			path.quadTo(p13.x, p13.y, p3.x, p3.y);
			canvas.drawPath(path, outPaint);
			
			path.reset();
			path.moveTo(p2.x, p2.y);
			path.quadTo(p24.x, p24.y, p4.x, p4.y);
			canvas.drawPath(path, outPaint);
		}
	}
	
	private void drawOutline4(Canvas canvas, Stroke stroke) {
		drawOutline4(canvas, stroke, outPaint);
	}

	private void drawOutline4(Canvas canvas, Stroke stroke, Paint paint) {
		path.reset();
		CPoint p1 = stroke.get(0).scale(scale);
		path.moveTo(p1.x, p1.y);
		for (int j=0; j<stroke.getCount()-5; j+=2) {
			p1 = stroke.get(j).scale(scale);
			CPoint p3 = stroke.get(j+2).scale(scale);
			CPoint p5 = stroke.get(j+4).scale(scale);
			
			path.quadTo(p3.x, p3.y, p5.x, p5.y);
		}
		canvas.drawPath(path, paint);
	}
	
	private void drawOutline5(Canvas canvas, Stroke stroke) {
		drawOutline5(canvas, stroke, outPaint);
	}
	
	private void drawOutline5(Canvas canvas, Stroke stroke, Paint paint) {
		path2.reset();
		CPoint p1 = stroke.get(1).scale(scale);
		path2.moveTo(p1.x, p1.y);
		for (int j=0; j<stroke.getCount()-5; j+=2) {
			p1 = stroke.get(j+1).scale(scale);
			CPoint p3 = stroke.get(j+3).scale(scale);
			CPoint p5 = stroke.get(j+5).scale(scale);
			
			path2.quadTo(p3.x, p3.y, p5.x, p5.y);
		}
		canvas.drawPath(path2, paint);
	}
	
	private void drawOutline6(Canvas canvas, Stroke stroke) {
		drawOutline6(canvas, stroke, outPaint);
	}
	
	private void drawOutline6(Canvas canvas, Stroke stroke, Paint paint) {
		for (int j=0; j<stroke.getCount()-11; j++) {
			CPoint p1 = stroke.get(j).scale(scale);
			CPoint p2 = stroke.get(j+10).scale(scale);
			
			canvas.drawLine(p1.x, p1.y, p2.x, p2.y, paint);
		}
		CPoint p2 = stroke.get(stroke.getCount()-1).scale(scale);
		for (int j=stroke.getCount()-10; j<stroke.getCount(); j++) {
			CPoint p1 = stroke.get(j).scale(scale);
			canvas.drawLine(p1.x, p1.y, p2.x, p2.y, paint);
		}
	}

	public boolean initLayers(int width, int height) {
		boolean succ = false;
		
		if (width <= 0 || height <= 0) {
			return succ;
		}
		
		if (width != mWidth || height != mHeight) {
			mWidth = width;
			mHeight = height;
			allocLayers();
			int sw = Math.min(mWidth, mHeight);
			if (scale <= 0.5) {
				scale = ((float)sw / (float)ORIGIN_CHARECTER_WIDTH);
			}
            if (mListener != null) {
				mListener.onLayerCreated(width, height);
			}
			setUserStroke();
			succ = true;
		}
		
		return succ;
	}
	
	private void setUserStroke() {
		if (mUserStroke != null && !mUserStroke.isRecycled()) {
			Canvas canvas = new Canvas(mPractiseLayer);
			Rect src = new Rect(0, 0, mUserStroke.getWidth(), mUserStroke.getHeight());
			Rect dst = new Rect(0, 0, mWidth, mHeight);
			canvas.drawBitmap(mUserStroke, src, dst, null);
			canvas.save(Canvas.ALL_SAVE_FLAG);
			canvas.restore();
			isDisplayingUserStroke = true;
			mUserStroke.recycle();
			mUserStroke = null;
		}
	}

	private void allocLayers() {
		if (mWidth <= 0 || mHeight <= 0) {
			return;
		}
		recycle();
		
		if (mConfig != StrokeConfig.demo) {
			createPractiseLayer();
		}
		createDemoLayer();
		createBgLayer();
	}
	
	private void createDemoLayer() {
		if (mShowLayer != null && !mShowLayer.isRecycled()) {
			mShowLayer.recycle();
		}
		mShowLayer 		= Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_4444);
	}
	
	private void createPractiseLayer() {
		if (mPractiseLayer != null && !mPractiseLayer.isRecycled()) {
			mPractiseLayer.recycle();
		}
		mPractiseLayer 	= Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_4444);
	}
	
	//获取用户的输入笔记
	public Bitmap getPractiseLayer() {
		return mPractiseLayer;
	}
	
	public void setPractiseLayer(Bitmap userInputBmp) {
		//在mPractiseLayer上居中绘制用户的输入笔迹userInputBmp
		mUserStroke = userInputBmp;
	}
	
	public boolean isDisplayingUserStroke() {
		return isDisplayingUserStroke;
	}
	
	private void createBgLayer() {
		if (mBgLayer != null && !mBgLayer.isRecycled()) {
			mBgLayer.recycle();
		}
		mBgLayer = Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_4444);
	}
	
	public void recycle() {
		if (mShowLayer != null && !mShowLayer.isRecycled()) {
			mShowLayer.recycle();
		}
		if (mPractiseLayer != null && !mPractiseLayer.isRecycled()) {
			mPractiseLayer.recycle();
		}
		if (mBgLayer != null && !mBgLayer.isRecycled()) {
			mBgLayer.recycle();
		}
	}
	
	public void resetDemoStroke() {
		Log.i(TAG, "resetDemoStroke: ");
		mStuffIndex = 0;
	}
	
	/**
	 * 
	 * @param canvas
	 * @param stroke
	 * @return true: completed, false: not completed
	 */
	public boolean visualDrawOneStroke(Canvas canvas, Stroke stroke) {
		boolean finish = false;

		if (mShowLayer == null) {
			Log.i(TAG, "visualDrawOneStroke: mShowLayer is null !!");
			return finish;
		}
		
		if (mStuffIndex > stroke.getCount() - 1 || mStuffIndex < 0) {
//			throw new RuntimeException(" invalid mStuffIndex = " + mStuffIndex + ", stroke.getCount() = " + stroke.getCount());
			Log.e(TAG, "invalid mStuffIndex = " + mStuffIndex + ", stroke.getCount() = " + stroke.getCount());
			mStuffIndex = 0;
			return true;
		} else if (mStuffIndex == stroke.getCount() - 1) {
			Log.i(TAG, "visualDrawOneStroke: finish demostrating current stroke !!");
			mStuffIndex = 0;
			return true;
		}
		
		Canvas mCanvas = new Canvas(mShowLayer);
		
		for (int i = 0; i < STEP_SIZE && mStuffIndex < stroke.getCount() - 1 ; i++, mStuffIndex++) {
			CPoint p1 = stroke.get(mStuffIndex).scale(scale);
			CPoint p2 = stroke.get(mStuffIndex + 1).scale(scale);
			mCanvas.drawLine(p1.x, p1.y, p2.x, p2.y, showPaint);
		}

		int startIndex = mStuffIndex - STEP_SIZE;
		if (startIndex < 13) {
			
			CPoint p1 = stroke.get(0).scale(scale);
			for (int j=0; j < mStuffIndex; j++) {
				CPoint p2 = stroke.get(j).scale(scale);
				mCanvas.drawLine(p1.x, p1.y, p2.x, p2.y, outShowPaint);
			}
		} else {

			for (int j = startIndex - 13; j < mStuffIndex - 13; j++) {
				CPoint p1 = stroke.get(j).scale(scale);
				CPoint p2 = stroke.get(j+12).scale(scale);
				mCanvas.drawLine(p1.x, p1.y, p2.x, p2.y, outShowPaint);
			}
			
			if (mStuffIndex >= stroke.getCount() - 1) {
				CPoint p2 = stroke.get(stroke.getCount() - 1).scale(scale);
				for (int j = stroke.getCount() - 12; j < stroke.getCount(); j++) {
					CPoint p1 = stroke.get(j).scale(scale);
					mCanvas.drawLine(p1.x, p1.y, p2.x, p2.y, outShowPaint);
				}
			}
		}
		drawShowLayer(canvas);
		if (mStuffIndex >= stroke.getCount() - 1) {
			mStuffIndex = 0;
			finish = true;
		}
		
		return finish;
	}
	
	public void drawShowLayer(Canvas canvas) {
		canvas.drawBitmap(mShowLayer, 0, 0, null);
	}
	
	public void clearShowLayer() {
		mStuffIndex = 0;
		if (mShowLayer != null && !mShowLayer.isRecycled()) {
			try {
				mShowLayer.eraseColor(Color.TRANSPARENT);	
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void drawUserStrokes(Canvas canvas) {
		if (mPractiseLayer != null) {
			canvas.drawBitmap(mPractiseLayer, 0, 0, null);
		}
	}
	
	public void drawUserStrokeToBuffer(Path path) {
		if (mPractiseLayer != null) {
			Canvas mCanvas = new Canvas(mPractiseLayer);
			mCanvas.drawPath(path, userPaint);
		}
	}
	
	public void drawUserInput(Canvas canvas, Path path) {
		canvas.drawPath(path, userPaint);
	}
	
	public void clearPractiseLayer() {
		if(mPractiseLayer != null) {
			try {
				isDisplayingUserStroke = false;
				mPractiseLayer.eraseColor(Color.TRANSPARENT);	
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void drawStrokeBg(Canvas canvas){
		if (mBgLayer != null) {
			canvas.drawBitmap(mBgLayer, 0, 0, null);
		}
	}
	
	public void drawStrokeBgToBuff(Stroke stroke) {
		if (mBgLayer != null) {
			Canvas canvas = new Canvas(mBgLayer);
			drawOriginal(canvas, stroke, bgPaint);
			drawOutline6(canvas, stroke, outBgPaint);
		}
	}
	
	public void clearBgLayer() {
		if(mBgLayer != null) {
			mBgLayer.eraseColor(Color.TRANSPARENT);
		}
	}
	
	public void highlightStroke(Canvas canvas, Stroke stroke) {
		drawOriginal(canvas, stroke, highlightPaint);
		drawOutline6(canvas, stroke, outHighlightPaint);
	}
	
	public void setOnLayerCreatedListener(OnLayerCreatedListener listener){
		mListener = listener;
	}
	
	public interface OnLayerCreatedListener {
		void onLayerCreated(int width, int height);
	}
}
