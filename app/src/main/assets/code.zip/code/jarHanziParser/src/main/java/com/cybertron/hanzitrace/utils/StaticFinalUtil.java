package com.cybertron.hanzitrace.utils;

import com.cybertron.account.CyberConst;

public class StaticFinalUtil {

	/** 页内每行显示个数 **/
	public static final int numColumns = 5;
	/** 页内行数 **/
	public static final int numLines = 4;
	/** 每组最多显示个数 **/
	public static final int GROUP_MAXCOLUMNS = numColumns * numLines;
	/** 汉字发音临时文件**/
	public static final String TMP_CHAR_VOICE_FILE = CyberConst.BASE_PATH+ "/temp/char_voice.mp3";
	/** 词典数据库文件**/
	public static final String DICT_DB_FILE = CyberConst.BASE_PATH+"/res/dict/dict.db";
	/** 汉字字体文件 **/
	public static final String FONTS_FILE_PATH = CyberConst.BASE_PATH+"/res/fonts/SIMKAI.TTF";
	/** tab 释义 TAG**/
	public static final String TAB_EXPLAIN_TAG = "explain";
	/** tab 组词 TAG**/
	public static final String TAB_COMBINATION_TAG = "combination";
	/** tab 释义 label**/
	public static final String TAB_EXPLAIN_LABEL = "释义";
	/** tab 组词 label**/
	public static final String TAB_COMBINATION_LABEL = "组词";
	/**汉字**/
	public static final String TAB_COURSE_NAME = "courseName";
	/**汉字硬笔视频地址**/
	public static final String TAB_COURSE_VIDEO = "coursevideo";
	/**汉字硬笔视频封面**/
	public static final String TAB_COURSE_SCREENSHOT ="courseScreenShot";
	/** 词典加密key **/
	public static final String DICT_DB_KEY = "2D367F67";
}
