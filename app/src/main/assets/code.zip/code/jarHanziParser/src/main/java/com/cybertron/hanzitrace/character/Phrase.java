package com.cybertron.hanzitrace.character;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cybertron.account.util.ListUtils;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;

public class Phrase implements Parcelable {
	
	private static final String TAG = Phrase.class.getSimpleName();
	private List<ChnCharacter> phrase;
	public Phrase() {
		phrase = new ArrayList<ChnCharacter>();
	}
	
	public Phrase(Parcel source) {
		this();
		source.readTypedList(phrase, ChnCharacter.CREATOR);
	}

	public List<ChnCharacter> getPhrase() {
		return phrase;
	}
	
	public void setPhrase(List<ChnCharacter> phrase) {
		this.phrase = phrase;
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	//插曲(chā qǔ);词曲(cí qǔ);度曲(dù qǔ);歌曲(ɡē qǔ);款曲(kuǎn qū);扭曲(niǔ qū);曲笔(qū bǐ);曲尺(qū chǐ);曲解(qū jiě);曲霉(qū méi);
	public static List<Phrase> valueOfArrayString(String arrayStr) {
		List<Phrase> phrases = new ArrayList<Phrase>();
		if (TextUtils.isEmpty(arrayStr)) {
			return phrases;
		}
		
		String [] phraseStrs = arrayStr.split(";");
		for (String phraseStr : phraseStrs) {
			Phrase phrase = valueOf(phraseStr);
			if (phrase != null) {
				phrases.add(phrase);
			}
		}
		
		return phrases;
	}
	
	//插曲(chā qǔ)
	public static Phrase valueOf(String phraseStr) {
		Phrase phrase = null;
		if (TextUtils.isEmpty(phraseStr)) {
			return phrase;
		}
		
		String charsStr = null;
		String spellsStr = null;
		String matchRegex = "(\\w+)\\((\\w+.*)\\)";
		Pattern pattern = Pattern.compile(matchRegex);
		Matcher m = pattern.matcher(phraseStr);
		if (m.find()) {
			charsStr = m.group(1);
			spellsStr = m.group(2);
		}

		List<ChnCharacter> charList = new ArrayList<ChnCharacter>();
		if (!TextUtils.isEmpty(charsStr) && !TextUtils.isEmpty(spellsStr)) {
			String [] spellStrs = spellsStr.split(" ");
			if (spellStrs.length == charsStr.length()) {
				for (int i = 0 ; i < spellStrs.length ; i ++) {
					char ch = charsStr.charAt(i);
					ChnCharacter cc = new ChnCharacter();
					cc.setChar(""+ch);
					cc.setSpell(spellStrs[i]);
					charList.add(cc);
				}
			} else {
				Log.e(TAG, "the number of char and the number of spell does not match!!");
			}
		} else {
			Log.e(TAG, "missing char or spell!!");
		}
		
		if (!ListUtils.isEmpty(charList)) {
			phrase = new Phrase();
			phrase.setPhrase(charList);
		}
		
		return phrase;
	}
	
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeTypedList(phrase);
	}
	
	
	@Override
	public String toString() {
		return ""+phrase;
	}
	
	public static final Parcelable.Creator<Phrase> CREATOR = new Creator<Phrase>() {
		@Override
		public Phrase createFromParcel(Parcel source) {
			return new Phrase(source);
		}
		
		@Override
		public Phrase[] newArray(int size) {
			return new Phrase[size];
		}
	};
	
	//-------------
	public String getSpells() {
		return getSpells(" ");
	}
	
	public String getSpells(String divider) {
		String spells = "";
		for (ChnCharacter c:phrase) {
			spells += c.getSpell()+divider;
		}
		return spells.trim();
	}
	
	public String getChars() {
		return getChars(" ");
	}
	
	public String getChars(String divider) {
		String chars = "";
		for (ChnCharacter c:phrase) {
			chars += c.getChar()+divider;
		}
		return chars.trim();
	}
}
