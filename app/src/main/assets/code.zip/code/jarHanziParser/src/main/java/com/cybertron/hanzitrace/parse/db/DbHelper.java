package com.cybertron.hanzitrace.parse.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DbHelper extends SQLiteOpenHelper {
	private static final String TAG = DbHelper.class.getSimpleName();

	public static final String TABLE = "bishun";
	private static final int DATABASE_VERSION = 7;
	
	public DbHelper(Context context, String dbPath) {
		super(context, dbPath, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
//		String sql = "CREATE TABLE IF NOT EXISTS " + TABLE
//				+"("
//				+Field.id        + " INTEGER PRIMARY KEY AUTOINCREMENT, "
//				+Field.character + " CHAR(2)   NOT NULL, "
//				+Field.sum       + " INT       NOT NULL, "
//				+Field.bishun    + " TEXT      NOT NULL"
//				+");";
//		
//		Log.i(TAG, "onCreate(): " + sql);
//		db.execSQL(sql);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//		String sql = "DROP TABLE IF EXISTS "+TABLE;
//		Log.i(TAG, "onUpgrade(): " + sql);
//		db.execSQL(sql);
//		onCreate(db);
	}
	
	@Override
	public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//		String sql = "DROP TABLE IF EXISTS "+TABLE;
//		Log.i(TAG, "onDowngrade(): " + sql);
//		db.execSQL(sql);
//		onCreate(db);
	}
	
	public String getBishun(char ch) {
		String bishun = null;
		
		try {
			SQLiteDatabase db = getReadableDatabase();
			String selection = Field.character+"=?";
			String[] args = new String[]{""+ch};
			
			Cursor c = db.query(TABLE, null, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					bishun = c.getString(c.getColumnIndex(Field.bishun));
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
//			e.printStackTrace();
		}
		
		return bishun;
	}
}
