package com.cybertron.hanzitrace.parse;

import java.io.Serializable;

import android.graphics.Point;

public class CPoint extends Point implements Serializable{

	private static final long serialVersionUID = -2098014127112019789L;

	public CPoint() {
	}

	public CPoint(Point src) {
		super(src);
	}

	public CPoint(int x, int y) {
		super(x, y);
	}

	public CPoint scale(float scale) {
		return new CPoint((int)(x*scale), (int)(y*scale));
	}
	
	public static CPoint average(CPoint p1, CPoint p2) {
		return new CPoint((p1.x+p2.x)/2, (p1.y+p2.y)/2);
	}
	
	public CPoint average(CPoint p2) {
		return average(this, p2);
	}
	
	@Override
	public String toString() {
		return "("+x+","+y+")";
	}
}
