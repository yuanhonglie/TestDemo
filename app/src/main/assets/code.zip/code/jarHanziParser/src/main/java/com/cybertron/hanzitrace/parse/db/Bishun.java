package com.cybertron.hanzitrace.parse.db;

/**
 * Created by yhl on 2017/12/21.
 */
public class Bishun {
    private String id;
    private String name;

    public Bishun(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return toText();
    }

    public static Bishun fromText(String text) {
        String[] parts = text.split("-");
        Bishun bishun = null;
        if (parts.length == 2) {
            bishun = new Bishun(parts[0], parts[1]);
        }

        return bishun;
    }

    public String toText() {
        return id + "-" + name;
    }
}
