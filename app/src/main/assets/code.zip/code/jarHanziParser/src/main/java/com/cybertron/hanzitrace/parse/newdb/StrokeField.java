package com.cybertron.hanzitrace.parse.newdb;

public interface StrokeField {
	String id = "_id";
	String idx = "idx";
	String name = "name";
	String strokeVoice = "strokeVoice";
}
