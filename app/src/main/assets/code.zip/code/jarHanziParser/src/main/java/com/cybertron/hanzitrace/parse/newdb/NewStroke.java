package com.cybertron.hanzitrace.parse.newdb;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.Log;

import com.cybertron.account.util.ListUtils;
import com.cybertron.hanzitrace.parse.CPoint;
import com.cybertron.hanzitrace.parse.Stroke;
import com.cybertron.hanzitrace.widget.DemonstrateStrokeTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class NewStroke extends Stroke {
    private static final long serialVersionUID = -7785106733000611072L;

    private static final String TAG = "NewStroke";
    /**
     * 由于平台差异，浮点计算的精度不相同，在android上绘制的轮廓点，可能会出现轮廓点不封闭的情况。
     * 所以在绘制轮廓点时，采用抗锯齿的方式绘制，在取轮廓点时，只要坐标点的颜色值不为0（透明）,
     * 则认为是轮廓点，这样就可以保证轮廓点是封闭的。但是这又可能会引入另一个问题，当缩放系数小于2时，
     * 起始点可能会落到轮廓点上，导致无法执行填充算法。所以对于缩放系数小于2时，将轮廓放大到2倍之后
     * 再使用填充算法获取填充点，实际显示时再对图片进行缩放绘制。这里缩放系数定为2.0f是根据实测数据确定的。
     */
    public static final float MIN_SCALE_FACTOR = 2.0f;
    private CPoint startPoint;
    private List<StkLine> lines;
    private Map<Float, Path> pathCache = new HashMap<Float, Path>();
    private Map<Float, List<CPoint>> fillPointCache = new HashMap<Float, List<CPoint>>();
    private List<Integer> outlineParts = new ArrayList<Integer>();

    private Paint mDotPaint;

    public NewStroke() {
        lines = new ArrayList<StkLine>();
        mDotPaint = new Paint();
        mDotPaint.setColor(Color.BLACK);
    }

    public CPoint getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(CPoint startPoint) {
        this.startPoint = startPoint;
    }

    public void addLine(StkLine line) {
        lines.add(line);
    }

    public StkLine getLine(int index) {
        return lines.get(index);
    }

    public List<StkLine> getLines() {
        return lines;
    }

    public List<Integer> getOutlineParts() {
        return outlineParts;
    }

    /**
     * 绘制笔画轮廓
     *
     * @param canvas 画布
     * @param paint  画笔
     * @param scale  放大系数
     */
    public void drawOutline(Canvas canvas, Paint paint, float scale) {
        Path path = getOutlinePath(scale);
        if (path != null && !path.isEmpty()) {
            canvas.drawPath(path, paint);
        }
    }

    /**
     * 绘制笔画填充
     *
     * @param canvas 画布
     * @param paint  画笔
     * @param scale  放大系数
     */
    public void drawContent(Canvas canvas, Paint paint, float scale) {
        Path path = getOutlinePath(scale);
        if (path != null && !path.isEmpty()) {
            canvas.drawPath(path, paint);
        }
        /*
        for (StkLine line : lines) {
            List<CPoint> points = line.getPoints();
            for (CPoint cp : points) {
                CPoint point = cp.scale(scale);
                canvas.drawCircle(point.x, point.y, 4, mDotPaint);
            }
        }
        */
    }

    /**
     * 获取当前笔画的关键点构成的封闭Path
     *
     * @param scale 放大系数
     * @return
     */
    public Path getOutlinePath(float scale) {
        if (pathCache.containsKey(scale)) {
            return pathCache.get(scale);
        }

        Path path = new Path();
        for (StkLine line : lines) {
            line.getPath(path, scale);
        }
        path.close();

        pathCache.clear();
        pathCache.put(scale, path);

        return path;
    }

    public List<CPoint> getStrokeFillPoints(Bitmap bitmap, DemonstrateStrokeTask.IDemonstrateStrategy strategy) throws FloodFillException {
        float scale = strategy.getScale();
        //当放大系数小于1时，起始点可能会不在轮廓点内部。
        //所以当轮廓点小于1时，按照放大系数为1获取填充点；
        //显示时将图片缩小进行显示；
        if (scale < MIN_SCALE_FACTOR) {
            scale = MIN_SCALE_FACTOR;
        }

        if (fillPointCache.containsKey(scale)) {
            return fillPointCache.get(scale);
        }

        int fillColor = Color.RED;
        int borderColor = Color.BLACK;
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1);
        paint.setColor(borderColor);
        List<CPoint> points = new ArrayList<CPoint>();
        if (bitmap != null && !bitmap.isRecycled()) {
            bitmap.eraseColor(0);
            Canvas canvas = new Canvas(bitmap);
            Path path = getOutlinePath(scale);
            canvas.drawPath(path, paint);
            points = floodFill4(bitmap, getStartPoint().scale(scale), strategy.getTestDotsSize(), fillColor, borderColor);
//            points = floodFill8(bitmap, getStartPoint().scale(scale), strategy.getTestDotsSize(), fillColor, borderColor);
        }
        fillPointCache.clear();
        if (!ListUtils.isEmpty(points)) {//当填充被中断时，points为空，不应该加入到缓存中去
            fillPointCache.put(scale, points);
        }

        return points;
    }


    /**
     * 洪泛填充算法(四领域)，非递归
     *
     * @param bitmap    原始图像
     * @param startPos  开始填充点
     * @param fillColor 要填充的颜色
     * @param blockSize 每个测试块中包含点的个数，用于获取每个测试块所包含的轮廓点的个数;
     * @return 返回所有填充点；
     */
    private List<CPoint> floodFill4(Bitmap bitmap, CPoint startPos, int blockSize, int fillColor, int borderColor) throws FloodFillException {
        outlineParts.clear();
        List<CPoint> fillPoints = new ArrayList<CPoint>();
        HashSet<CPoint> borderPoint = new HashSet<CPoint>();

        if (bitmap == null || bitmap.isRecycled()) {
            return fillPoints;
        }

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        if (startPos.x < 0 || startPos.x >= width || startPos.y < 0 || startPos.y >= height) {
            return fillPoints;
        }


        int color = bitmap.getPixel(startPos.x, startPos.y);
        if (color != Color.TRANSPARENT) {
            throw new FloodFillStartPointException("起始点在边界上, 请重新选取!");
        }

        Queue<CPoint> fillQueue = new LinkedBlockingQueue<CPoint>();
        fillQueue.offer(new CPoint(startPos.x, startPos.y));
        boolean[][] mask = new boolean[width][height];

        try {
            int fillCounter = 0, outlineCounter = 0;
            CPoint point = startPos;
            mask[point.x][point.y] = true;
            bitmap.setPixel(point.x, point.y, fillColor);
            fillPoints.add(new CPoint(point.x, point.y));
            CPoint testPoint;
            while (fillQueue.size() > 0 && !Thread.interrupted()
                    && bitmap != null && !bitmap.isRecycled()) {

                point = fillQueue.remove();
                if (point.x <= 0 || point.x >= width || point.y <= 0 || point.y >= height) {
                    throw new FloodFillOutlineExeption("填充区域超边界，填充错误! point = " + point + ", width = " + width + ", height = " + height);
                }

                // 填充当前点的左边点
                testPoint = new CPoint(point.x - 1, point.y);
                if (point.x > 0 && !mask[testPoint.x][testPoint.y]) {
                    color = bitmap.getPixel(testPoint.x, testPoint.y);
                    if (color == 0) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        fillQueue.offer(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (color != fillColor && !borderPoint.contains(testPoint)) {//将轮廓点的个数记录下来
                        borderPoint.add(testPoint);
                        outlineCounter++;
                    }
                }

                // 填充当前点的上边点
                testPoint = new CPoint(point.x, point.y - 1);
                if (point.y > 0 && !mask[testPoint.x][testPoint.y]) {
                    color = bitmap.getPixel(testPoint.x, testPoint.y);
                    if (color == 0) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        fillQueue.offer(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (color != fillColor && !borderPoint.contains(testPoint)) {//将轮廓点的个数记录下来
                        borderPoint.add(testPoint);
                        outlineCounter++;
                    }
                }

                // 填充当前点的右边点
                testPoint = new CPoint(point.x + 1, point.y);
                if (point.x < width - 1 && !mask[testPoint.x][testPoint.y]) {
                    color = bitmap.getPixel(testPoint.x, testPoint.y);
                    if (color == 0) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        fillQueue.offer(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (color != fillColor && !borderPoint.contains(testPoint)) {//将轮廓点的个数记录下来
                        borderPoint.add(testPoint);
                        outlineCounter++;
                    }
                }

                // 填充当前点的下边点
                testPoint = new CPoint(point.x, point.y + 1);
                if (point.y < height - 1 && !mask[testPoint.x][testPoint.y]) {
                    color = bitmap.getPixel(testPoint.x, testPoint.y);
                    if (color == 0) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        fillQueue.offer(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (color != fillColor && !borderPoint.contains(testPoint)) {//将轮廓点的个数记录下来
                        borderPoint.add(testPoint);
                        outlineCounter++;
                    }
                }
            }
            outlineParts.add(Integer.valueOf(outlineCounter));
        } catch (Exception e) {
            Log.e(TAG, "floodFill4: error = " + e.getMessage());
        }

        //填充被中断，则将已填充的点全部清除
        if (fillQueue.size() > 0) {
            fillPoints.clear();
            outlineParts.clear();
        }

        return fillPoints;
    }


    /**
     * 洪泛填充算法(八领域)，非递归,填充顺序
     * @param bitmap 原始图像
     * @param startPos 开始填充点
     * @param blockSize 分块大小
     * @param fillColor 要填充的颜色
     * @param borderColor 边界的颜色
     * @return 所有填充点
     * @throws FloodFillException
     */
    public List<CPoint> floodFill8(Bitmap bitmap, CPoint startPos, int blockSize, int fillColor, int borderColor) throws FloodFillException {
        outlineParts.clear();
        List<CPoint> allFillPoints = new ArrayList<CPoint>();
        HashSet<CPoint> borderPoint = new HashSet<CPoint>();

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        if (startPos.x < 0 || startPos.x >= width || startPos.y < 0 || startPos.y >= height) {
            return allFillPoints;
        }

        int color = bitmap.getPixel(startPos.x, startPos.y);
        if (color != Color.TRANSPARENT) {
            throw new FloodFillStartPointException("起始点在边界上, 请重新选取!");
        }

        // 列表方式
        List<CPoint> fillPoints = new ArrayList<CPoint>();
        fillPoints.add(new CPoint(startPos.x, startPos.y));

        boolean[][] mask = new boolean[width][height];

        try {
            int fillCounter = 0, outlineCounter = 0;
            CPoint point = startPos;
            CPoint prePoint = point;
            CPoint testPoint;
            // 至当前点标志位为1，标识已填充
            mask[point.x][point.y] = true;
            // 填充当前点
            bitmap.setPixel(point.x, point.y, fillColor);

            while (fillPoints.size() > 0) {

                point = getMinDistancePoint(prePoint, fillPoints);
                fillPoints.remove(point);

                if (point.x <= 0 || point.x >= width || point.y <= 0 || point.y >= height) {
                    throw new FloodFillOutlineExeption("填充区域超边界，填充错误! point = " + point + ", width = " + width + ", height = " + height);
                }

                prePoint = point;

                // 填充当前点的[右点]
                testPoint = new CPoint(point.x + 1, point.y);
                if (point.x < width - 1 && mask[testPoint.x][testPoint.y] == false) {
                    color = bitmap.getPixel(testPoint.x, testPoint.y);
                    if (color == Color.TRANSPARENT) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        allFillPoints.add(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (equalIgnoreAlpha(color, borderColor) && !borderPoint.contains(testPoint)) {
                        borderPoint.add(testPoint);
                        outlineCounter++;
                    }
                }

                // 填充当前点的[左点]
                testPoint = new CPoint(point.x - 1, point.y);
                if (point.x > 0 && mask[testPoint.x][testPoint.y] == false) {
                    color = bitmap.getPixel(testPoint.x, testPoint.y);
                    if (color == Color.TRANSPARENT) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        allFillPoints.add(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (equalIgnoreAlpha(color, borderColor) && !borderPoint.contains(testPoint)) {
                        borderPoint.add(testPoint);
                        outlineCounter++;
                    }
                }


                // 填充当前点的[上点]
                testPoint = new CPoint(point.x, point.y - 1);
                if (point.y > 0 && mask[testPoint.x][testPoint.y] == false) {
                    color = bitmap.getPixel(testPoint.x, testPoint.y);
                    if (color == Color.TRANSPARENT) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        allFillPoints.add(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (equalIgnoreAlpha(color, borderColor) && !borderPoint.contains(testPoint)) {
                        borderPoint.add(testPoint);
                        outlineCounter++;
                    }

                }

                // 填充当前点的[左上点]
                testPoint = new CPoint(point.x - 1, point.y - 1);
                if (point.x > 0 && point.y > 0 && mask[testPoint.x][testPoint.y] == false) {
                    int topPointColor = bitmap.getPixel(point.x, point.y - 1);        // 当前点的上边点的颜色
                    int leftPointColor = bitmap.getPixel(point.x - 1, point.y);      // 当前点的左边点的颜色
                    int leftTopPointColor = bitmap.getPixel(testPoint.x, testPoint.y);// 当前点的左上点的颜色
                    if ((!equalIgnoreAlpha(topPointColor, borderColor) || !equalIgnoreAlpha(leftPointColor, borderColor)) && (leftTopPointColor == Color.TRANSPARENT)) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        allFillPoints.add(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (equalIgnoreAlpha(color, borderColor) && !borderPoint.contains(testPoint)) {
                        if (!equalIgnoreAlpha(topPointColor, borderColor) || !equalIgnoreAlpha(leftPointColor, borderColor)) {
                            borderPoint.add(testPoint);
                            outlineCounter++;
                        }
                    }
                }


                // 填充当前点的[右上点]
                testPoint = new CPoint(point.x + 1, point.y - 1);
                if (point.x < width - 1 && point.y > 0 && mask[testPoint.x][testPoint.y] == false) {
                    int topPointColor = bitmap.getPixel(point.x, point.y - 1);        // 当前点的上边点的颜色
                    int rightPointColor = bitmap.getPixel(point.x + 1, point.y);     // 当前点的右边点的颜色
                    int rightTopPointColor = bitmap.getPixel(testPoint.x, testPoint.y);// 当前点的右上点的颜色
                    if ((!equalIgnoreAlpha(topPointColor, borderColor) || !equalIgnoreAlpha(rightPointColor, borderColor)) && (rightTopPointColor == Color.TRANSPARENT)) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        allFillPoints.add(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (equalIgnoreAlpha(color, borderColor) && !borderPoint.contains(testPoint)) {
                        if (!equalIgnoreAlpha(topPointColor, borderColor) || !equalIgnoreAlpha(rightPointColor, borderColor)) {
                            borderPoint.add(testPoint);
                            outlineCounter++;
                        }
                    }
                }

                // 填充当前点的[左下点]
                testPoint = new CPoint(point.x - 1, point.y + 1);
                if (point.x > 0 && point.y < height - 1 && mask[testPoint.x][testPoint.y] == false) {
                    int leftPointColor = bitmap.getPixel(point.x - 1, point.y);      // 当前点的左边点的颜色
                    int bottomPointColor = bitmap.getPixel(point.x, point.y + 1);      // 当前点的下边点的颜色
                    int leftBottomPointColor = bitmap.getPixel(testPoint.x, testPoint.y);// 当前点的左下点的颜色
                    if ((!equalIgnoreAlpha(leftPointColor, borderColor) || !equalIgnoreAlpha(bottomPointColor, borderColor)) && (leftBottomPointColor == Color.TRANSPARENT)) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        allFillPoints.add(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (equalIgnoreAlpha(color, borderColor) && !borderPoint.contains(testPoint)) {
                        if (!equalIgnoreAlpha(leftPointColor, borderColor) || !equalIgnoreAlpha(bottomPointColor, borderColor)) {
                            borderPoint.add(testPoint);
                            outlineCounter++;
                        }
                    }
                }

                // 填充当前点的[右下点]
                testPoint = new CPoint(point.x + 1, point.y + 1);
                if (point.x < width - 1 && point.y < height - 1 && mask[testPoint.x][testPoint.y] == false) {
                    int rightPointColor = bitmap.getPixel(point.x + 1, point.y);     // 当前点的右边点的颜色
                    int bottomPointColor = bitmap.getPixel(point.x, point.y + 1);      // 当前点的下边点的颜色
                    int rightBottomPointColor = bitmap.getPixel(testPoint.x, testPoint.y);// 当前点的右下点的颜色
                    if ((!equalIgnoreAlpha(rightPointColor, borderColor) || !equalIgnoreAlpha(bottomPointColor, borderColor)) && (rightBottomPointColor == Color.TRANSPARENT)) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        allFillPoints.add(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (equalIgnoreAlpha(color, borderColor) && !borderPoint.contains(testPoint)) {
                        if (!equalIgnoreAlpha(rightPointColor, borderColor) || !equalIgnoreAlpha(bottomPointColor, borderColor)) {
                            borderPoint.add(testPoint);
                            outlineCounter++;
                        }
                    }
                }

                // 填充当前点的[下点]
                testPoint = new CPoint(point.x, point.y + 1);
                if (point.y < height - 1 && mask[testPoint.x][testPoint.y] == false) {
                    color = bitmap.getPixel(testPoint.x, testPoint.y);
                    if (color == Color.TRANSPARENT) {
                        fillCounter++;
                        if (fillCounter == blockSize) {
                            outlineParts.add(Integer.valueOf(outlineCounter));
                            fillCounter = 0;
                            outlineCounter = 0;
                        }
                        bitmap.setPixel(testPoint.x, testPoint.y, fillColor);
                        fillPoints.add(testPoint);
                        allFillPoints.add(testPoint);
                        mask[testPoint.x][testPoint.y] = true;
                    } else if (equalIgnoreAlpha(color, borderColor) && !borderPoint.contains(testPoint)) {
                        borderPoint.add(testPoint);
                        outlineCounter++;
                    }
                }
            }
            outlineParts.add(Integer.valueOf(outlineCounter));
        } catch (Exception e) {
            Log.e(TAG, "floodFill8: error = " + e.getMessage());
        }
        //填充被中断，则将已填充的点全部清除
        if (fillPoints.size() > 0) {
            allFillPoints.clear();
            outlineParts.clear();
        }

        return allFillPoints;
    }

    private boolean equalIgnoreAlpha(int color, int border) {
        return (color & 0x00ffffff) == border;
    }

    /**
     * 计算两点距离
     * @param p1 起点
     * @param p2 终点
     * @return
     */
    private static double getDistance(CPoint p1, CPoint p2) {
        int x = Math.abs(p2.x - p1.x);
        int y = Math.abs(p2.y - p1.y);
        return Math.sqrt(x * x + y * y);
    }

    private CPoint getMinDistancePoint(CPoint p, List<CPoint> fillPoints) {
        if (fillPoints.size() == 1) {
            return fillPoints.get(0);
        }

        CPoint point = new CPoint();
        double minDistance = Double.MAX_VALUE;
        for (CPoint cp : fillPoints) {
            double distance = getDistance(p, cp);
            if (distance < minDistance) {
                minDistance = distance;
                point = cp;
            }
        }

        return point;
    }


    //----------------
    private void disabledHint(String method) {
        String msg = "[" + method + "] method is disabled in " + TAG;
        Log.e(TAG, msg);
        throw new RuntimeException(msg);
    }

    @Deprecated
    @Override
    public void add(CPoint point) {
        disabledHint("add");
    }

    @Deprecated
    @Override
    public CPoint get(int index) {
        disabledHint("get");
        return null;
    }

    @Deprecated
    @Override
    public List<CPoint> getPoints() {
        disabledHint("getPoints");
        return null;
    }

    public int getCount() {
        return lines.size();
    }

    @Deprecated
    @Override
    public void reverse() {
        disabledHint("reverse");
    }

    @Override
    public String toString() {
        return "" + getBishun() + "|" + startPoint + "|" + lines.toString();
    }

    public class FloodFillException extends Exception {
        public FloodFillException(String msg) {
            super(msg);
        }
    }

    public class FloodFillStartPointException extends FloodFillException {
        public FloodFillStartPointException(String msg) {
            super(msg);
        }
    }

    public class FloodFillOutlineExeption extends FloodFillException {
        public FloodFillOutlineExeption(String msg) {
            super(msg);
        }
    }

}
