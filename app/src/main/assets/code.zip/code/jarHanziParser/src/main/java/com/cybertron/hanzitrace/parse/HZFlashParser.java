package com.cybertron.hanzitrace.parse;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import com.cybertron.account.book.Book;
import com.cybertron.account.util.RandomReader;
import com.cybertron.encdes.EncDes;
import com.cybertron.enclib.EncTools;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;

/**
 * 汉字动画解析类
 * @author SXK
 *
 */
public class HZFlashParser {

	private static final String TAG = HZFlashParser.class.getSimpleName(); 
	
	private static HZFlashParser hzFlashParser = null;
	
	private RandomReader mReader; 
	
	private SQLiteDatabase mFlashSqLiteDatabase;
	
	public static void initialize(Context context,String dbpath){
		if(hzFlashParser == null){
			hzFlashParser = new HZFlashParser(context,dbpath);
		}
	}
	
	public static HZFlashParser getInstance(){
		check();
		return hzFlashParser;
	}

	private static void check() {
		if(hzFlashParser == null){
			throw new RuntimeException("Please call HZFlashParser.initialize() first!!");
		}
	}
	
	public HZFlashParser(Context context, String dbpath) {
		creatFlashDbSqliteDatabase(dbpath);
	}

	/**
	 * 创建flash数据库
	 * @param dbpath
	 */
	private void creatFlashDbSqliteDatabase(String dbpath){
		mFlashSqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(dbpath, null); 
	}
	
	/**
	 * 初始化flash动画库
	 * @param baskey
	 * @param baspath
	 */
	public void initFlashBasinfo( String baskey,String baspath){
		try {
			mReader = new RandomReader(baspath, Charset.defaultCharset());
			if (TextUtils.isEmpty(baskey)) {
				baskey = EncTools.readKey(baspath);
			}
			EncDes enc = EncDes.create(baspath, baskey);
			mReader.setEncDes(enc);
		} catch (Exception e) {
			e.printStackTrace();
			Log.e(TAG, "汉字学习Flash数据异常!");
		}
	}
	
	/**  
	 * 根据汉字获取flash的封面
	 * @param word
	 * @return
	 */
	public byte[] getFlashCover(String word){
		byte[] coverbuf = null;
		long begin = 0;
		long end = 0;
		
		if(mFlashSqLiteDatabase != null){
			String sql = "select * from " + Config.FLASH_DB_TABLE_NAME +" where Word like '"+word+"'";
			Cursor cursor = null;
			try {
				cursor = mFlashSqLiteDatabase.rawQuery(sql, null);
				if(cursor.moveToNext()){
					begin = cursor.getLong(cursor.getColumnIndex(Config.FLASH_COVER_ADDR_BRGIN));
					end = cursor.getLong(cursor.getColumnIndex(Config.FLASH_COVER_ADDR_END));
				}
				coverbuf = getFlashDataBuffer(begin, (int) (end - begin));
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(cursor != null)
					cursor.close();
			}
			
		}
		return coverbuf;
	}
	
	/**
	 * 汉字是否存在flash
	 * @param word 
	 * @return
	 */
	public boolean isExistFlash(String word){
		boolean isexist = false;
		if(mFlashSqLiteDatabase != null){
			String sql = "select * from " + Config.FLASH_DB_TABLE_NAME +" where Word like '"+word+"'";
			Cursor cursor = null;
			try {
				cursor = mFlashSqLiteDatabase.rawQuery(sql, null);
				if(cursor.moveToNext()){
					isexist = true;
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(cursor != null)
					cursor.close();
			}
			
		}
		return isexist;
	}
	
	/**
	 * 前往书城下载
	 * @param context
	 * @param books
	 */
	public void startStoreDownload(Context context, List<Book> books) {
		try {
			Intent intent = new Intent();
			intent.setAction("cybertron.intent.action.BOOKSTORE_DOWNLOAD");
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.putParcelableArrayListExtra("books",(ArrayList<? extends Parcelable>) books);
			context.startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	
	/**
	 * 获取flash数据
	 * @param word
	 * @return
	 */
	public byte[] getFlashData(String word){
		byte[] flashdata = null;
		
		long begin = 0;
		long end = 0;
		
		if(mFlashSqLiteDatabase != null){
			String sql  = "select * from "+Config.FLASH_DB_TABLE_NAME + " where Word like '"+word+"'";
			Cursor cursor = null;
			try {
				cursor = mFlashSqLiteDatabase.rawQuery(sql, null);
				if(cursor.moveToNext()){
					begin = cursor.getLong(cursor.getColumnIndex(Config.FLASH_ADDR_BEGIN));
					end = cursor.getLong(cursor.getColumnIndex(Config.FLASH_ADDR_END));
				}
				flashdata = getFlashDataBuffer(begin, (int)(end - begin));
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(cursor != null){
					cursor.close();
				}
			}
		}
		
		return flashdata;
	}
	
	/**
	 * 获取flash数据
	 * @return
	 */
	private byte[] getFlashDataBuffer(long offset,int length){
		byte[] buf = null;
		try {
			buf = mReader.readData(offset, length);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buf;
	}
	
	/**
	 * 关闭数据库
	 */
	public void closeDataBase(){
		if(mFlashSqLiteDatabase != null)
			mFlashSqLiteDatabase.close();
		
		hzFlashParser = null;
	}
	
}
