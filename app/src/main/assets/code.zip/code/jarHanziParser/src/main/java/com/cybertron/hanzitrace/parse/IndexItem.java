package com.cybertron.hanzitrace.parse;

import com.cybertron.account.util.EndianUtils;


public class IndexItem {
	private static final String TAG = IndexItem.class.getSimpleName();
	
	public static final int SIZE = 2+1+2+4;
	
	public char ch;
	public int grade;
	public int order;
	public int addr;
	
	public IndexItem(char ch, int grade, int order, int addr) {
		this.ch = ch;
		this.grade = grade;
		this.order = order;
		this.addr = addr;
	}
	
	@Override
	public String toString() {
		String code = Integer.toHexString(
				EndianUtils.le.charToShort(ch, Config.charset));
		return code+'|'+ch+'|'+grade+'|'+order;
	}
}
