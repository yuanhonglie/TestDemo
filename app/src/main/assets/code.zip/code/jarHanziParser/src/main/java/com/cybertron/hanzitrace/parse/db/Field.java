package com.cybertron.hanzitrace.parse.db;

public interface Field {
	String _id        = "_id";        //INTEGER primary key autoincrement 自增字段
	String grade      = "grade";      //INT 年级
	String order      = "_order";     //INT 在本年级的排序
	String character  = "character";  //TEXT 字
	String radical    = "radical";    //TEXT 部首
	String structure  = "structure";  //TEXT 结构
	String spell      = "spell";      //TEXT 拼音
	String strokeCount="strokeCount";//int 笔画数
	String bishun     = "bishun";    //TEXT 笔顺
	String strokes    ="strokes";    //BOLD 描红数据：笔画1点数N1(2B)+笔画2点数N2(2B)+...+笔画n点数NN(2B) 
									 //+笔画1笔点的坐标信息(N1*2B[x,y])+...+笔画N笔点的坐标信息(NN*2B[x,y])
}
