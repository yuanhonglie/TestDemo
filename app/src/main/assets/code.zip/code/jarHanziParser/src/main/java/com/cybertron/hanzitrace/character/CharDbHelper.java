package com.cybertron.hanzitrace.character;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;
import android.util.Log;

public class CharDbHelper extends SQLiteOpenHelper {
	public static final String TAG = "CharDbHelper";
	public static final String TABLE = "NewWords1";
	private static final int DATABASE_VERSION = 2;
	public CharDbHelper(Context context, String dbPath) {
		super(context, dbPath, null, DATABASE_VERSION);
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		Log.i(TAG, "onUpgrade ---> oldVersion = " + oldVersion + ", newVersion = " + newVersion);
		onCreate(db);
	}
	
	@Override
	public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.i(TAG, "onDowngrade ---> oldVersion = " + oldVersion + ", newVersion = " + newVersion);
		onCreate(db);
	}
	
	public List<Phrase> getPhrases(ChnCharacter ch) {
		String phraseStr = null;
		List<Phrase> phrases = new ArrayList<Phrase>();
		SQLiteDatabase db = null;
		Cursor c = null;
		try {
			db = getReadableDatabase();
			String selection = CharDbField.word + "=? and " + CharDbField.phonetic + "=?";
			String[] args = new String[]{ch.getChar(), ch.getSpell()};
			String[] columns = new String[]{CharDbField.phrase};
			c = db.query(TABLE, columns, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					byte[] phraseBuf = c.getBlob(0);
					if (phraseBuf != null) {
						phraseStr = new String(phraseBuf, Charset.forName("GBK"));
					}
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
//			e.printStackTrace();
		} finally {
			if (c != null) c.close();
			if (db != null) db.close();
		}
		
		if (!TextUtils.isEmpty(phraseStr)) {
			phrases = Phrase.valueOfArrayString(phraseStr);
		}
		return phrases;
	}
	
	/**
	 * 获取汉字的造句
	 * @param word
	 * @return
	 */
	public String getSentence(String word){
		String sentenceStr = "";
		SQLiteDatabase db = null;
		Cursor c = null;
		try {
			db = getReadableDatabase();
			String selection = CharDbField.word + "=? ";
			String[] args = new String[]{word};
			String[] columns = new String[]{CharDbField.sentence};
			c = db.query(TABLE, columns, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					byte[] sentenceBuf = c.getBlob(0);
					if (sentenceBuf != null){
						sentenceStr = new String(sentenceBuf, Charset.forName("GBK"));
					}
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if (c != null) c.close();
			if (db != null) db.close();
		}
		
		if(!TextUtils.isEmpty(sentenceStr)){
			String[] phraseStrs = sentenceStr.split("\n");
			StringBuilder sb = new StringBuilder();
			if(phraseStrs != null){
				if(phraseStrs.length > 10){
					for (int i = 0; i < 10; i++) {
						sb.append(phraseStrs[i]).append("\n");
					}
					
				}else{
					for (int i = 0; i < phraseStrs.length; i++) {
						sb.append(phraseStrs[i]).append("\n");
					}
				}
			}
			
			if(!TextUtils.isEmpty(sb.toString())){
				sentenceStr = sb.toString();
			}
		}
		
		return sentenceStr;
	}
	
	/**
	 * 获取汉字的词组
	 * @param word
	 * @param phonetic
	 * @return
	 */
	public String getPhrases(String word,String phonetic){
		String phraseStr = "";
		SQLiteDatabase db = null;
		Cursor c = null;
		try {
			db = getReadableDatabase();
			String selection = CharDbField.word + "=? and " + CharDbField.phonetic + "=?";
			String[] args = new String[]{word, phonetic};
			String[] columns = new String[]{CharDbField.phrase};
			c = db.query(TABLE, columns, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					byte[] phraseBuf = c.getBlob(0);
					if (phraseBuf != null) {
						phraseStr = new String(phraseBuf, Charset.forName("GBK"));
					}
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (c != null) c.close();
			if (db != null) db.close();
		}
		if(!TextUtils.isEmpty(phraseStr)){
			StringBuilder sb = new StringBuilder();
			
			sb.append("[组词]").append(phraseStr);
			
//			String [] phraseStrs = phraseStr.split(";");			
//			if(phraseStrs != null){
//				if(phraseStrs.length > 10){
//					for (int i = 0; i < 10; i++) {
//						sb.append(phraseStrs[i]).append("\n");
//					}
//				}else{
//					for (int i = 0; i < phraseStrs.length; i++) {
//						sb.append(phraseStrs[i]).append("\n");
//					}
//				}
//			}

			if(!TextUtils.isEmpty(sb.toString())){
				phraseStr = sb.toString();
			}
		}
		
		return phraseStr;
	}
	
	
}
