package com.cybertron.hanzitrace.widget;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.text.TextPaint;
import android.util.Log;
import android.util.SparseArray;

import com.cybertron.account.util.ListUtils;
import com.cybertron.hanzitrace.parse.CPoint;
import com.cybertron.hanzitrace.parse.Stroke;
import com.cybertron.hanzitrace.parse.newdb.NewStroke;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/8/2.
 */

public class UserStrokePath {
    private static final String TAG = "UserStrokePath";
    private static final float TOUCH_TOLERANCE = 4;
    private static final int MIN_PART_NUM = 5;
    private static final int MAX_INVALID_DOT = 50;
    private static final int GRANTED_SCORE = 70;
    /**
     * 用户书写笔迹采样点的步进值，即两个采样点之间的距离。
     * 此值越小，获取的笔迹采样点越多，计算精度越高，
     * 同时计算笔画分数的过程耗时也会越长。
     */
    private static final int USER_STROKE_SAMPLE_STEP = 1;
    private volatile long id;
    /**
     * 用户书写笔迹，会对笔迹进行平滑处理
     */
    private Path mUserStrokePath;
    /**
     * 用户真实书写笔迹
     */
    private Path mUserRawPath;
    private int prevX, prevY;
    private int xOffset, yOffset;

    private DemonstrateStrokeTask.IDemonstrateStrategy mStrategy;
    private UserStrokeResult mResult;
    private Paint mPaint, mTxtPaint;

    public UserStrokePath(DemonstrateStrokeTask.IDemonstrateStrategy strategy) {
        mUserStrokePath = new Path();
        mUserRawPath = new Path();
        mStrategy = strategy;
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(1);
        mTxtPaint = new TextPaint();
        mTxtPaint.setAntiAlias(true);
        mTxtPaint.setTextSize(20);
        mTxtPaint.setColor(Color.RED);
    }

    /**
     * 获取书写笔迹id
     *
     * @return
     */
    public long getId() {
        return id;
    }

    public void setOffset(int x, int y) {
        xOffset = x;
        yOffset = y;
    }

    /**
     * 设置书写笔迹的起点
     *
     * @param x
     * @param y
     */
    public void moveTo(int x, int y) {
        x -= xOffset;
        y -= yOffset;

        reset();
        mUserStrokePath.moveTo(x, y);
        mUserRawPath.moveTo(x, y);
        prevX = x;
        prevY = y;
    }

    /**
     * 将书写笔迹移动到指定点
     *
     * @param x
     * @param y
     */
    public void lineTo(int x, int y, boolean touchUp) {
        int nx = x - xOffset;
        int ny = y - yOffset;
        int dx = Math.abs(nx - prevX);
        int dy = Math.abs(ny - prevY);

        if (mUserStrokePath.isEmpty()) {
            moveTo(x, y);
        } else {
            if (dx > TOUCH_TOLERANCE || dy > TOUCH_TOLERANCE) {
                mUserStrokePath.quadTo(prevX, prevY, (nx + prevX) / 2, (ny + prevY) / 2);
                prevX = nx;
                prevY = ny;
            } else {
                if (touchUp) {
                    mUserStrokePath.lineTo(nx, ny);
                }
            }
            mUserRawPath.lineTo(nx, ny);
        }
    }

    /**
     * 清空书写笔迹
     */
    private void reset() {
        reset(xOffset, yOffset);
    }

    /**
     * 清空书写笔迹
     * @param x 笔迹的起始坐标相对于View的原点x坐标偏移
     * @param y 笔迹的起始坐标相对于View的原点y坐标偏移
     */
    public void reset(int x, int y) {
        //这里不将书写笔迹结果清空是为了在每次书写完毕都能显示书写笔迹的调试信息，
        //便于调试分析
        //mResult = null;
        mUserStrokePath.reset();
        mUserRawPath.reset();
        id = System.currentTimeMillis();
        setOffset(x, y);
    }

    /**
     * 判断书写笔迹是否为空
     *
     * @return
     */
    public boolean isEmpty() {
        return mUserStrokePath.isEmpty();
    }

    /**
     * 绘制书写笔迹
     *
     * @param canvas
     * @param paint
     */
    public void draw(Canvas canvas, Paint paint) {
        draw(canvas, paint, true);
    }

    /**
     * 绘制书写笔迹
     *
     * @param canvas
     * @param paint
     * @param showStrokeMsgInDebugMode
     */
    private void draw(Canvas canvas, Paint paint, boolean showStrokeMsgInDebugMode) {
        //显示笔画信息
        drawStrokeMsg(canvas, showStrokeMsgInDebugMode);
        if (isEmpty()) {
            return;
        }
        if (mStrategy.isDebugEnabled()) {
            //当且仅当书写结果与当前书写笔迹一致时，才显示笔迹调试详情，
            // 避免在书写过程中频繁绘制而导致书写笔迹跟随效果不好的问题；
            if (mResult != null && mResult.pathId == getId()) {
                SparseArray<Integer> colorMap = new SparseArray<Integer>();
                if (!ListUtils.isEmpty(mResult.validBlocks)) {
                    for (int i = 0; i < mResult.validBlocks.size(); i++) {
                        int block = mResult.validBlocks.get(i);
                        int[] colors = mStrategy.getDebugBlockColors();
                        int color = colors[i % colors.length];
                        colorMap.put(block, color);
                    }
                }

                for (int i = 0; i < mResult.testBlockSize; i++) {
                    Integer color = colorMap.get(i);
                    if (color == null) {
                        color = Color.RED;
                    }
                    mPaint.setColor(color);
                    drawStrokeBlock(canvas, mResult.fillPoints, i, mResult.dotSizePerBlock, mPaint);
                }
            }
            mPaint.setColor(Color.BLACK);
            canvas.drawPath(mUserRawPath, mPaint);
        } else {
            canvas.drawPath(mUserStrokePath, paint);
//            canvas.drawPath(mUserRawPath, mPaint);
        }
    }

    private void drawStrokeMsg(Canvas canvas, boolean showStrokeMsg) {
        //调试信息格式说明：
        //block:[每个测试块的点阵数],[笔画测试块总数],[命中的测试块总数],[[第一个命中的测试块序号]-[最后一个命中的测试块序号]],[命中的测试块序号列表]
        //input:[笔迹采样点总数],[[第一个有效的笔迹点序号]-[最后一个有效的笔迹点序号]]
        //score:[分数]（对于测试块数小于等于MIN_PART_NUM时，不以分数值作为判断笔画是否正确的标准，命中的测试块超过一半即认为正确）
        //time:[计分过程所消耗的时间]
        if (mResult != null && mStrategy.isDebugEnabled() && showStrokeMsg) {
            int xStart = 10, yStart = 10;
            int yPos = (int) mTxtPaint.getTextSize() + 2;
            String blockInfo = "block:" + mResult.dotSizePerBlock + "," + mResult.testBlockSize + ","
                    + (ListUtils.isEmpty(mResult.validBlocks) ? 0 : mResult.validBlocks.size()) + ",["
                    + mResult.firstOkBlockIndex + "-" + mResult.lastOkBlockIndex + "], " + mResult.validBlocks;
            canvas.drawText(blockInfo, xStart, yStart + yPos, mTxtPaint);
            String inputInfo = "input:" + mResult.totalInputSize + "，["
                    + mResult.firstAcceptedDotIndex + "-" + mResult.lastAcceptedDotIndex + "]";
            canvas.drawText(inputInfo, xStart, yStart + yPos * 2, mTxtPaint);
            canvas.drawText("score:" + mResult.score, xStart, yStart + yPos * 3, mTxtPaint);
            canvas.drawText("time:" + mResult.escapedTime, xStart, yStart + yPos * 4, mTxtPaint);
        }
    }

    private void drawStrokeBlock(Canvas canvas, List<CPoint> points, int index, int blockSize, Paint paint) {
        int start = index * blockSize;
        int end = start + blockSize;
        if (end > points.size()) {
            end = points.size();
        }
        List<CPoint> subPoints = points.subList(start, end);
        for (CPoint point : subPoints) {
            canvas.drawPoint(point.x, point.y, paint);
        }
    }

    public void draw(Bitmap bitmap, Paint paint) {
        if (bitmap != null && !bitmap.isRecycled()) {
            Canvas mCanvas = new Canvas(bitmap);
            draw(mCanvas, paint, false);
        }
    }

    /**
     * 判断书写笔迹是否正确
     * <br>
     *     这里说明两个概念：
     *     <em>测试块：</em>将笔画的填充点按填充顺序分成若干等分，每份填充点构成的集合就是一个测试块。
     *     测试块的填充点的数目可以通过{@link DemonstrateStrokeTask.IDemonstrateStrategy}
     *     的getTestDotsSize()方法进行配置。
     *     <em>笔迹点：</em>将用户的书写笔迹按照书写顺序进行采集，得到一个有序的点集。
     * </br>
     * <br>
     *     如果一个测试块中包含了笔迹采样点则称这个测试块被命中，否则称为未命中的测试块；
     *     如果一个笔迹采样点被某个测试块包含，则称为有效笔迹点，否则称为无效笔迹点。
     * </br>
     * @param stroke 笔画
     * @return true-正确，false-错误
     */
    public boolean evaluate(Stroke stroke) {
        mResult = new UserStrokeResult();
        mResult.pathId = getId();
        int correctRectNum = 0;
        long startTime = System.currentTimeMillis();
        Log.i(TAG, "evaluate: ========================");
        try {
            //获取当前笔画所有填充点；
            NewStroke newStroke = (NewStroke) stroke;
            mResult.fillPoints = newStroke.getStrokeFillPoints(mStrategy.getFloodFillLayer(), mStrategy);
            int totalFillSize = mResult.fillPoints.size();
            List<Integer> outlineParts = ((NewStroke) stroke).getOutlineParts();

            //将填充点分成N等分，每份的填充点数由设置IDemonstrateStrategy.getTestDotsSize();
            // 如果最后余下的点数多于半分填充点数，则算作一份，否则不算；
            mResult.dotSizePerBlock = mStrategy.getTestDotsSize();
            mResult.testBlockSize = (totalFillSize + (mResult.dotSizePerBlock*3)/4) / mResult.dotSizePerBlock;
//            mResult.testBlockSize = (totalFillSize + mResult.dotSizePerBlock) / mResult.dotSizePerBlock;
            //获取用户的书写笔迹点；
            List<CPoint> inputPoints = getUserInputPoints(mUserRawPath);
            mResult.totalInputSize = inputPoints.size();

            Log.i(TAG, "evaluate: mTestBlockSize = " + mResult.testBlockSize + ", mFilledInputSize = " + mResult.totalInputSize + ", outlineParts = " + outlineParts.size());
            mResult.validBlocks = new ArrayList<Integer>();

            int start = 0;
            int outlinePartLength = 0;
            for (int i = 0; i < mResult.testBlockSize; i++) {
                int blockStart = i * mResult.dotSizePerBlock;
                int blockEnd = blockStart + mResult.dotSizePerBlock;
                if (blockEnd > totalFillSize) {
                    blockEnd = totalFillSize;
                }

                boolean found = false;
                int invalidInputDots = 0;
                int validInputDots = 0;

                outlinePartLength = i < outlineParts.size() ? outlineParts.get(i) : 0;
                Log.i(TAG, "evaluate: oulinePartLegth["+i+"] = " + outlinePartLength);
                if (i == 0 || i == mResult.testBlockSize -1) {
                    outlinePartLength = outlinePartLength/4;
                } else {
                    outlinePartLength = outlinePartLength/3;
                }

                List<CPoint> block = mResult.fillPoints.subList(blockStart, blockEnd);
                for (int j = start; j < mResult.totalInputSize; j++) {
                    CPoint p = inputPoints.get(j);
                    boolean inBlock = isInBlock(block, p);

                    if (inBlock) {
                        if (!found) {
                            found = true;//找到位于测试块中的有效笔迹点
                        }

                        if (mResult.firstAcceptedDotIndex == -1) {
                            mResult.firstAcceptedDotIndex = j;
                        }
                        mResult.lastAcceptedDotIndex = j;

                        validInputDots++;
                        start = j + 1;//更新笔迹点起始序号，下个测试块从这个笔迹点开始查找
                        if (start == mResult.totalInputSize) {
                            Log.i(TAG, "evaluate: last block validInputDots = " + validInputDots);
                            if (validInputDots > outlinePartLength*4/5) {
                                mResult.validBlocks.add(i);
                                if (mResult.firstOkBlockIndex == -1) {
                                    mResult.firstOkBlockIndex = i;
                                }
                                mResult.lastOkBlockIndex = i;
                            } else {
                                Log.e(TAG, "evaluate: skip block[" + i + "] because block was covered less then 80%! validInputDots = " + validInputDots + ", outlinePartLength = " + outlinePartLength);
                            }
                        }
                    } else {
                        invalidInputDots++;
                        if (found) {
                            //找到一个无效笔迹点，在这个笔迹点之前，有一个或多个有效笔迹点；
                            //跳到下一个测试块继续查找；
                            Log.i(TAG, "evaluate: validInputDots = " + validInputDots);
                            if (validInputDots >= outlinePartLength*4/5) {
                                mResult.validBlocks.add(i);
                                if (mResult.firstOkBlockIndex == -1) {
                                    mResult.firstOkBlockIndex = i;
                                }
                                mResult.lastOkBlockIndex = i;

                            } else {
                                Log.e(TAG, "evaluate: skip block[" + i + "] because block was covered less then 80%! validInputDots = " + validInputDots + ", outlinePartLength = " + outlinePartLength);
                            }
                            break;
                        } else {
                            //当无效笔迹点太多时，放弃这个测试块，从下一个测试块中查找；
                            //1.开始位置无效笔迹点数超过总笔迹点数1/5时，认为书写错误；
                            //2.开始位置无效笔迹点数超过MAX_INVALID_DOT时，认为书写错误；
    //                        Log.i(TAG, "evaluate: invalidInputDots = " + invalidInputDots);
                            if (invalidInputDots > mResult.totalInputSize / 5 || (invalidInputDots >= MAX_INVALID_DOT)) {
                                Log.e(TAG, "evaluate: too many invalid dots at the beginning!!");
                                break;
                            }
                        }
                    }
                }

                //开始位置未命中测试块数超过测试块总数的1/5时，认为书写错误；
                if ((i > mResult.testBlockSize / 5) && (mResult.firstOkBlockIndex == -1)) {
                    Log.e(TAG, "evaluate: too many rects were not reached at the beginning!!");
                    return mResult.result;
                }
            }

            //书写笔迹开始部分无效笔迹点太多，超过MAX_INVALID_DOT时，则认为书写错误；
            if (mResult.firstAcceptedDotIndex > MAX_INVALID_DOT) {
                Log.e(TAG, "evaluate: Too many INVALID dots at the beginning");
                return mResult.result;
            }

            //书写笔迹结束部分无效笔迹点太多，超过MAX_INVALID_DOT时；
            if (mResult.lastAcceptedDotIndex < (mResult.totalInputSize - MAX_INVALID_DOT)) {
                int unAcceptedDots = mResult.totalInputSize - mResult.lastAcceptedDotIndex;
                start = mResult.totalInputSize;
                Log.i(TAG, "evaluate: unAcceptedDots1 = " + unAcceptedDots);
                for (int i = mResult.testBlockSize; i > mResult.testBlockSize*4/5; i--) {
                    int blockIndex = i - 1;
                    int blockStart = blockIndex * mResult.dotSizePerBlock;
                    int blockEnd = blockStart + mResult.dotSizePerBlock;
                    if (blockEnd > totalFillSize) {
                        blockEnd = totalFillSize;
                    }

                    boolean found = false;
                    int invalidInputDots = 0;
                    List<CPoint> block = mResult.fillPoints.subList(blockStart, blockEnd);
                    for (int j = start; j > mResult.lastAcceptedDotIndex + 1; j--) {
                        int inputIndex = j - 1;
                        CPoint p = inputPoints.get(inputIndex);
                        boolean inBlock = isInBlock(block, p);

                        if (inBlock) {
                            if (!found) {
                                found = true;//找到位于测试块中的有效笔迹点
                            }

                            unAcceptedDots--;
                            start = inputIndex;//更新笔迹点起始序号，下个测试块从这个笔迹点开始查找
                        } else {
                            invalidInputDots++;
                            if (found) {
                                //找到一个无效笔迹点，在这个笔迹点之前，有一个或多个有效笔迹点；
                                //跳到下一个测试块继续查找；
                                break;
                            } else {
                                //当无效笔迹点太多时，放弃这个测试块，从下一个测试块中查找；
                                //1.开始位置无效笔迹点数超过总笔迹点数1/5时，认为书写错误；
                                //2.开始位置无效笔迹点数超过MAX_INVALID_DOT时，认为书写错误；
                                if (invalidInputDots > mResult.totalInputSize / 5 || (invalidInputDots >= MAX_INVALID_DOT)) {
                                    Log.e(TAG, "evaluate: too many invalid dots at the beginning 2 !!");
                                    break;
                                }
                            }
                        }
                    }
                }

                Log.i(TAG, "evaluate: at the end of input path, unAcceptedDots = " + unAcceptedDots);
                if (unAcceptedDots > MAX_INVALID_DOT) {
                    Log.e(TAG, "evaluate: Too many INVALID dots at the end");
                    return mResult.result;
                }
            }

            if (mResult.testBlockSize > MIN_PART_NUM) {
                //当测试块的数目大于MIN_PART_NUM，如果结束位置的未命中的测试块数大于总测试块数的1/5，
                //则认为书写错误，否则执行下一步的计分操作；
                if (mResult.lastOkBlockIndex < (mResult.testBlockSize * 4) / 5) {
                    Log.e(TAG, "evaluate: too many rects were not reached at the end1!!");
                    return mResult.result;
                }
            } else {
                //当测试块数目小于MIN_PART_NUM时，如果以测试块命中数占测试块总数的百分比来作为分数，
                //某些笔画计算的分数会非常低，可能很难书写正确，所以这里对测试块数目小于MIN_PART_NUM的进行特别处理；
                //当测试块的数目太少，小于或等于MIN_PART_NUM时，只要命中测试块的数目大于等于总测试块数的一半时，
                //就认为书写是正确的，否则认为错误。

                if (mResult.validBlocks.size() >= (mResult.testBlockSize+1) / 2) {
                    Log.i(TAG, "evaluate: testBlockSize = " + mResult.testBlockSize + ", correctRectNum = " + mResult.validBlocks.size());
                    mResult.result = true;
                    return mResult.result;
                } else {
                    Log.e(TAG, "evaluate: too many rects were not reached!!");
                    return mResult.result;
                }
            }

            //以测试块命中数占测试块总数的百分比来作为分数，当分数大于或等于GRANTED_SCORE时，
            // 则认为书写正确，否则书写错误；
            correctRectNum = mResult.validBlocks.size();
            mResult.score = (correctRectNum * 100) / mResult.testBlockSize;
            if (mResult.score >= GRANTED_SCORE) {
                mResult.result = true;
            }
        } catch (NewStroke.FloodFillException e) {
            Log.e(TAG, "evaluate: getStrokeFillPoints", e);
        } finally {
            mResult.escapedTime = System.currentTimeMillis() - startTime;
        }
        Log.i(TAG, "evaluate: escapedTime = " + mResult.escapedTime);

        Log.i(TAG, "evaluate: testBlockSize = " + mResult.testBlockSize + ", correctRectNum = " + correctRectNum + ", score = " + mResult.score);
        Log.i(TAG, "evaluate: firstOkBlockIndex = " + mResult.firstOkBlockIndex);
        Log.i(TAG, "evaluate: lastOkBlockIndex = " + mResult.lastOkBlockIndex);
        Log.i(TAG, "evaluate: firstAcceptedDotIndex = " + mResult.firstAcceptedDotIndex);
        Log.i(TAG, "evaluate: lastAcceptedDotIndex = " + mResult.lastAcceptedDotIndex);
        Log.i(TAG, "evaluate: validBlocks = " + mResult.validBlocks);
        Log.i(TAG, "evaluate: testBlockSize = " + mResult.testBlockSize);

        return mResult.result;
    }

    class UserStrokeResult {
        /**
         * 此书写结果对应的书写笔迹id；
         */
        long pathId;
        /**
         * 结果，正确or错误
         */
        boolean result = false;
        /**
         * 分数
         */
        int score;
        /**
         * 第一个命中的测试块序号；
         */
        int firstOkBlockIndex = -1;
        /**
         * 最后一个命中的测试块序号；
         */
        int lastOkBlockIndex = -1;
        /**
         * 第一个有效笔迹点；
         */
        int firstAcceptedDotIndex = -1;
        /**
         * 最后一个有效笔迹点；
         */
        int lastAcceptedDotIndex = -1;
        /**
         * 笔画的所有填充点
         */
        List<CPoint> fillPoints;
        /**
         * 每个测试块中的点个数
         */
        int dotSizePerBlock;
        /**
         * 命中的测试块列表
         */
        List<Integer> validBlocks;
        /**
         * 测试块个数
         */
        int testBlockSize;
        /**
         * 书写笔迹的点数
         */
        int totalInputSize;
        /**
         * 评估笔迹所消耗的时间，单位为毫秒
         */
        long escapedTime;
    }


    /**
     * 判断p点是否包含在测试块中
     *
     * @param block
     * @param p
     * @return
     */
    private boolean isInBlock(List<CPoint> block, CPoint p) {
        for (CPoint point : block) {
            if (point.equals(p)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取用户书写笔迹中的点集，
     * 可以通过调整{@link #USER_STROKE_SAMPLE_STEP}的值来调整点集疏密程度。
     *
     * @param mUserRawPath
     * @return
     */
    private List<CPoint> getUserInputPoints(Path mUserRawPath) {
        List<CPoint> points = new ArrayList<CPoint>();
        PathMeasure measure = new PathMeasure(mUserRawPath, false);
        int length = (int) measure.getLength();
        float[] pos = new float[2];
        for (int i = 0; i < length; i += USER_STROKE_SAMPLE_STEP) {
            measure.getPosTan(i, pos, null);
            CPoint point = new CPoint((int) pos[0], (int) pos[1]);
            points.add(point);
        }
        return points;
    }
}
