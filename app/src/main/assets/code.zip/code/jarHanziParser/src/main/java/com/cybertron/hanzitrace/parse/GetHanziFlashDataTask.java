package com.cybertron.hanzitrace.parse;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.cybertron.account.book.Book;
import com.cybertron.account.book.BookUtils;

public class GetHanziFlashDataTask extends AsyncTask<Object, Void, List<Book>> {

	private Context mContext;
	
	public GetHanziFlashDataTask(Context context){
		mContext = context;
	}
	
	@Override
	protected List<Book> doInBackground(Object... params) {
		return BookUtils.getBookListFromAce("hanzixuexi");
	}

	@Override
	protected void onPostExecute(List<Book> result) {
		super.onPostExecute(result);
		List<Book> flashBooks = new ArrayList<Book>();
		if (result != null && result.size() > 0) {
			for (int i = 0; i < result.size(); i++) {
				Book flvbook = result.get(i);
				if (flvbook.getResName().equals("汉字动画库")) {
					flashBooks.add(flvbook);
				}
			}
			HZFlashParser.getInstance().startStoreDownload(mContext, flashBooks);
		} else {
			Toast.makeText(mContext, mContext.getResources().getString(R.string.start_store_fail),Toast.LENGTH_SHORT).show();
		}
	}

}
