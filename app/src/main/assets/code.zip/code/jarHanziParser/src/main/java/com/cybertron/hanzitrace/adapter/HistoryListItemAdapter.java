package com.cybertron.hanzitrace.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.cybertron.hanzitrace.parse.R;

public class HistoryListItemAdapter extends BaseAdapter{

	private LayoutInflater mInflater;
	
	private List<Bitmap> mBitmaps;
	
	public HistoryListItemAdapter(Context context,List<Bitmap> bitmaps){
		mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mBitmaps = bitmaps;
	}
	
	@Override
	public int getCount() {
		return mBitmaps.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder; 
		if(convertView == null){
			holder = new ViewHolder();
			convertView = mInflater.inflate(R.layout.trace_history_item, null);
			holder.mImageView = (ImageView) convertView.findViewById(R.id.card_study_trace_history_item);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder) convertView.getTag();
		}
		
		holder.mImageView.setImageBitmap(mBitmaps.get(position));
		return convertView;
	}

	class ViewHolder{
		ImageView mImageView;
	}

	public void setBitmap(int i) {
		
	}

	public void addBitmap(Bitmap bitmap) {
		if(mBitmaps != null)
			mBitmaps.add(bitmap);
	}

	public void removeFistBitmap() {
		if(mBitmaps != null && mBitmaps.size() > 0){
			Bitmap bitmap = mBitmaps.get(0);
			if(!bitmap.isRecycled()){
				bitmap.recycle();
			}
			mBitmaps.remove(0);
		}
	}

	
	
}
