package com.cybertron.hanzitrace.widget;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.ImageView;

import com.cybertron.hanzitrace.parse.CPoint;
import com.cybertron.hanzitrace.parse.Char;
import com.cybertron.hanzitrace.parse.Stroke;
import com.cybertron.hanzitrace.widget.StrokeDrawer.Mode;
import com.cybertron.hanzitrace.widget.StrokeDrawer.OnLayerCreatedListener;
import com.cybertron.hanzitrace.widget.StrokeDrawer.StrokeConfig;

class CharView extends ImageView implements OnLayerCreatedListener, ICharView{
	private static final String TAG = CharView.class.getSimpleName();

	private Char mChar;
	private StrokeDrawer drawer;
	private CybMediaPlayer mAudioPlayer;
	private boolean enableOriginal = true;
	private boolean enableOutline = true;
	private boolean isDemoStarted = false;//笔画演示是否开始
	private boolean isDemoPaused = false;//笔画演示是否暂停
	private boolean isPractising = false;//是否正在书写
	private boolean isShowingUserInput = false;//是否显示用户笔迹
	private boolean isStrokeDemoFinished = false;//笔画演示是否结束
	private boolean isStrokeAudioFinished = false;//笔画发音是否结束
	private boolean isPenUp = false;
	
	private Paint rectPaint;
	private int mStrokeIndex = 0;
	private List<Rect> mTestRects = new ArrayList<Rect>();
	private List<Rect> mValidRects = new ArrayList<Rect>();
	private List<Rect> mMissingRects = new ArrayList<Rect>();
	
	private int prevX, prevY;
	private Path mUserPath = new Path();
	private List<Point> rawInputDots = new ArrayList<Point>();
	private List<Point> mInputDots = new ArrayList<Point>();
//	private List<Path> mPaths = new ArrayList<Path>();
	private StrokeConfig mConfig = StrokeConfig.demo;
	private DemoType mType = DemoType.none;
	private OnAudioCompletedListener mCompletedListener = new OnAudioCompletedListener(this);
	private boolean isNotified = false;
	private boolean DEBUG = false;
	public enum DemoType{
		none, one, all;
	}

	private static final float TOUCH_TOLERANCE = 4;
	private static final int TEST_RECT_MARGIN = 5;
	private static final int SKIP_DOT_NUM = 5;//must be odd
	private static final int MIN_PART_NUM = 10;
	private static final int MAX_INVALID_DOT = 35;
	private static final int GRANTED_SCORE = 60;
	
	private static final boolean DEBUG_TEST_RECT = false;
	private static final boolean DEBUG_OK_RECT = false;
	private /*static final*/ boolean DEBUG_STROKE_SIZE = false;
	private static final boolean DEBUG_SHOW_MISSING_RECT = false;
	
	public void setMode(Mode m) {
		drawer.setMode(m);
		postInvalidate();
	}
	
	public void setColor(int color) {
		drawer.setColor(color);
		postInvalidate();
	}
	
	public void setWidth(int width) {
		drawer.setStrokeWidth(width);
		postInvalidate();
	}
	
	public CharView(Context context) {
		super(context);
		init();
	}

	public CharView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public CharView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}
	
	private void init() {
		drawer = new StrokeDrawer();
		drawer.setOnLayerCreatedListener(this);
		rectPaint = new Paint();
		rectPaint.setStyle(Style.FILL);
	}
	
	
	
	public void setChar(Char c) {
		mChar = c;
		reInit();
	}
	
	public Char getChar() {
		return mChar;
	}
	
	public void setScale(float scale) {
		drawer.setScale(scale);
		reInit();
	}
	
	public void setStrokeConfig(StrokeConfig config) {
		mConfig = config;
		drawer.setStrokeConfig(config);
		reInit();
	}
	
	public StrokeConfig getStrokeConfig() {
		return mConfig;
	}
	
	public void setEnableOriginal(boolean b) {
		if (enableOriginal != b) {
			enableOriginal = b;
			postInvalidate();
		}
	}
	
	public void setenableOutline(boolean b) {
		if (enableOutline != b) {
			enableOutline = b;
			postInvalidate();
		}
	}
	
	public void demonstrateOneStroke() {
		genStrokeRects(mStrokeIndex, mTestRects);
		demonstrate(DemoType.one);
	}

	public void demonstrateAllStrokes() {
		resetDemonstration();
		demonstrate(DemoType.all);
	}
	
	private void demonstrate(DemoType type) {
		mCompletedListener.type = AudioType.stroke;
		if (mAudioPlayer != null) {
			mAudioPlayer.setOnCompletedListener(mCompletedListener);
			mAudioPlayer.playAudio(getContext(), mChar.get(mStrokeIndex).getBishun());
		}
		
		if (type == DemoType.one) {
			drawer.resetDemoStroke();
		}
		
		isStrokeDemoFinished = false;
		isStrokeAudioFinished = false;
		isDemoStarted = true;
		isDemoPaused = false;
		mType = type;
		postInvalidate();
	}
	
	private void demonstrateNextStroke() {
		logd(TAG, "demonstrateNextStroke start");
		mStrokeIndex++;
		isStrokeDemoFinished = false;
		isStrokeAudioFinished = false;
		mCompletedListener.type = AudioType.stroke;
		if (mAudioPlayer != null) {
			mAudioPlayer.setOnCompletedListener(mCompletedListener);
			if (mAudioPlayer.playAudio(getContext(), mChar.get(mStrokeIndex).getBishun())) {
				invalidate();
			}
		}
		logd(TAG, "demonstrateNextStroke end");
	}
	
	public void pauseDemonstration() {
		postInvalidate();
		isDemoPaused = true;
	}
	
	public void resumeDemonstration() {
		postInvalidate();
		isStrokeAudioFinished = true;
		isDemoPaused = false;
	}
	
	public void resetDemonstration() {
		logd(TAG, "resetDemonstration");
		mStrokeIndex = 0;
		clearDemonstration();
		if (mAudioPlayer != null) {
			mAudioPlayer.stopAudio();
		}
	}
	
	public void clearDemonstration() {
		mHandler.removeCallbacksAndMessages(null);
		isDemoStarted = false;
		mType = DemoType.none;
		drawer.clearShowLayer();
		postInvalidate();
	}
	
	public boolean isDemoStarted() {
		return isDemoStarted;
	}
	
	public boolean isDemoPlaying() {
		return !isDemoPaused;
	}
	
	public boolean isDemoPaused() {
		return isDemoPaused;
	}
	
	public boolean isPractising() {
		return isPractising;
	}
	
	private void doCurStroke() {
		demonstrateOneStroke();
		invalidate();
	}
	
	private void doNextStroke() {
		mStrokeIndex++;
		invalidate();
		demonstrateOneStroke();
	}
	
	
	public void practise() {
		stopPractise();
		isPractising = true;
		mCompletedListener.type = AudioType.welcome;
		if (mAudioPlayer != null) {
			mAudioPlayer.setOnCompletedListener(mCompletedListener);
			mAudioPlayer.playAudio(getContext(), CybMediaPlayer.getStartWriteTipAudioId());
		}
	}
	
	public void stopAll() {
		resetDemonstration();
		if (isDemonstrationMode()) {
		} else {
			stopPractise();
		}
		invalidate();
	}
	
	public void stopPractise() {
		logd(TAG, "stopPractise");
		mHandler.removeCallbacksAndMessages(null);
		mStrokeIndex = 0;
		isPractising = false;
		isShowingUserInput = false;
		isNotified = false;
		mUserPath.reset();
		rawInputDots.clear();
		mValidRects.clear();
		drawer.clearPractiseLayer();
		if (mAudioPlayer != null) {
			mAudioPlayer.stopAudio();
		}
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (mChar == null) {
			return;
		}
		if (DEBUG_STROKE_SIZE) {
			drawOriginal(canvas);
			drawOutline(canvas);
		} else {
			drawStrokeBg(canvas);
		}
		
		if (isDemonstrationMode()) {
			demoCurStroke(canvas);
		} else if (isPractiseMode()) {
			if (isDemoStarted) {
				demoCurStroke(canvas);
			} else {
				drawHightlightStroke(canvas);//绘制高亮显示当前笔画
			}
			drawTestRect(canvas);//绘制测试框（用于调试）
			drawCorrectRect(canvas);//绘制命中框（用于调试）
			drawUserStrokes(canvas);//绘制用户之前笔画的书写笔迹
			drawUserInput(canvas);//绘制用户当前当前笔画的书写笔迹
		} else if (isAdvanceMode()) {
			drawHightlightStroke(canvas);//绘制高亮显示当前笔画
			drawTestRect(canvas);//绘制测试框（用于调试）
			drawCorrectRect(canvas);//绘制命中框（用于调试）
			drawUserStrokes(canvas);//绘制用户之前笔画的书写笔迹
			drawUserInput(canvas);//绘制用户当前当前笔画的书写笔迹
		}
	}
	
	private void drawOriginal(Canvas canvas) {
		if (!enableOriginal) {
			return;
		}
		for (int i=0; i<mChar.getCount(); i++) {
			Stroke stroke = mChar.get(i);
			drawer.drawOriginal(canvas, stroke);
		}
	}
	
	private void drawOutline(Canvas canvas) {
		if (!enableOutline) {
			return;
		}
		for (int i=0; i<mChar.getCount(); i++) {
			Stroke stroke = mChar.get(i);
			drawer.drawOutline(canvas, stroke);
		}
	}
	
	private void drawStrokeBg(Canvas canvas) {
		drawer.drawStrokeBg(canvas);
	}
	
	private void drawStrokeBgToBuffer() {
		drawer.clearBgLayer();
		for (int i=0; i<mChar.getCount(); i++) {
			Stroke stroke = mChar.get(i);
			drawer.drawStrokeBgToBuff(stroke);
		}
	}
	
	private void drawUserInput(Canvas canvas) {
		drawer.drawUserInput(canvas, mUserPath);
	}
	
	private void drawUserStrokes(Canvas canvas) {
		drawer.drawUserStrokes(canvas);
	}
	
	private void drawTestRect(Canvas canvas) {
		if (!DEBUG_TEST_RECT) {
			return;
		}
		List<Rect> rects = new ArrayList<Rect>();
		for (int i=0; i<mChar.getCount(); i++) {
			genStrokeRects(i, rects);
			drawTestRect(canvas, rects);
		}
	}
	
	private void drawTestRect(Canvas canvas, List<Rect> rects) {
		for (int i = 0; i < rects.size(); i++) {
			if ((i % 2) == 0) {
				rectPaint.setColor(Color.YELLOW);
			} else {
				rectPaint.setColor(Color.BLUE);
			}
			canvas.drawRect(rects.get(i), rectPaint);
		}
	}
	
	public void drawCorrectRect(Canvas canvas) {
		if (!DEBUG_OK_RECT) {
			return;
		}
		
		rectPaint.setColor(Color.GREEN);
		for (int i = 0; i < mValidRects.size(); i++) {
			Rect rt = new Rect(mValidRects.get(i));
			rt.left += 1;
			rt.top += 1;
			rt.right -= 1;
			rt.bottom -= 1;
			canvas.drawRect(rt, rectPaint);
		}
	}
	
	
	private boolean genStrokeRects(int index, List<Rect> rectList) {
		boolean result = false;
		Stroke stroke = null;
		if (index < mChar.getCount()) {
			stroke = mChar.get(index);
		}
		
		if (stroke != null) {
			int left, top, right, bottom;
			float scale = drawer.getScale();
			rectList.clear();
			Rect preRt = null;
			for (int i = 0; i < stroke.getCount() - SKIP_DOT_NUM; i+=SKIP_DOT_NUM) {
				CPoint p1 = stroke.get(i).scale(scale);
				CPoint p2 = stroke.get(i + SKIP_DOT_NUM).scale(scale);
				
				left = Math.min(p1.x, p2.x);
				top = Math.min(p1.y, p2.y);
				right = Math.max(p1.x, p2.x);
				bottom = Math.max(p1.y, p2.y);
				
				Rect rt = new Rect(left, top, right, bottom);
				rt.left -= TEST_RECT_MARGIN;
				rt.right += TEST_RECT_MARGIN;
				rt.top -= TEST_RECT_MARGIN;
				rt.bottom += TEST_RECT_MARGIN;
				if (preRt != null && preRt.equals(rt)) {

				} else {
					preRt = rt;
					rectList.add(rt);
				}
			}
			
			if (rectList.size() > 0) {
				result = true;
			}
		}
		
		return result;
	}
	
	private boolean judgeUserInputStroke() {
		boolean result = false;
		int mTestRectNum = mTestRects.size();
		int mFilledInputNum = mInputDots.size();

		int firstOkRtIndex = -1, lastOkRtIndex = -1;
		int firstAcceptedDotIndex = -1, lastAcceptedDotIndex = -1;
		
		mValidRects.clear();
		int start = 0;
		for (int i = 0; i < mTestRects.size(); i++) {
			
			Rect rt = mTestRects.get(i);
			boolean found = false;
			for (int j = start; j < mInputDots.size(); j++) {

                Point p = mInputDots.get(j);
                boolean contain = rt.contains(p.x, p.y);

                if (!found && contain) {
					found = true;
					if (firstAcceptedDotIndex == -1) {
						firstAcceptedDotIndex = j;
					}
				}
				
				if (found && !contain) {
					start = j;
					mValidRects.add(rt);
					if (firstOkRtIndex == -1) {
						firstOkRtIndex = i;
					}
					lastOkRtIndex = i;
					lastAcceptedDotIndex = j;
					break;
				}
			}
			
			if ((i > mTestRectNum/5) && (firstOkRtIndex == -1)) {
				Log.e(TAG, "too many rects were not reached at the beginning!!");
				return result;
			}
		}
		
		if (firstAcceptedDotIndex > MAX_INVALID_DOT) {
			Log.e(TAG, "Too many INVALID dots at the beginning");
			return result;
		}
		
		if (lastAcceptedDotIndex < (mFilledInputNum - MAX_INVALID_DOT)) {
			Log.e(TAG, "Too many INVALID dots at the end");
			return result;
		}
		
		if (mTestRectNum > MIN_PART_NUM) {
			if (lastOkRtIndex < (mTestRectNum*4)/5) {
				Log.e(TAG, "too many rects were not reached at the end!!");
				return result;
			}
		} else {
			if (mValidRects.size() < mTestRectNum/2) {
				Log.e(TAG, "too many rects were not reached!!");
				return result;
			} else {
				logd(TAG, "mTestRectNum = " + mTestRectNum + ", correctRectNum = "+mValidRects.size());
				return true;
			}
		}
		
		int correctRectNum = mValidRects.size();
		int score = (correctRectNum*100)/mTestRectNum;
		
		if (score >= GRANTED_SCORE) {
			result = true;
		}
		logd(TAG, "mTestRectNum = " + mTestRectNum + ", correctRectNum = "+correctRectNum+", score = " + score);
		logd(TAG, "firstOkRtIndex = " + firstOkRtIndex);
		logd(TAG, "lastOkRtIndex = " + lastOkRtIndex);
		logd(TAG, "firstAcceptedDotIndex = " + firstAcceptedDotIndex);
		logd(TAG, "lastAcceptedDotIndex = " + lastAcceptedDotIndex);
		if (DEBUG_SHOW_MISSING_RECT) {
			mMissingRects.clear();
			mMissingRects.addAll(mTestRects);
			mMissingRects.removeAll(mValidRects);
			logd(TAG, "mMissingRects.size() = " + mMissingRects.size());
			logd(TAG, "mMissingRects = " + mMissingRects);
		}
		
		logd(TAG, "mFilledInputNum = " + mFilledInputNum);
		
		return result;
	}
	
	private void fillUserInputDots() {
		mInputDots.clear();
		if (rawInputDots.size() == 0) {
			return;
		}
		
		mInputDots.add(rawInputDots.get(0));
		for (int i = 0; i < rawInputDots.size() - 1; i++) {
			Point p1 = rawInputDots.get(i);
			Point p2 = rawInputDots.get(i+1);
			mInputDots.addAll(lineTo(p1, p2));
		}
	}
	
	public List<Point> lineTo(Point p1, Point p2) {
		return lineUp(p1.x, p1.y, p2.x, p2.y);
	}
	
	/**
	 * 计算A(x1, y1)与B(x2, y2)间的所有点
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 * @return 返回的点集不包含点A,但包含点B。如果AB两点重合，返回的List的size为0
	 */
	public List<Point> lineUp(int x1, int y1, int x2, int y2) {
		
		List<Point> points = new ArrayList<Point>();
		if (x1==x2 && y1==y2) {
			return points;
		}
		
		int deltaX = Math.abs(x1-x2);
		int deltaY = Math.abs(y1-y2);
		
		int sx = (x1 > x2) ? -1 : ((x1 < x2) ? 1 : 0);
		int sy = (y1 > y2) ? -1 : ((y1 < y2) ? 1 : 0);
		
		int ix = x1, iy = y1, dx = 0, dy = 0, ex = 0, ey = 0;
		if (deltaX > deltaY) {
			for(int i = 0; i < deltaX; i++) {
				ix += sx;
				dx = Math.abs(ix - x1);
				dy = Math.abs(iy - y1);
				ey = (deltaY * dx) / deltaX;
				if (dy < ey) {
					iy += sy;
				}
				points.add(new Point(ix, iy));
			}
		} else {
			for(int i = 0; i < deltaY; i++) {
				iy += sy;
				dy = Math.abs(iy - y1);
				dx = Math.abs(ix - x1);
				ex = (deltaX * dy) / deltaY;
				if (dx < ex) {
					ix += sx;
				}
				points.add(new Point(ix, iy));
			}
		}
		
		return points;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		
		if (isDemonstrationMode()) {
			return super.onTouchEvent(event);
		}
		
		this.getParent().requestDisallowInterceptTouchEvent(true);
		
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:{
			touchDown(event);
		}
			break;
		case MotionEvent.ACTION_MOVE:{
			touchMove(event);
		}
			break;
		case MotionEvent.ACTION_UP:{
			touchUp(event);
		}
			break;
		default:
			break;
		}
		
		return true;
	}

	private void touchDown(MotionEvent event) {
		int x = (int)event.getX();
		int y = (int)event.getY();
		if (isShowingUserInput || drawer.isDisplayingUserStroke()) {
			practise();
			return;
		}
		
		isPenUp = false;
		notifyOnStartWriting();
		if (!isPractising) {
			logd(TAG, "touchDown");
			isPractising = true;
			doCurStroke();
		} else if (isDemoStarted) {
			clearDemonstration();
		}
		logd(TAG, "touchDown ---> mUserPath.reset()");
		mUserPath.reset();
		mUserPath.moveTo(x, y);
		prevX = x;prevY = y;
		rawInputDots.clear();
		rawInputDots.add(new Point(x, y));
	}
	
	private void touchMove(MotionEvent event) {
		int x = (int)event.getX();
		int y = (int)event.getY();
		
		int dx = Math.abs(x - prevX);
		int dy = Math.abs(y - prevX);
		
		if(mUserPath.isEmpty()) {
			logd(TAG, "touchMove ---> mUserPath.reset()");
			mUserPath.reset();
			rawInputDots.clear();
			mUserPath.moveTo(x, y);
			prevX = x;prevY = y;
		} else {
			if (dx > TOUCH_TOLERANCE || dy > TOUCH_TOLERANCE) {
				mUserPath.quadTo(prevX, prevY, (x + prevX)/2, (y + prevY)/2);
				prevX = x;prevY = y;
			}
		}
		rawInputDots.add(new Point(x, y));
		invalidate();
	}
	
	private void touchUp(MotionEvent event) {
		isPenUp = true;
		if (isNotified || mTestRects.isEmpty()) {
			logd(TAG, "touchUp ---> mUserPath.reset()");
			mUserPath.reset();
			rawInputDots.clear();
			return;
		}
		int x = (int)event.getX();
		int y = (int) event.getY();
		if (!mUserPath.isEmpty()) {
			mUserPath.lineTo(x, y);
			rawInputDots.add(new Point(x, y));
			fillUserInputDots();
			if(judgeUserInputStroke()) {
				logd(TAG, "after judgeUserInputStroke() mStrokeIndex = " + mStrokeIndex);
				mTestRects.clear();
				mValidRects.clear();
				drawer.drawUserStrokeToBuffer(mUserPath);
				if (mStrokeIndex < mChar.getCount()-1) {
					logd(TAG, "after judgeUserInputStroke() 1");
					doNextStroke();
					isNotified = false;
				} else {
					logd(TAG, "after judgeUserInputStroke() isNotified = " + isNotified);
					if (!isNotified) {
						isNotified = true;
						boolean replay = notifyOnCompleteWriting(100);
						if (replay) {
							if (mAudioPlayer != null) {
								mCompletedListener.type = AudioType.completed;
								mAudioPlayer.setOnCompletedListener(mCompletedListener);
							}
						} else {
							isShowingUserInput = true;
						}
						if (mAudioPlayer != null) {
							mAudioPlayer.playAudio(getContext(), CybMediaPlayer.getCompletedWriteAudioId());
						}
					}
				}
			} else {
				mCompletedListener.type = AudioType.bad;
				if (mAudioPlayer != null) {
					mAudioPlayer.setOnCompletedListener(mCompletedListener);
					mAudioPlayer.playAudio(getContext(), CybMediaPlayer.getErrorTipAudioId());
				}
			}
		} else {
			mCompletedListener.type = AudioType.bad;
			if (mAudioPlayer != null) {
				mAudioPlayer.setOnCompletedListener(mCompletedListener);
				mAudioPlayer.playAudio(getContext(), CybMediaPlayer.getErrorTipAudioId());
			}
		}
		
	}
	
	public void drawHightlightStroke(Canvas canvas) {
		if (mStrokeIndex > mChar.getCount() || mStrokeIndex < 0) {
			return;
		}

		if (isPractising) {
			Stroke stroke = mChar.get(mStrokeIndex);
			drawer.highlightStroke(canvas, stroke);
		}
	}
	
	public void drawHightlightStrokeToBuffer(Canvas canvas) {
		if (mStrokeIndex > mChar.getCount() || mStrokeIndex < 0) {
			return;
		}

		if (isPractising) {
			Stroke stroke = mChar.get(mStrokeIndex);
			drawer.highlightStroke(canvas, stroke);
		}
	}
	
	public void demoCurStroke(Canvas canvas) {
		logd(TAG, "demoCurStroke isDemoStarted = " + isDemoStarted);
		if (!isDemoStarted || mStrokeIndex > mChar.getCount() || mStrokeIndex < 0) {
			return;
		}
		
		logd(TAG, "demoCurStroke isDemoPaused = " + isDemoPaused);
		//pause demonstration
		if (isDemoPaused && isDemonstrationMode()) {
			drawer.drawShowLayer(canvas);
			return;
		}
		
		Stroke stroke = mChar.get(mStrokeIndex);
		if (!isStrokeDemoFinished && drawer.visualDrawOneStroke(canvas, stroke)) {
			isStrokeDemoFinished = true;
			if (isStrokeAudioFinished && !isDemoPaused) {
				mHandler.sendEmptyMessage(MSG_DEMO_NEXT_STROKE);
			}
		} else {
			invalidate();
		}
	}
	
	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		if(drawer.initLayers(w, h)) {
			invalidate();
		}
	}
	
	@Override
	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		if (mAudioPlayer == null) {
			mAudioPlayer = new CybMediaPlayer();
		}
	}
	
	@Override
	protected void onDetachedFromWindow() {
		stopAll();
		if (mAudioPlayer != null) {
			try {
				if (mAudioPlayer.isPlaying()) {
					mAudioPlayer.stop();
				}
				mAudioPlayer.release();
				mAudioPlayer = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Log.i(TAG, "onDetachedFromWindow: ");
		super.onDetachedFromWindow();
//		drawer.recycle();
	}
	
	

	public boolean isDemonstrationMode() {
		return mConfig == StrokeConfig.demo || mConfig == StrokeConfig.advance || mConfig == StrokeConfig.demo_emu;
	}
	
	public boolean isPractiseMode() {
		return mConfig == StrokeConfig.write || mConfig == StrokeConfig.write_p16 || mConfig == StrokeConfig.write_p10;
	}
	
	public boolean isAdvanceMode() {
		return mConfig == StrokeConfig.advance;
	}

	public Bitmap getUserInputBitmap() {
		return drawer.getPractiseLayer();
	}
	
	public void setUsetInputBitmap(Bitmap bitmap) {
		drawer.setPractiseLayer(bitmap);
	}
	
	@Override
	public void onLayerCreated(int width, int height) {
		reInit();
	}
	
	private void reInit() {
		if (mChar != null) {
			genStrokeRects(mStrokeIndex, mTestRects);
			drawStrokeBgToBuffer();
			resetDemonstration();
			stopPractise();
			postInvalidate();
		}
	}
	
	public interface AudioType {
		int none 		= 0;
		int good 		= 1;
		int bad 		= 2;
		int completed 	= 3;
		int stroke 		= 4;
		int welcome 	= 5;
	}
	
	private static class OnAudioCompletedListener implements OnCompletionListener {
		public int type = AudioType.none;
		private WeakReference<CharView> mReference;
		OnAudioCompletedListener(CharView cv) {
			mReference = new WeakReference<CharView>(cv);
		}

		@Override
		public void onCompletion(MediaPlayer mp) {
			CharView charView = mReference.get();
			if (charView != null) {
				Log.i(TAG, "onCompletion --> type = " + type);
				switch (type) {
					case AudioType.none:
						break;
					case AudioType.welcome:
						charView.onWelcomeComplete();
						break;
					case AudioType.good:
						break;
					case AudioType.bad:{
						charView.onBadTipsComplete();
					}
					break;
					case AudioType.completed:{
						charView.onPractiseComplete();
					}
					break;
					case AudioType.stroke:{
						charView.onStrokeDemoComplete();
					}
					break;
					default:
						break;
				}

				type = AudioType.none;
			}

		}
		
		@Override
		public String toString() {
			return ""+type;
		}
	}

	private void onPractiseComplete() {
		invalidate();
		mHandler.sendEmptyMessage(MSG_START_PRACTISE);
	}

	private void onStrokeDemoComplete() {
		logd(TAG, "demoCurStroke 2 isDemoPaused = " + isDemoPaused);
		isStrokeAudioFinished = true;
		if (isStrokeDemoFinished && !isDemoPaused) {
            mHandler.sendEmptyMessage(MSG_DEMO_NEXT_STROKE);
        }
	}

	private void onBadTipsComplete() {
		logd(TAG, "OnAudioCompletedListener ---> mUserPath.reset()");
		if (isPenUp) {
            mUserPath.reset();
            rawInputDots.clear();
        }
		doCurStroke();
	}

	private void onWelcomeComplete() {
		logd(TAG, "OnAudioCompletedListener AudioType.welcome");
		doCurStroke();
	}


	private static final int MSG_DEMO_NEXT_STROKE = 100;
	private static final int MSG_START_PRACTISE = 101;
	private Handler mHandler = new UiHandler(this);
	private static class UiHandler extends Handler {
		WeakReference<CharView> mReference;
		public UiHandler(CharView cv) {
			mReference = new WeakReference<CharView>(cv);
		}

		@Override
		public void handleMessage(Message msg) {
			CharView charView = mReference.get();
			if (charView != null) {
				switch (msg.what) {
					case MSG_DEMO_NEXT_STROKE:
						charView.demoNextStroke();
						break;
					case MSG_START_PRACTISE:
						charView.practise();
						break;
					default:
						break;
				}
			}
		}
	}

	private void demoNextStroke() {
		if (mType == DemoType.all) {
			if ((mStrokeIndex < mChar.getCount() - 1)) {
				logd(TAG, "demoCurStroke 2 demonstrateNextStroke");
				demonstrateNextStroke();
			} else {
				logd(TAG, "demoCurStroke 2 resetDemonstration");
				notifyOnCompleteDemonstrating();
				resetDemonstration();
			}
		} else if (mType == DemoType.one) {
			logd(TAG, "demoCurStroke 2 clearDemonstration");
			clearDemonstration();
		}
	}

	private MagicCharView.OnCompleteWritingListener mListener = null;
	public void setOnCompleteWritingListener(MagicCharView.OnCompleteWritingListener listener) {
		mListener = listener;
	}
	
	private void notifyOnStartWriting(){
		if (mListener != null && isPractiseMode()) {
			mListener.onStartWriting(this);
		}
	}
	
	private boolean notifyOnCompleteWriting(int score){
		if (mListener != null && isPractiseMode()) {
			return mListener.onCompleteWriting(this, score);
		}
		return true;
	}
	
	private void notifyOnCompleteDemonstrating() {
		if (mListener != null && isDemonstrationMode()) {
			mListener.onCompleteDemonstrating(this);
		}
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(mChar == null ? "" : mChar.ch+"-");
		sb.append(isDemonstrationMode() ? "DEMO" : "PRAC");
		return sb.toString();
	}
	
	private void logd(String tag, String msg) {
		if (DEBUG) {
			Log.i(tag, this + ":" + msg);
		}
	}
	
	public void enableDebug(boolean enable) {
		DEBUG_STROKE_SIZE = enable;
	}

	@Override
	public void skipDemoAudioMode(boolean skip) {

	}

	@Override
	public void setParams(MagicCharView.CharViewParams params) {
		drawer.setMode(params.mMode);
		setStrokeConfig(params.mConfig);
		drawer.setColor(params.mColor);
		setEnableOriginal(params.enableOriginal);
		setenableOutline(params.enableOutline);
		enableDebug(params.enableDebug);
		setOnCompleteWritingListener(params.mListener);
		setUsetInputBitmap(params.mUserBitmap);
		drawer.setScale(params.mScale);
		params.mScale = drawer.getScale();

		if (DEBUG_STROKE_SIZE) {
			drawer.setStrokeWidth(params.mWidth);
		}

		reInit();
	}

	@Override
	public StringBuilder getLogMsg() {
		return null;
	}
}
