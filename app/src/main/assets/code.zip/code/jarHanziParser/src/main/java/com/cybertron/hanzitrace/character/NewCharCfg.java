package com.cybertron.hanzitrace.character;

import java.io.File;

import com.cybertron.account.CyberConst;

public interface NewCharCfg {
	boolean USE_DEMO_DATA = false;
	String CHARACTER_DB_PATH = CyberConst.TEMP_PATH + File.separator + "NewWordsBase.db";
	String CHAR_VOICE_DB_PATH = CyberConst.TEMP_PATH + File.separator + "chnvoicebank.db";
	String DEFAULT_CHARACTER_VOICE_PATH = CyberConst.TEMP_PATH + File.separator + "word_voice.mp3";
}
