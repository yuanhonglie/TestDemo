package com.cybertron.hanzitrace.view;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import com.cybertron.account.book.Book;
import com.cybertron.account.intent.OnLinePlay;
import com.cybertron.account.util.ACache;
import com.cybertron.account.util.FileUtils;
import com.cybertron.account.util.NetUtils;
import com.cybertron.api.CybHelper;
import com.cybertron.dicts.util.DictDBHelper;
import com.cybertron.dicts.util.StaticUtils;
import com.cybertron.dicts.util.UyghurDictHelper;
import com.cybertron.hanzitrace.GroupItem;
import com.cybertron.hanzitrace.adapter.HistoryListItemAdapter;
import com.cybertron.hanzitrace.character.CharDbHelper;
import com.cybertron.hanzitrace.character.CharacterVoice;
import com.cybertron.hanzitrace.parse.Char;
import com.cybertron.hanzitrace.parse.Config;
import com.cybertron.hanzitrace.parse.GetHanziFlashDataTask;
import com.cybertron.hanzitrace.parse.HZDataParser;
import com.cybertron.hanzitrace.parse.HZFlashParser;
import com.cybertron.hanzitrace.parse.HanZiHelper;
import com.cybertron.hanzitrace.parse.R;
import com.cybertron.hanzitrace.parse.newdb.HZDataParserDb;
import com.cybertron.hanzitrace.utils.StaticFinalUtil;
import com.cybertron.hanzitrace.utils.StringUtil;
import com.cybertron.hanzitrace.widget.ICharView;
import com.cybertron.hanzitrace.widget.MagicCharView;
import com.cybertron.hanzitrace.widget.StrokeDrawer.StrokeConfig;
import com.cybertron.sdk.net.communication.HttpHelper;
import com.cybertron.sdk.net.communication.Param;
import com.cybertron.sdk.net.communication.ServerUrl;
import com.cybertron.sdk.net.communication.Values;
import com.cybertron.swflib.SwfUtils;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
import com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack;
import com.lidroid.xutils.bitmap.callback.BitmapLoadFrom;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 显示单个单词学习的fragment
 * 
 * @author Administrator
 * 
 */
public class HanziStudyFragment extends Fragment implements OnClickListener {

	private String TAG = "HanziStudyFragment";

	private View mContainer;

	private MagicCharView mBigCharView, mSmallTraceCharView; // 描红

	private ImageView mTracePronounce; // 汉字发音

	private TextView mTraceSpell; // 汉字拼音

	private TextView mTraceStrokes; // 汉字笔画

	private TextView mTraceRadicals; // 汉字部首

	private TextView mTraceStructure; // 汉字结构

	private Char mChar; // 汉字信息

	private GroupItem mGroupItem; // 每个汉字item

	private HZDataParser mDataParser; // 数据解析

	private MediaPlayer mediaPlayer;

	private ListView mHistoryCharViewList; // 存储绘制过笔迹的历史记录

	private HistoryListItemAdapter mListItemAdapter;

	private List<Bitmap> mHistoryBitmaps = new ArrayList<Bitmap>();

	private String chosen_word;

	private List<Book> mDictBooks; // 词典资源列表

	private boolean isVisibleHint = false;

	private TabHost mExpFlashTabHost;

	private Context mContext;

	private CharDbHelper charDbHelper;

//	private String mExplain, mSentence, mPhrase;

	private boolean isViewLoadFinish = false; // view资源是否加载完成

	private ACache mACache; // 硬笔书法信息缓存

	private BitmapUtils mBitmapUtils;

	private HanZiHelper mHanZiHelper;
	
	private CharacterVoice mCharVoice;

	private Handler mHandler = new UiHandler(this);
	static class UiHandler extends Handler {
		private WeakReference<HanziStudyFragment> mReference;
		public UiHandler(HanziStudyFragment fragment) {
			mReference = new WeakReference<>(fragment);
		}

		@Override
		public void handleMessage(Message msg) {
			HanziStudyFragment fragment = mReference.get();
			if (fragment != null) {
				if (msg.what == 0) {
					String explain = (String) msg.obj;
					fragment.initExplainView(explain);
				} else {
					fragment.initExplainView(null);
				}
				fragment.isViewLoadFinish = true;
			}
		}
	}


	public static HanziStudyFragment newInstance(GroupItem groupItem, List<Book> dictbooks, String phrasepath) {
		HanziStudyFragment studydFragment = new HanziStudyFragment();
		Bundle bundle = new Bundle();
		bundle.putSerializable("groupItem", groupItem);
		bundle.putString("phrasepath", phrasepath);
		bundle.putParcelableArrayList("dictbooks", (ArrayList<? extends Parcelable>) dictbooks);
		studydFragment.setArguments(bundle);
		return studydFragment;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		mContext = activity.getApplicationContext();
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mBitmapUtils = new BitmapUtils(mContext);
		mBitmapUtils.configDefaultConnectTimeout(10000);
		mBitmapUtils.configDefaultReadTimeout(5000);

		Bundle bundle = this.getArguments();
		if (bundle != null) {
			mACache = ACache.get(mContext);
			mGroupItem = (GroupItem) bundle.getSerializable("groupItem");
			chosen_word = bundle.getString("copyValue");
			mDictBooks = bundle.getParcelableArrayList("dictbooks");

			String phrasepath = null;
			Book charPhraseBk = bundle.getParcelable("charphrasebook");
			if (charPhraseBk != null) {
				phrasepath = charPhraseBk.getLocalPath();
			} else {
				phrasepath = bundle.getString("phrasepath");
			}
			Log.i(TAG, "==phrasepath " + phrasepath);
			try {
				if (!TextUtils.isEmpty(phrasepath)) {
					charDbHelper = new CharDbHelper(mContext, phrasepath);
				}
				mDataParser = HZDataParser.getInstance();
				mHanZiHelper = HanZiHelper.getIntance();
				
				if (HZDataParser.isUseNewDb()) {
					HZDataParserDb parserDb = (HZDataParserDb) mDataParser;
					Book charVoiceBk = mHanZiHelper.getCharVoiceBook();
					mCharVoice = new CharacterVoice(mContext, charVoiceBk);
					parserDb.setCharacterVoice(mCharVoice);
				}
			} catch (Exception e) {
				e.printStackTrace();
				return;
			}

			if (mGroupItem != null) {
				mChar = mDataParser.getChar(mGroupItem.getHanzi().charAt(0));
			} else {
				String spell = bundle.getString("valueSpell");
				mChar = mDataParser.getChar(chosen_word.charAt(0), spell);
			}
			mediaPlayer = new MediaPlayer();

			new Thread() {
				public void run() {
					StringBuilder comsbExplain = new StringBuilder();
					Message msg = Message.obtain();
					try{
						comsbExplain.append(getExplain());
						comsbExplain.append(getSentence());
						comsbExplain.append(getPhrase());
						if (CybHelper.isWeiYu()) {
							String ugExplain = UyghurDictHelper.getInstance().getExplainString(String.valueOf(mChar.ch), StaticUtils.UG_HWBIG_DICT);
							if (!TextUtils.isEmpty(ugExplain)) {
								comsbExplain.append(ugExplain);
							}
						}

						if (CybHelper.isP36()) {
							String ourExplain = DictDBHelper.getInstance().getExplainString(String.valueOf(mChar.ch), StaticUtils.OUR_DICT);
							if (!TextUtils.isEmpty(ourExplain)) {
								comsbExplain.append(ourExplain);
							}
						}

						msg.what = 0;
						msg.obj = comsbExplain.toString();
						mHandler.sendMessage(msg);
					}catch (RuntimeException e){
						msg.what = -1;
						mHandler.sendMessage(msg);
					}catch (Exception e){
						msg.what = -1;
						mHandler.sendMessage(msg);
					}
				}
			}.start();
		}
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		isVisibleHint = isVisibleToUser;

		if (mChar != null) {
			if (isVisibleToUser && isViewLoadFinish) { // 相当于Fragment的onResume
				onPractiseExecute();
			} else { // 相当于Fragment的onPause
				relevance = true;

				if (mediaPlayer != null && mediaPlayer.isPlaying()) {
					stopVoice();
				}

				stopStrokeDemo();
			}
		}
	}

	private void stopStrokeDemo() {
		if (mBigCharView != null) {
			Log.d(this.getClass().getSimpleName(), ">>>mBigCharView : " + mBigCharView.isDemoStarted());
			mBigCharView.stopAll();
		}
		if (mSmallTraceCharView != null) {
			Log.d(this.getClass().getSimpleName(),
					">>>mSmallTraceCharView : " + mSmallTraceCharView.isDemoStarted());
			mSmallTraceCharView.stopAll();
		}
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		mBitmapUtils.flushCache();
		mBitmapUtils.clearCache();
		stopStrokeDemo();
		relevance = true;
		mHandler.removeCallbacksAndMessages(null);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		releasePlayer();
	}

	/**
	 * 执行 发音 并开始演示
	 */
	public void onPractiseExecute() {
		if (mChar == null) // 加载第一个时直接返回，因为此时view尚未绘制
			return;
		Pronounce(); // 发音标
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		mContainer = (ViewGroup) inflater.inflate(R.layout.cards_study_cell, container, false);
		mContainer.setOnClickListener(this);

		initTraceView(mContainer);

		if (this.getUserVisibleHint()) {
			mHandler.postDelayed(new Runnable() {

				@Override
				public void run() {
					onPractiseExecute();
				}
			}, 1000);

		}

		return mContainer;
	}

	/**
	 * 初始化 描红 view
	 * 
	 * @param root
	 */
	private void initTraceView(View root) {
		String model = getResources().getString(R.string.machine_model);
		StrokeConfig cfg = StrokeConfig.write;
		if (TextUtils.equals("p16", model)) {
			cfg = StrokeConfig.write_p16;
		} else if (TextUtils.equals("p10", model)) {
			cfg = StrokeConfig.write_p10;
		} else if (CybHelper.isWinEmu()) {
			cfg = StrokeConfig.demo_emu;
		}
		mHistoryCharViewList = (ListView) root.findViewById(R.id.card_study_trace_history_list);
		mListItemAdapter = new HistoryListItemAdapter(getActivity(), mHistoryBitmaps);
		mHistoryCharViewList.setAdapter(mListItemAdapter);

		// 描红
		mBigCharView = (MagicCharView) root.findViewById(R.id.card_study_trace_charview);
		mBigCharView.setStrokeConfig(cfg);
		mBigCharView.setChar(mChar);
		mBigCharView.setOnClickListener(this);
		mBigCharView.setOnCompleteWritingListener(new MagicCharView.OnCompleteWritingListener() {

			@Override
			public void onStartWriting(ICharView cv) {
				if (mSmallTraceCharView != null && mSmallTraceCharView.isDemoStarted()) {
					if (mSmallTraceCharView.isDemoPlaying()) {
						mSmallTraceCharView.pauseDemonstration();
					}
				}
			}

			@Override
			public boolean onCompleteWriting(ICharView cv, int score) {
				addBitmap2HistoryList();
				return true;
			}

			@Override
			public void onCompleteDemonstrating(ICharView cv) {

			}

		});

		// 描红小demo
		mSmallTraceCharView = (MagicCharView) root.findViewById(R.id.card_study_trace_demo);
		mSmallTraceCharView.setOnClickListener(this);
		mSmallTraceCharView.setStrokeConfig(StrokeConfig.demo);
		mSmallTraceCharView.setChar(mChar);

		// 发音
		mTracePronounce = (ImageView) root.findViewById(R.id.card_study_trace_pronounce);
		mTracePronounce.setOnClickListener(this);

		// 拼音
		mTraceSpell = (TextView) root.findViewById(R.id.card_study_trace_spell);
		mTraceSpell.setText(mChar.spell);

		// 笔画
		mTraceStrokes = (TextView) root.findViewById(R.id.card_study_trace_strokes);
		String strokesFormat = mContext.getResources().getString(R.string.hanzi_trace_strokes);
		mTraceStrokes.setText(String.format(strokesFormat, mChar.strokeCount));

		// 部首
		mTraceRadicals = (TextView) root.findViewById(R.id.card_study_trace_radicals);
		String radicalFormat = mContext.getResources().getString(R.string.hanzi_trace_radicals);
		mTraceRadicals.setText(String.format(radicalFormat, mChar.radical));

		// 结构
		mTraceStructure = (TextView) root.findViewById(R.id.card_study_trace_structure);
		mTraceStructure.setText(mChar.structure);

		initTab(root);

		// 模拟器机型特殊处理
		if (CybHelper.isWinEmu()) {
			// 左边不再显示
			LinearLayout demoListParent = (LinearLayout) root.findViewById(R.id.ll_demo_list);
			demoListParent.setVisibility(View.GONE);

			RelativeLayout.LayoutParams params = (LayoutParams) mBigCharView.getLayoutParams();
			params.setMargins(92, 0, 0, 0); // 居中显示
			mBigCharView.setLayoutParams(params);
		}
	}

	private boolean isExistFlash = false; // 是否存在动画

	private byte[] flashcoverbuf; // 动画封面

	private byte[] flashdatabuf; // 动画数据

	private TextView mTraceExplain; // 释义

	private TextView mToStore; // 跳转书城

	private boolean existHardPenCalligraphy = false; // 是否存在汉字硬笔书法

	private String hardPenCalligraphyVideoPath; // 汉字硬笔书法视频地址

	private void initTab(View root) {
		String word = String.valueOf(mChar.ch);

		try {
			isExistFlash = HZFlashParser.getInstance().isExistFlash(word);
			existHardPenCalligraphy = mHanZiHelper.existHardPenCalligraphyData(word);
		} catch (Exception e) {
			e.printStackTrace();
		}

		mExpFlashTabHost = (TabHost) root.findViewById(R.id.card_study_cell_trace_tab);
		mExpFlashTabHost.setup();

		// 汉字硬笔书法
		if (existHardPenCalligraphy && !CybHelper.isWinEmu()) {
			mExpFlashTabHost.addTab(mExpFlashTabHost.newTabSpec("hardpencalligraphy")
					.setIndicator(getTabItemView(mContext.getResources().getString(R.string.trace_hardpencalligraphy)))
					.setContent(R.id.card_study_cell_hardpencalligraphy_parent));
			String screenshotpath = ServerUrl.SF_VIDEO_HOST + mHanZiHelper.getHardPenCalligraphyScreenShotPath(word);
			hardPenCalligraphyVideoPath = ServerUrl.SF_VIDEO_HOST + mHanZiHelper.getHardPenCalligraphyVideoPath(word);
			initHardPenCalligraphyView(screenshotpath);
		}

		mExpFlashTabHost.addTab(mExpFlashTabHost.newTabSpec("explain")
				.setIndicator(getTabItemView(mContext.getResources().getString(R.string.trace_explain)))
				.setContent(R.id.card_study_cell_exp_parent));

		// 动画
		if (isExistFlash) {
			mExpFlashTabHost.addTab(mExpFlashTabHost.newTabSpec("flash")
					.setIndicator(getTabItemView(mContext.getResources().getString(R.string.trace_flash)))
					.setContent(R.id.card_study_cell_flash_parent));
			initFlashView(root);
		}

		mExpFlashTabHost.setCurrentTab(0);

		mTraceExplain = (TextView) root.findViewById(R.id.card_study_trace_explain);
		mTraceExplain.setMovementMethod(ScrollingMovementMethod.getInstance());

		// 前往书城
		mToStore = (TextView) root.findViewById(R.id.card_study_trace_2store);
		mToStore.setOnClickListener(this);

		// // 加载硬笔书法任务
		// new GetHardPenCalligraphyTask().execute(word);
	}

	/**
	 * 获取汉字硬笔书法线程
	 */
	class GetHardPenCalligraphyTask extends AsyncTask<Object, Object, Object> {

		@Override
		protected Object doInBackground(Object... params) {
			String courseName = (String) params[0];
			JSONObject resultjson = mACache.getAsJSONObject(courseName);

			// 未缓存的汉字联网获取
			if (resultjson == null && NetUtils.isNetworkAvailable(mContext)) {
				JSONObject postjson = new JSONObject();
				String response = null;
				try {
					Log.i(TAG, "==courseName :" + courseName);
					postjson.put(Param.SfCourse.courseName, courseName);
					postjson.put(Param.action, Values.Action.getSfcourse);
					response = HttpHelper.sendPostRequest(ServerUrl.BOOK, postjson);
					Log.i(TAG, "==response :" + response);
					if (response != null) {
						resultjson = new JSONObject(response);
						String code = resultjson.getString(Param.code);
						Log.i(TAG, "==code :" + code);
						if (code.equals(Values.Code.success)) {
							// 缓存获取的数据
							mACache.put(courseName, resultjson);
						}
					}
				} catch (JSONException e) {
					e.printStackTrace();
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			return resultjson;
		}

		@Override
		protected void onPostExecute(Object result) {
			super.onPostExecute(result);
			JSONObject resultjson = (JSONObject) result;
			if (resultjson != null) {
				mExpFlashTabHost.addTab(mExpFlashTabHost.newTabSpec("hardpencalligraphy")
						.setIndicator(
								getTabItemView(mContext.getResources().getString(R.string.trace_hardpencalligraphy)))
						.setContent(R.id.card_study_cell_hardpencalligraphy_parent));
				try {
					String screenshotpath = resultjson.getString(Param.SfCourse.courseScreenShot);
					hardPenCalligraphyVideoPath = resultjson.getString(Param.SfCourse.courseVideo);
					initHardPenCalligraphyView(screenshotpath);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		}
	};

	/**
	 * 初始化汉字硬笔书法view
	 * 
	 * @param screenshotpath
	 *            封面图片地址
	 */
	private void initHardPenCalligraphyView(String screenshotpath) {
		ImageView hardpencalligraphycover = (ImageView) mContainer
				.findViewById(R.id.card_study_trace_hardpencalligraphy);
		ImageView playImageView = (ImageView) mContainer.findViewById(R.id.card_study_trace_hardpencalligraphy_play);
		playImageView.setVisibility(View.VISIBLE);
		hardpencalligraphycover.setVisibility(View.VISIBLE);
		if (mBitmapUtils != null && !TextUtils.isEmpty(screenshotpath)) {
			try {
				mBitmapUtils.configDefaultLoadingImage(R.drawable.sf_default_bg);
				mBitmapUtils.display(hardpencalligraphycover, screenshotpath, new BitmapLoadCallBack<ImageView>() {

					@Override
					public void onLoadCompleted(ImageView container, String uri, Bitmap bitmap,
							BitmapDisplayConfig config, BitmapLoadFrom from) {
						container.setImageBitmap(bitmap);
					}

					@Override
					public void onLoadFailed(ImageView container, String uri, Drawable drawable) {
						container.setImageResource(R.drawable.sf_default_bg);
					}

				});
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Log.e(TAG, "Load Hard Pen Calligraphy Cover failed !");
		}
		playImageView.setOnClickListener(this);
		hardpencalligraphycover.setOnClickListener(this);
	}

	/**
	 * 播放汉字硬笔书法视频
	 * 
	 * @param videopath
	 */
	protected void displayHardPenCalligraphyVideo(String videopath) {
		if (mediaPlayer != null && mediaPlayer.isPlaying()) {
			stopVoice();
		}

		if (mSmallTraceCharView.isDemoStarted() && mSmallTraceCharView.isDemoPlaying()) {
			mSmallTraceCharView.pauseDemonstration();
		}
		Log.i(TAG, "===paly sf video path:" + videopath);

		try {
			OnLinePlay.onLinePlayDirect(mContext, videopath, null, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 初始化汉字动画view
	 * 
	 * @param root
	 */
	private void initFlashView(View root) {
		try {
			flashcoverbuf = HZFlashParser.getInstance().getFlashCover(String.valueOf(mChar.ch));
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (flashcoverbuf == null) {
			// 前往书城
			TextView mToStore = (TextView) root.findViewById(R.id.card_study_trace_flash_2store);
			TextView mTip = (TextView) root.findViewById(R.id.card_study_trace_flash_tip);
			mToStore.setOnClickListener(this);
			mToStore.setVisibility(View.VISIBLE);
			mTip.setVisibility(View.VISIBLE);
			mTip.setText(R.string.trace_flash_null);
		} else {
			ImageView flashcover = (ImageView) root.findViewById(R.id.card_study_trace_flash);
			Bitmap bmp = BitmapFactory.decodeByteArray(flashcoverbuf, 0, flashcoverbuf.length);
			flashcover.setImageBitmap(bmp);
			flashcover.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					displayFlash();
				}
			});
		}
	}

	/**
	 * 获取解释
	 * 
	 * @return
	 */
	private String getExplain() {
		String explain = ""; // 释义
		try {
//			explain = LightDictDBHelper.getInstance().getExplain(String.valueOf(mChar.ch), "xdhy");
			explain = DictDBHelper.getInstance().getExplainString(String.valueOf(mChar.ch), StaticUtils.DICT_XDHY);
			if (!TextUtils.isEmpty(explain)) {
				explain = InterceptionExplain(explain);
			} else {
				explain = DictDBHelper.getInstance().getExplainString(String.valueOf(mChar.ch), StaticUtils.DICT_XHCD);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return explain;
	}

	/**
	 * 获取造句
	 * 
	 * @return
	 */
	private String getSentence() {
		String sentence = ""; // 造句
		try {
			sentence = charDbHelper.getSentence(String.valueOf(mChar.ch));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sentence;
	}

	/**
	 * 获取词组
	 * 
	 * @return
	 */
	private String getPhrase() {
		String phrase = ""; // 词组
		try {
			String[] spells = String.valueOf(mChar.spell).split("-");
			String spell = "";
			if (spells.length > 0) {
				spell = spells[spells.length - 1];
			} else {
				spell = String.valueOf(mChar.spell);
			}
			phrase = charDbHelper.getPhrases(String.valueOf(mChar.ch), spell);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return phrase;
	}

	// /**
	// * 获取组合释义(解释+)
	// * @return
	// */
	// private String getCombineExplain(){
	// return getExplain()+ getSentence() + getPhrase();
	// }

	private void initExplainView(String explain) {
		if (explain != null) {
			mToStore.setVisibility(View.GONE);
			mTraceExplain.setText(explain);
			mTraceExplain.setLineSpacing(4, 1.5f);
		} else {
			mToStore.setVisibility(View.VISIBLE);
			mTraceExplain.setText(R.string.trace_explain_null);
		}
	}

	/**
	 * 获取tabbutton
	 * 
	 * @param text
	 * @return
	 */
	private View getTabItemView(String text) {
		LayoutInflater inflater = LayoutInflater.from(mContext);
		View view = inflater.inflate(R.layout.card_study_cell_trace_tab_indicator, null);
		TextView tv = (TextView) view.findViewById(R.id.card_study_tab_indicator_tv);
		tv.setText(text);
		return view;
	}

	/**
	 * 截取解释(只针对现代汉语)
	 * 
	 * @param explain
	 */
	private String InterceptionExplain(String explain) {
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new ByteArrayInputStream(explain.getBytes(Charset.forName("utf8"))), Charset.forName("utf8")));

		StringBuilder sb = new StringBuilder();
		String line;
		try {
			while ((line = br.readLine()) != null) {

				if (line.contains("部首") || line.contains("笔画") || line.contains("结构") || line.contains("五笔字母")
						|| line.contains("表码字母")) {

				} else {
					sb.append(line + "\n");
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();

	}

	/**
	 * 播放flash
	 */
	protected void displayFlash() {
		String word = String.valueOf(mChar.ch);

		if (flashdatabuf == null) {
			flashdatabuf = HZFlashParser.getInstance().getFlashData(word);
		}
		String TmpFlashPath = Config.ROOT_DIR + "tmp.swf";

		if (FileUtils.writeFile(TmpFlashPath, flashdatabuf)) {
			SwfUtils.openSwf(mContext, TmpFlashPath, null);
		}
	}

	@Override
	public void onClick(View v) {
		if (StringUtil.isFastDoubleClick()) {
			Toast.makeText(getActivity(), R.string.click_too_fast, Toast.LENGTH_SHORT).show();
			return;
		}
		int id = v.getId();

		// 描红小demo
		if (R.id.card_study_trace_demo == id) {
			if (mSmallTraceCharView.isDemoStarted()) {
				if (mSmallTraceCharView.isDemoPlaying()) {
					mSmallTraceCharView.pauseDemonstration();
				} else {
					mSmallTraceCharView.resumeDemonstration();
				}
			} else {
				mSmallTraceCharView.demonstrateAllStrokes();
			}
		}

		// 描红大demo
		if (R.id.card_study_trace_charview == id) {
			if (mBigCharView.isDemoStarted()) {
				if (mBigCharView.isDemoPlaying()) {
					mBigCharView.pauseDemonstration();
				} else {
					mBigCharView.resumeDemonstration();
				}
			} else {
				mBigCharView.demonstrateAllStrokes();
			}
		}

		if (R.id.card_study_trace_pronounce == id) {// 描红界面发音
			if (mSmallTraceCharView.isDemoStarted()) { // 暂停描红
				if (mSmallTraceCharView.isDemoPlaying()) {
					mSmallTraceCharView.pauseDemonstration();
				}
			}
			Pronounce();
		}

		if (R.id.card_study_trace_2store == id) {// 前往书城
			try {
				Intent intent = new Intent();
				intent.setAction("cybertron.intent.action.BOOKSTORE_DOWNLOAD");
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.putParcelableArrayListExtra("books", (ArrayList<? extends Parcelable>) mDictBooks);
				startActivity(intent);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (R.id.card_study_trace_flash_2store == id) {// 前往书城
			new GetHanziFlashDataTask(mContext).execute();
		}

		if (R.id.card_study_trace_hardpencalligraphy == id || R.id.card_study_trace_hardpencalligraphy_play == id) {
			displayHardPenCalligraphyVideo(hardPenCalligraphyVideoPath);
		}

		if (R.id.container == id) {
		}
	}

	boolean relevance = true; // 发音和笔顺是否关联

	/**
	 * 发音
	 */
	private void Pronounce() {
		byte[] voiceBytes = mDataParser.getCharVoice(mChar);
		File file = new File(StaticFinalUtil.TMP_CHAR_VOICE_FILE);
		if (!FileUtils.writeFile(file, voiceBytes)) {
			return;
		}
		if (mediaPlayer.isPlaying()) {
			stopVoice();
		}

		playVoice(StaticFinalUtil.TMP_CHAR_VOICE_FILE);
		mediaPlayer.setOnCompletionListener(new OnCompletionListener() {

			@Override
			public void onCompletion(MediaPlayer arg0) {
				if (CybHelper.isWinEmu()) {
					WinEmuDemonStration();
				} else {

					if (isVisibleHint) {
						if (relevance) {
							demonstration();
						}
						relevance = false;
					}
				}
			}
		});
	}

	/**
	 * 开始播放发音
	 */
	private void playVoice(String path) {
		try {
			mediaPlayer.reset();
			mediaPlayer.setDataSource(path);
			mediaPlayer.prepare();
			mediaPlayer.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 停止播放发音
	 */
	private void stopVoice() {
		if (mediaPlayer != null) {
			mediaPlayer.stop();
			try {
				mediaPlayer.prepare();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 停止播放发音
	 */
	private void releasePlayer() {
		if (mediaPlayer != null) {
			mediaPlayer.stop();
			try {
				mediaPlayer.release();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 模拟器demo演示
	 */
	private void WinEmuDemonStration() {
		if (mBigCharView.isDemoStarted()) {
			if (mBigCharView.isDemoPlaying()) {
				mBigCharView.pauseDemonstration();
			} else {
				mBigCharView.resumeDemonstration();
			}
		} else {
			mBigCharView.demonstrateAllStrokes();
		}
	}

	/**
	 * 演示
	 */
	private void demonstration() {
		if (mSmallTraceCharView.isDemoStarted()) {
			if (mSmallTraceCharView.isDemoPlaying()) {
				mSmallTraceCharView.pauseDemonstration();
			} else {
				mSmallTraceCharView.resumeDemonstration();
			}
		} else {
			mSmallTraceCharView.demonstrateAllStrokes();
		}

		mSmallTraceCharView.setOnCompleteWritingListener(new MagicCharView.OnCompleteWritingListener() {

			@Override
			public boolean onCompleteWriting(ICharView cv, int score) {
				return true;
			}

			@Override
			public void onCompleteDemonstrating(ICharView cv) {
				if (isVisibleHint) {
					if (!mBigCharView.isPractising()) {
						mBigCharView.practise(); // 描红
					}
				}
			}

			@Override
			public void onStartWriting(ICharView cv) {

			}
		});
	}

	/**
	 * 添加bitmap到历史记录表中
	 */
	protected void addBitmap2HistoryList() {
		Bitmap bitmap = convertViewToBitmap(mBigCharView);
		if (mListItemAdapter.getCount() >= 3) {
			mListItemAdapter.removeFistBitmap();
		}

		mListItemAdapter.addBitmap(bitmap);
		mListItemAdapter.notifyDataSetChanged();
	}

	/**
	 * 将view转化成bitmap
	 * 
	 * @param view
	 * @return
	 */
	public Bitmap convertViewToBitmap(View view) {

		Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap); // 利用bitmap生成画布
		view.draw(canvas);// 把view中的内容绘制在画布上
		return bitmap;
	}

}
