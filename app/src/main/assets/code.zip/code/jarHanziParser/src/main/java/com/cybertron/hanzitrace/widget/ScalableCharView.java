package com.cybertron.hanzitrace.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.ImageView;

import com.cybertron.hanzitrace.parse.Char;
import com.cybertron.hanzitrace.parse.Stroke;
import com.cybertron.hanzitrace.parse.newdb.NewStroke;
import com.cybertron.hanzitrace.widget.StrokeDrawer.Mode;
import com.cybertron.hanzitrace.widget.StrokeDrawer.StrokeConfig;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.List;

class ScalableCharView extends ImageView implements ICharView,
        DemonstrateStrokeTask.IDemonstrateCallback, DemonstrateStrokeTask.IDemonstrateStrategy {
    private static final String TAG = "ScalableCharView";

    /**
     * 本控件中，描红汉字的宽高值
     */
    private int mWidth, mHeight;
    /**
     * 原始数据的宽高，实际汉字显示宽高为160*{@link #scale}
     */
    private static final int ORIGIN_CHARACTOR_WIDTH = 160;
    /**
     * 本控件中汉字轮廓的缩放系数，此系数会根据控件的宽高自动调整，外部也可以设置此缩放系数
     */
    private float scale = -1;

    /**
     * 最大放大系数
     */
    private float mMaxScale = 0;

    /**
     * 汉字绘制偏移，当汉字宽高小于控件的宽高时，居中显示；
     */
    private int xOffset, yOffset;

    /**
     * 描红汉字
     */
    private Char mChar;

    private CybMediaPlayer mAudioPlayer;

    private Handler mHandler = new Handler();

    /**
     * 笔画设置
     */
    private StrokeConfig mConfig = StrokeConfig.demo;

    /**
     * 演示层，显示当前笔画动态书写过程
     */
    private DemonstrateLayer mDemoLayer;
    /**
     * 洪泛填充辅助图片，此图片仅用于生成填充点，不用于显示；
     */
    private Bitmap mFloodFillLayer;
    /**
     * 用户笔迹层，显示用户输入笔迹
     */
    private Bitmap mUserStrokeLayer;
    /**
     * 用户保存的笔迹图片
     */
    private Bitmap mUserStroke;

    /**
     * 描红背景的外轮廓绘制画笔
     */
    private Paint mBgOutlinePaint;
    /**
     * 描红背景的笔画内容绘制画笔
     */
    private Paint mBgContentPaint;

    /**
     * 用户笔迹画笔
     */
    private Paint mUserPathPaint;

    /**
     * 演示类型，单笔演示或全字演示
     */
    private CharView.DemoType mType = CharView.DemoType.none;
    /**
     * 当前描红演示的笔画序号
     */
    private volatile int strokeIndex = 0;
    /**
     * 描红演示的外轮廓绘制画笔
     */
    private Paint mDemoOutlinePaint;
    /**
     * 描红演示的笔画内容绘制画笔
     */
    private Paint mDemoContentPaint;

    /**
     * 当前笔画描红演示任务
     */
    private DemonstrateStrokeTask mCurDemoTask;
    /**
     * 描红演示是否开始
     */
    private boolean isDemoStarted;
    /**
     * 描红演示是否暂停
     */
    private boolean isDemoPaused;
    /**
     * 描红外轮廓画笔宽度
     */
    private int mStrokeWidth = 2;

    /**
     * 描红书写监听回调
     */
    private MagicCharView.OnCompleteWritingListener mListener = null;

    /**
     * 是否为调试模式
     */
    private boolean isDebugEnabled = false;

    /**
     * 是否跳过语音，主要用于测试数据；
     */
    private boolean skipAudioData = false;

    private boolean isNotified = false;
    //单词书写完成后，如果onCompleteWriting返回false，
    // 则isShowingUserInput会被设置为true，表示停留在用户书写笔迹界面；
    private boolean isShowingUserInput = false;
    private boolean isDisplayingUserStroke;//
    private OnAudioCompletedListener mCompletedListener = new OnAudioCompletedListener(this);
    /**
     * 是否正在书写
     */
    private volatile boolean isPractising = false;
    private UserStrokePath mUserStrokePath = new UserStrokePath(this);

    private StringBuilder mDemonstrationLog = new StringBuilder();

    private boolean isDetached = false;

    public ScalableCharView(Context context) {
        super(context);
        init();
    }

    public ScalableCharView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ScalableCharView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        mBgOutlinePaint = new Paint();
        mBgOutlinePaint.setAntiAlias(true);
        mBgOutlinePaint.setStyle(Style.STROKE);
        mBgOutlinePaint.setStrokeWidth(1);
        mBgOutlinePaint.setColor(mConfig.bgColor);

        mBgContentPaint = new Paint();
        mBgContentPaint.setColor(mConfig.bgColor);

        mDemoOutlinePaint = new Paint();
        mDemoOutlinePaint.setAntiAlias(true);
        mDemoOutlinePaint.setStyle(Style.STROKE);
        mDemoOutlinePaint.setStrokeWidth(mStrokeWidth);
        mDemoOutlinePaint.setColor(mConfig.demoColor);

        mDemoContentPaint = new Paint();
        mDemoContentPaint.setColor(mConfig.demoColor);

        mUserPathPaint = new Paint();
        mUserPathPaint.setColor(mConfig.userColor);
        mUserPathPaint.setStyle(Style.STROKE);
        mUserPathPaint.setAntiAlias(true);
        mUserPathPaint.setStrokeWidth(mConfig.userWidth);
        mUserPathPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mChar == null) {
            return;
        }
        canvas.save();
        canvas.translate(xOffset, yOffset);
        drawCharBackground(canvas);
        drawDemoLayer(canvas);
        if (isPractiseMode()) {
            drawUserLayer(canvas);//绘制已书写笔画的用户笔迹；
            drawUserInputPath(canvas);//绘制当前笔画的用户笔迹；
        }
        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (isDemonstrationMode()) {
            return super.onTouchEvent(event);
        }

        this.getParent().requestDisallowInterceptTouchEvent(true);

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                touchDown(event);
            }
            break;
            case MotionEvent.ACTION_MOVE: {
                touchMove(event);
            }
            break;
            case MotionEvent.ACTION_UP: {
                touchUp(event);
            }
            break;
            default:
                break;
        }

        return true;
    }

    private void touchDown(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();

        //在显示用户书写笔迹状态下触摸屏幕，将开启新的书写流程
        if (isShowingUserInput || isDisplayingUserStroke) {
            practise();
            return;
        }

        notifyOnStartWriting();
        Log.i(TAG, "touchDown: isPractising = " + isPractising + ", isDemoStarted = " + isDemoStarted);
        if (!isPractising) {//???
            stopPractise();//如果一个汉字书写完成后，需要先清除上一次书写的笔迹，再执行第一笔的演示与书写
            isPractising = true;
            demonstrateOneStroke(0);
            drawHighlightStroke(strokeIndex);//从非书写状态直接切换到书写状态，则绘制第一笔的书写背景；
        } else if (isDemoStarted) {//在笔画演示时触摸屏幕，停止演示，进入书写状态
            stopDemonstrate();
            //绘制书写背景，虽然调用stopDemonstrate()方法可能会触发onCancel回调，
            // 由于演示是另外一个线程中处理的，有可能在笔画演示刚好结束时调用stopDemonstrate()方法，
            // 则不会触发onCancel回调，就会出现当前笔画未绘制书写背景的情况。所有为保险起见，这里先绘制笔画书写背景；
            drawHighlightStroke(strokeIndex);
        }

        mUserStrokePath.moveTo(x, y);
    }

    private void touchMove(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        Log.i(TAG, "touchMove: x = " + x + ", y = " + y);
        userStrokeLineTo(x, y, false);
    }

    private void touchUp(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();

        if (!mUserStrokePath.isEmpty()) {
            userStrokeLineTo(x, y, true);
            stopDemonstrate();//判断笔迹前先停止描红；
            boolean pass = mUserStrokePath.evaluate(mChar.get(strokeIndex));
            invalidate();//刷新一下画布；
            if (pass) {
                drawUserStrokeToBuffer();
                if (strokeIndex < mChar.getCount() - 1) {
                    demonstrateOneStroke(strokeIndex + 1);
                    isNotified = false;
                } else {
                    isPractising = false;
                    if (!isNotified) {
                        isNotified = true;
                        boolean replay = notifyOnCompleteWriting(100);
                        if (replay) {
                            if (mAudioPlayer != null) {
                                mCompletedListener.userStrokeId = mUserStrokePath.getId();
                                mCompletedListener.type = CharView.AudioType.completed;
                                mAudioPlayer.setOnCompletedListener(mCompletedListener);
                            }
                        } else {
                            isShowingUserInput = true;
                        }
                        if (mAudioPlayer != null) {
                            mAudioPlayer.playAudio(getContext(), CybMediaPlayer.getCompletedWriteAudioId());
                        }
                    }
                }
            } else {
                drawHighlightStroke(strokeIndex);//绘制书写背景；
                playRetryTipAudio(mUserStrokePath.getId());
            }
        } else {
            drawHighlightStroke(strokeIndex);//绘制书写背景；
            playRetryTipAudio(0);
        }
    }

    private void userStrokeLineTo(int x, int y, boolean touchUp) {
        mUserStrokePath.lineTo(x, y, touchUp);
        invalidate();
    }

    public void drawUserStrokeToBuffer() {
        mUserStrokePath.draw(mUserStrokeLayer, mUserPathPaint);
    }

    private void playRetryTipAudio(long userStrokeId) {
        mCompletedListener.type = CharView.AudioType.bad;
        mCompletedListener.userStrokeId = userStrokeId;
        if (mAudioPlayer != null) {
            mAudioPlayer.setOnCompletedListener(mCompletedListener);
            mAudioPlayer.playAudio(getContext(), CybMediaPlayer.getErrorTipAudioId());
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (initLayers(w, h)) {
            invalidate();
        }
    }

    private boolean initLayers(int width, int height) {
        boolean success = false;
        if (width <= 0 || height <= 0) {
            return success;
        }

        if (width != mWidth || height != mHeight) {
            mWidth = width;
            mHeight = height;
            allocLayers();
            int sw = Math.min(mWidth, mHeight);
            mMaxScale = ((float) sw / (float) ORIGIN_CHARACTOR_WIDTH);
            if (scale <= 0) {
                setScale(mMaxScale);
            }
            reInit();
            setUserStroke();
            success = true;
        }

        return success;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (mAudioPlayer == null) {
            mAudioPlayer = new CybMediaPlayer();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        isDetached = true;
        if (mAudioPlayer != null) {
            try {
                if (mAudioPlayer.isPlaying()) {
                    mAudioPlayer.stop();
                }
                mAudioPlayer.release();
                mAudioPlayer = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        stopAll();
        recycle();
        super.onDetachedFromWindow();
    }

    private void reInit() {
        if (mChar != null) {
            stopPractise();
            resetDemonstration();
            stopPractise();
        }
    }

    //==================public methods==================
    @Override
    public void setMode(Mode m) {
        Log.i(TAG, "setMode: ");
    }

    @Override
    public void setColor(int color) {
        Log.i(TAG, "setColor: ");
    }

    @Override
    public void setWidth(int width) {
        Log.i(TAG, "setWidth: ");
        mStrokeWidth = width;
        init();
    }

    @Override
    public void setChar(Char c) {
        mChar = c;
        reInit();
    }

    @Override
    public Char getChar() {
        return mChar;
    }

    @Override
    public void setScale(float scale) {
        if (scale < 0.5) return;
        if (scale > mMaxScale) {
            scale = mMaxScale;
        }
        if (scale < mMaxScale) {
            xOffset = (int)(mWidth - ORIGIN_CHARACTOR_WIDTH*scale)/2;
            yOffset = (int)(mHeight - ORIGIN_CHARACTOR_WIDTH*scale)/2;
        } else {
            xOffset = 0;
            yOffset = 0;
        }

        if (mUserStrokePath != null) {
            mUserStrokePath.setOffset(xOffset, yOffset);
        }
        Log.i(TAG, "setScale: scale = " + scale);
        this.scale = scale;
        reInit();
    }

    @Override
    public void setStrokeConfig(StrokeConfig config) {
        mConfig = config;
        init();
    }

    @Override
    public StrokeConfig getStrokeConfig() {
        return mConfig;
    }

    @Override
    public void setEnableOriginal(boolean b) {
        Log.i(TAG, "setEnableOriginal: b = " + b);
    }

    @Override
    public void setenableOutline(boolean b) {
        Log.i(TAG, "setenableOutline: b = " + b);
    }

    @Override
    public void demonstrateOneStroke() {
        isDemoStarted = true;
        demonstrateStroke(strokeIndex, CharView.DemoType.one);
    }

    @Override
    public void demonstrateAllStrokes() {
        clearDemonstration();
        if (isDebugEnabled) {
            mDemonstrationLog = new StringBuilder();
        }
        isDemoStarted = true;
        demonstrateStroke(0, CharView.DemoType.all);
    }

    @Override
    public void pauseDemonstration() {
        isDemoPaused = true;
        if (mCurDemoTask != null) {
            mCurDemoTask.pause();
        }
    }

    @Override
    public void resumeDemonstration() {
        isDemoPaused = false;
        if (mCurDemoTask != null) {
            mCurDemoTask.resume();
        } else {
            //如果两个笔画之间暂停了，则继续演示下一个笔画
            demonstrateStroke(strokeIndex + 1, CharView.DemoType.all);
        }
    }

    @Override
    public void resetDemonstration() {
        stopDemonstrate();
    }

    @Override
    public void clearDemonstration() {
        isDemoStarted = false;
        mType = CharView.DemoType.none;
        clearDemoLayer();
        invalidate();
    }

    @Override
    public boolean isDemoStarted() {
        return isDemoStarted;
    }

    @Override
    public boolean isDemoPlaying() {
        return !isDemoPaused;
    }

    @Override
    public boolean isDemoPaused() {
        return isDemoPaused;
    }

    @Override
    public boolean isPractising() {
        return isPractising;
    }

    @Override
    public void practise() {
        if (isDetached) {
            return;
        }
        stopPractise();
        isPractising = true;
        mCompletedListener.type = CharView.AudioType.welcome;
        if (mAudioPlayer != null) {
            mAudioPlayer.setOnCompletedListener(mCompletedListener);
            mAudioPlayer.playAudio(getContext(), CybMediaPlayer.getStartWriteTipAudioId());
        }
    }

    @Override
    public void stopAll() {
        stopPractise();
    }

    @Override
    public void stopPractise() {
        strokeIndex = 0;
        isPractising = false;
        isNotified = false;
        isShowingUserInput = false;
        mUserStrokePath.reset(xOffset, yOffset);
        clearPractiseLayer();
        stopDemonstrate();
        if (mAudioPlayer != null) {
            mAudioPlayer.stopAudio();
        }
    }

    @Override
    public boolean isDemonstrationMode() {
        return mConfig == StrokeConfig.demo || mConfig == StrokeConfig.advance || mConfig == StrokeConfig.demo_emu;
    }

    @Override
    public boolean isPractiseMode() {
        return mConfig == StrokeConfig.write || mConfig == StrokeConfig.write_p16 || mConfig == StrokeConfig.write_p10;
    }

    @Override
    public boolean isAdvanceMode() {
        return mConfig == StrokeConfig.advance;
    }

    @Override
    public Bitmap getUserInputBitmap() {
        return mUserStrokeLayer;
    }

    @Override
    public void setUsetInputBitmap(Bitmap bitmap) {
        mUserStroke = bitmap;
    }

    @Override
    public void setOnCompleteWritingListener(MagicCharView.OnCompleteWritingListener listener) {
        mListener = listener;
    }


    private void notifyOnStartWriting() {
        if (mListener != null && isPractiseMode()) {
            mListener.onStartWriting(this);
        }
    }

    private boolean notifyOnCompleteWriting(int score) {
        if (mListener != null && isPractiseMode()) {
            return mListener.onCompleteWriting(this, score);
        }
        return true;
    }

    private void notifyOnCompleteDemonstrating() {
        if (mListener != null && isDemonstrationMode()) {
            mListener.onCompleteDemonstrating(this);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(mChar == null ? "" : mChar.ch + "-");
        sb.append(isDemonstrationMode() ? "DEMO" : "PRAC");
        return sb.toString();
    }

    @Override
    public void enableDebug(boolean enable) {
        isDebugEnabled = enable;
    }

    @Override
    public void skipDemoAudioMode(boolean skip) {
        skipAudioData = skip;
    }

    @Override
    public void setParams(MagicCharView.CharViewParams params) {
//        mMode = params.mMode;
        mConfig = params.mConfig;
//        setStrokeConfig(params.mConfig);
//        mColor = params.mColor;

//        enableOriginal = params.enableOriginal;
//        enableOutline = params.enableOutline;
//        isDebugEnabled = params.enableDebug;
        enableDebug(params.enableDebug);
//        mListener = params.mListener;
        if (isDebugEnabled) {
            mStrokeWidth = params.mWidth;
        }
        skipDemoAudioMode(params.skipStrokAudio);
        setOnCompleteWritingListener(params.mListener);
        mUserStroke = params.mUserBitmap;
        init();

//        scale = params.mScale;
        Log.i(TAG, "setParams: setScale = " + params.mScale);
        setScale(params.mScale);
        params.mScale = getScale();
    }

    @Override
    public StringBuilder getLogMsg() {
        return mDemonstrationLog;
    }
    //==================public methods==================

    private void setUserStroke() {
        if (mUserStroke != null && !mUserStroke.isRecycled()) {
            Canvas canvas = new Canvas(mUserStrokeLayer);
            Rect src = new Rect(0, 0, mUserStroke.getWidth(), mUserStroke.getHeight());
            Rect dst = new Rect(0, 0, mWidth, mHeight);
            canvas.drawBitmap(mUserStroke, src, dst, null);
            canvas.save(Canvas.ALL_SAVE_FLAG);
            canvas.restore();
            isDisplayingUserStroke = true;
            mUserStroke.recycle();
            mUserStroke = null;
        }
    }

    private void clearPractiseLayer() {
        isDisplayingUserStroke = false;
        if (mUserStrokeLayer != null && !mUserStrokeLayer.isRecycled()) {
            mUserStrokeLayer.eraseColor(Color.TRANSPARENT);
        }
    }

    private void clearDemoLayer() {
        if (mDemoLayer != null) {
            mDemoLayer.clearDemoLayer();
        }
    }

    private void stopDemonstrate() {
        Log.i(TAG, "stopDemonstrate: strokeIndex = " + strokeIndex);
        if (mCurDemoTask != null) {
            Log.i(TAG, "stopDemonstrate: cancel --> strokeIndex = " + strokeIndex);
            mCurDemoTask.cancel();
            mCurDemoTask = null;
        }
        //当此方法刚好在两笔之间调用时，onCancel()方法不会被调用，
        // 这里需要将演示停止，并将已绘制的内容清除。
        clearDemonstration();
    }

    //==========================================================

    private void allocLayers() {
        if (mWidth <= 0 || mHeight <= 0) {
            return;
        }

        createDemoLayer();
        createUserLayer();
        createFloodFillLayer();
    }

    private void createDemoLayer() {
        recycleDemoLayer();
        Bitmap demoBmp = createZoomOutLayer();
        mDemoLayer = new DemonstrateLayer(demoBmp);
    }

    private void recycleDemoLayer() {
        if (mDemoLayer != null) {
            mDemoLayer.recycle();
        }
    }

    private void createUserLayer() {
        recycleUserLayer();
        mUserStrokeLayer = createLayer();
    }

    private void recycleUserLayer() {
        if (mUserStrokeLayer != null && !mUserStrokeLayer.isRecycled()) {
            mUserStrokeLayer.recycle();
            mUserStrokeLayer = null;
        }
    }

    private void createFloodFillLayer() {
        recycleFloodFillLayer();
        mFloodFillLayer = createZoomOutLayer();
    }

    private void recycleFloodFillLayer() {
        if (mFloodFillLayer != null && !mFloodFillLayer.isRecycled()) {
            mFloodFillLayer.recycle();
            mFloodFillLayer = null;
        }
    }

    private Bitmap createZoomOutLayer() {
        int minWidth = (int) (ORIGIN_CHARACTOR_WIDTH * NewStroke.MIN_SCALE_FACTOR);
        int width = mWidth < minWidth ? minWidth : mWidth;
        int height = mHeight < minWidth ? minWidth : mHeight;
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_4444);
    }

    private Bitmap createLayer() {
        return Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_4444);
    }

    public void recycle() {
        recycleDemoLayer();
        recycleUserLayer();
        recycleFloodFillLayer();
    }

    private void drawCharBackground(Canvas canvas) {
        if (mChar == null) return;

        List<Stroke> strokes = mChar.getStrokes();
        for (int i = 0; i < strokes.size(); i++) {
            NewStroke ns = (NewStroke) strokes.get(i);
            ns.drawOutline(canvas, mBgOutlinePaint, scale);
            ns.drawContent(canvas, mBgContentPaint, scale);
        }
    }

    private void drawDemoLayer(Canvas canvas) {
        if (mDemoLayer != null) {
            mDemoLayer.draw(canvas, scale);
        }
    }

    /**
     * 绘制当前笔画的书写背景，与描红完成后的效果保持一致；
     */
    private void drawHighlightStroke(int index) {
        if (mChar == null || mDemoLayer == null) return;
        if (index != strokeIndex) {
            Log.i(TAG, "drawHighlightStroke: index != strokeIndex");
            return;
        }

        NewStroke ns = (NewStroke) mChar.getStrokes().get(index);
        mDemoLayer.drawHighlightStroke(ns, mDemoOutlinePaint, mDemoContentPaint, scale);
        invalidate();
    }

    private void drawUserLayer(Canvas canvas) {
        if (mUserStrokeLayer != null && !mUserStrokeLayer.isRecycled()) {
            canvas.drawBitmap(mUserStrokeLayer, 0, 0, null);
        }
    }

    private void drawUserInputPath(Canvas canvas) {
        mUserStrokePath.draw(canvas, mUserPathPaint);
    }

    private synchronized void demonstrateStroke(int index, CharView.DemoType type) {
        if (index < 0 || index >= mChar.getCount()) {
            Log.i(TAG, "demonstrateStroke: index out of boundary!!");
            return;
        }

        if (isDetached) {
            Log.i(TAG, "demonstrateStroke: isDetached = true");
            return;
        }

        if (isDemoPaused) {//处理两个笔画中间暂停的情况
            Log.i(TAG, "demonstrateStroke: isDemoPaused = true");
            return;
        }

        if (!isDemoStarted) {//处理两个笔画中间取消的情况
            Log.i(TAG, "demonstrateStroke: isDemoStarted = false");
            return;
        }

        if (isPractiseMode()) {//在书写模式下，书写状态停止，则停止演示下一笔画；
            if (!isPractising) {
                Log.i(TAG, "demonstrateStroke: isPractising = false");
                return;
            }
        }

        //防止启动多次演示；
        if (mCurDemoTask != null) {
            Log.i(TAG, "demonstrateStroke: mCurDemoTask != null");
            return;
        }

        Log.i(TAG, "demonstrateStroke: mType = " + type + ", strokeIndex = " + index);
        if (mAudioPlayer != null) {
            mAudioPlayer.stopAudio();
        }
        mType = type;
        strokeIndex = index;
        mCurDemoTask = new DemonstrateStrokeTask(index, mHandler, this, this);
        mCurDemoTask.execute();
    }

    //----------------------------------------------------------------------


    private void demonstrateOneStroke(int index) {
        //书写状态下，只演示当前书写笔画，每次演示时将先前的演示笔画清除掉，再重新开始；
        if (isPractiseMode()) {
            clearDemoLayer();
            isDemoStarted = true;
        }
        demonstrateStroke(index, CharView.DemoType.one);
    }

    private static class OnAudioCompletedListener implements MediaPlayer.OnCompletionListener {
        public int type = CharView.AudioType.none;
        /**
         * 在书写模式下，记录用户的书写笔迹的id号。
         * 每次书写完毕后，如果书写笔迹不正确，会发送提示语音。
         * 即提示语音与书写笔迹是一一对应的关系。在错误提示语音播放完毕之后，
         * 需要对笔迹id进行检查，如果id一致才重新播放当前笔画的演示。
         */
        public long userStrokeId = 0;

        private WeakReference<ScalableCharView> mReference;
        public OnAudioCompletedListener(ScalableCharView scv) {
            mReference = new WeakReference<ScalableCharView>(scv);
        }

        @Override
        public void onCompletion(MediaPlayer mp) {
            Log.i(TAG, "onCompletion --> type = " + type);
            ScalableCharView charView = mReference.get();
            if (charView != null) {
                switch (type) {
                    case CharView.AudioType.none:
                        break;
                    case CharView.AudioType.welcome:
                        //TODO
                        Log.i(TAG, "OnAudioCompletedListener AudioType.welcome");
                        charView.demonstrateOneStroke(0);
                        break;
                    case CharView.AudioType.good:
                        break;
                    case CharView.AudioType.bad: {
                        charView.onBadTipsComplete(userStrokeId);
                    }
                    break;
                    case CharView.AudioType.completed: {
                        charView.onStrokeComplete(userStrokeId);
                    }
                    break;
                    case CharView.AudioType.stroke: {
                    }
                    break;
                    default:
                        break;
                }
                userStrokeId = 0;
                type = CharView.AudioType.none;
            }
        }


        @Override
        public String toString() {
            return "" + type;
        }
    }

    private void onStrokeComplete(long id) {
        if (id == mUserStrokePath.getId()) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    practise();
                }
            });
        }
    }

    private void onBadTipsComplete(long id) {
        //1.在多次快速书写时，前一次错误书写提示语播放完毕时，需要判断isPractising是否为true，
        //因为此处为播放器线程，此时可能书写正确并结束了，需要检查一下isPractising的值；
        //2.这里还需要检查当前的书写笔迹id与启动语音时的书写笔迹id是否一致，否则不进行下一笔的演示；
        if (isPractising && id == mUserStrokePath.getId()) {
            //书写错误，将先前的书写笔迹清除，继续演示当前笔画
            mUserStrokePath.reset(xOffset, yOffset);
            demonstrateOneStroke(strokeIndex);
        }
    }

    //-----------------------IDemonstrateCallback----------------------------
    @Override
    public void onStart(int index) {
        Log.i(TAG, "onStart: index = " + index);
//        isDemoStarted = true;
    }

    @Override
    public void onPause(int index) {
        Log.i(TAG, "onPause: index = " + index);
        isDemoPaused = true;
    }

    @Override
    public void onResume(int index) {
        Log.i(TAG, "onResume: index = " + index);
        isDemoPaused = false;
    }

    @Override
    public void onCancel(int index) {
        Log.i(TAG, "onCancel: index = " + index);
        if (mCurDemoTask != null && mCurDemoTask.getIndex() == index) {
            mCurDemoTask = null;
        } else {
            Log.i(TAG, "onCancel: other demonstration task is started!!");
        }

        if (isDemonstrationMode()) {
            clearDemonstration();
        } else if (isPractiseMode() && isPractising) {
            //如果此时无正在执行的演示任务，则将isDemoStarted置为false；
            if (mCurDemoTask == null) {
                isDemoStarted = false;
            }
            //在书写模式下，书写过程中触摸屏幕会打断演示（见touchDown()方法），
            //需要将当前笔画显示为演示完成的颜色，提示进入书写状态；
            drawHighlightStroke(index);
        }
    }

    @Override
    public void onRefresh(int index) {
        invalidate();
    }

    @Override
    public void onFinish(int index) {
        Log.i(TAG, "onFinish: index = " + index + ", mType = " + mType);
        if (mCurDemoTask != null && mCurDemoTask.getIndex() == index) {
            mCurDemoTask = null;
        }
        //全字演示，用于描红演示
        if (mType == CharView.DemoType.all) {
            int count = mChar.getCount();
            if (index < count - 1) {
                demonstrateStroke(index + 1, mType);
            } else {
                resetDemonstration();
                notifyOnCompleteDemonstrating();//通知客户端演示已经结束
            }
        } else if (mType == CharView.DemoType.one) {//单笔演示，书写前的演示过程
            Log.i(TAG, "onFinish: mType = " + mType);
            isDemoStarted = false;
            mType = CharView.DemoType.none;
            drawHighlightStroke(index);//绘制书写背景；
        } else {
            Log.e(TAG, "onFinish: error demo type = " + mType);
        }
    }

    @Override
    public void onError(int index, Exception e) {
        Log.i(TAG, "onError: index = " + index + ", error = " + e.getMessage());
        if (!isDebugEnabled) {
            return;
        }

        mDemonstrationLog.append(mChar.ch).append(":").append("第").append(index+1).append("笔").append(", ").append(e.getMessage()).append("\n");
        if (mCurDemoTask != null && mCurDemoTask.getIndex() == index) {
            mCurDemoTask = null;
        }
        //全字演示，用于描红演示
        if (mType == CharView.DemoType.all) {
            int count = mChar.getCount();
            if (index < count - 1) {
                demonstrateStroke(index + 1, mType);
            } else {
                resetDemonstration();
                notifyOnCompleteDemonstrating();//通知客户端演示已经结束
            }
        }
    }

    //-----------------------IDemonstrateStrategy--------------------
    @Override
    public NewStroke getStroke(int index) {
        return (NewStroke) mChar.get(index);
    }

    @Override
    public Bitmap getFloodFillLayer() {
        return mFloodFillLayer;
    }

    @Override
    public DemonstrateLayer getDemonstrateLayer() {
        return mDemoLayer;
    }

    @Override
    public int getDrawIntervals() {
        return skipAudioData ? 0 : mConfig.drawInterval;
    }

    @Override
    public int getDotsOneDraw() {
        return mConfig.dotsPerDraw;
    }

    @Override
    public String getStrokeVoice(int index) {
        NewStroke stroke = getStroke(index);
        File audio = CybMediaPlayer.getStrokeAudioFile(getContext(), stroke.getBishun());
        return audio == null ? "" : audio.getAbsolutePath();
    }

    @Override
    public Paint getOutlinePaint() {
        return mDemoOutlinePaint;
    }

    @Override
    public float getScale() {
        return scale;
    }

    @Override
    public int getFillColor() {
        return mConfig.demoColor;
    }

    @Override
    public boolean isDebugEnabled() {
        return isDebugEnabled;
    }

    @Override
    public boolean isSkipAudioMode() {
        return skipAudioData;
    }

    @Override
    public int getTestDotsSize() {
        return mConfig.testBlockSize;
    }

    @Override
    public int[] getDebugBlockColors() {
        return new int[]{Color.GREEN, Color.BLUE};
    }

}
