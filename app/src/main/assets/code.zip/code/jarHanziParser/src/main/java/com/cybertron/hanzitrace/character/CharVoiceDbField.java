package com.cybertron.hanzitrace.character;

public interface CharVoiceDbField {
	String Phonetic = "Phonetic";
	String readVoc	= "readVoc";
	String spellVoc = "spellVoc";
}
