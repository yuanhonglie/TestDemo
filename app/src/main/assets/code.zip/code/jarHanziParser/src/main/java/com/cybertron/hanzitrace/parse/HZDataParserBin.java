package com.cybertron.hanzitrace.parse;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.cybertron.account.util.ArrayUtils;
import com.cybertron.account.util.AssetUtils;
import com.cybertron.account.util.BytesInputStream;
import com.cybertron.account.util.EndianUtils;
import com.cybertron.account.util.ListUtils;
import com.cybertron.account.util.RandomReader;
import com.cybertron.account.util.RawUtils;
import com.cybertron.encdes.EncDes;
import com.cybertron.enclib.EncTools;
import com.cybertron.enclib.EncTools.FlagCheck;
import com.cybertron.hanzitrace.parse.db.DbHelper;

import android.content.Context;
import android.content.res.AssetManager;
import android.text.TextUtils;
import android.util.Log;

//解析miaohong.bin
public class HZDataParserBin extends HZDataParser {
	private static final String TAG = HZDataParserBin.class.getSimpleName();

	private RandomReader reader;
	private Charset mCharset;
	private FileHeader mFileHeader;
	private GradeAddr mGradeAddr;
	private SearchManager mSearchMgr;
	private DbHelper mDbHelper;
	
	//-------------------
	/*private*/ HZDataParserBin(Context context, String path, String keyStr) {
		mCharset = Config.charset;
		mGradeAddr = new GradeAddr();
		
		copyToSdcard(context.getAssets());
		initQiaoVoiceBytes(context);
		
		try {
			reader = new RandomReader(path, Config.charset);
			if (TextUtils.isEmpty(keyStr)) {
				keyStr = EncTools.readKey(path);
			}
			if (isEncrypt(path, keyStr)) {
				EncDes enc = EncDes.create(path, keyStr/*EncConfig.KEY*/);
				reader.setEncDes(enc);
			}
			
			readFileHeader();
			
			mSearchMgr = new SearchManager(reader, mFileHeader.searchAddr);
			mDbHelper = new DbHelper(context, Config.dbPath);
		} catch (IOException e) {
			e.printStackTrace();
			Log.e(TAG, "汉字学习数据异常!");
		}
	}
	
	public void close() {
		Log.i(TAG, "close()");
		if (mDbHelper != null) mDbHelper.close();
		if (mGradeAddr != null) mGradeAddr.close();
		if (reader != null) reader.close();
		super.close();
	}
	
	public static boolean isEncrypt(String path, String keyStr) {
		return EncTools.isEncrypt(new File(path), 
				new FlagCheck() {
			@Override
			public boolean isValid(byte[] buf) {
				byte[] dest = FileHeader.ID.getBytes();
				if (buf != null) {
					if (   buf[0] == dest[0]
						&& buf[1] == dest[1]
						&& buf[2] == dest[2]
						&& buf[3] == dest[3]) {
						return true;
					}
				}
				return false;
			}
		}, keyStr);
	}
	
	private void copyToSdcard(AssetManager assetMgr) {
//		File file = Config.dbFile;
//		if (!file.exists()) {
			AssetUtils.copyFile(assetMgr, Config.dbName, Config.dbPath);
//		}
		
//		file = Config.file;
//		if (!file.exists()) {
//			AssetUtils.copyFile(assetMgr, Config.fileName, Config.filePath);
//		}
	}
	
	private void readFileHeader() throws IOException {
		FileHeader fh = new FileHeader();
		BytesInputStream bis = null;
		byte[] buf = new byte[FileHeader.SIZE];
		
		try {
			reader.seek(FileHeader.ADDR);
			reader.read(buf);
			
			bis = new BytesInputStream(buf, 0, buf.length);
			
			fh.iden = bis.readString(4);
			fh.version     = bis.readString(8);
			fh.type        = bis.readInt();
			fh.fileSize    = bis.readInt();
			fh.headSize  = bis.readInt();
			fh.createDate  = bis.readString(20);
			
			bis.setPostion(FileHeader.FILE_HEAD_SIZE);
			for (int i=0; i<FileHeader.GRADE_COUNT; i++) {
				fh.setAddr(i, bis.readInt());
			}
			
			fh.indexAddr = bis.readInt();
			fh.voiceAddr = bis.readInt();
			fh.searchAddr = bis.readInt();
			
			Log.i(TAG, fh.toString());
			
			if (fh.isValid()) {
				mFileHeader = fh;//OK
			} else {
				String text = "data is not valid, maybe mismatched version!";
				Log.e(TAG, text);
				throw new RuntimeException(text);
			}
		} finally {
			try {
				if (bis != null) bis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	private GradeIndex getGradeIndex(int grade) {
		GradeIndex gi = mGradeAddr.get(grade);
		if (gi != null) {
			return gi;
		}
		
		gi = new GradeIndex();
		
		BytesInputStream bis = null;
		byte[] buf = new byte[4];
		
		try {
			reader.seek(mFileHeader.getAddr(grade));
			reader.read(buf);
			
			gi.count = readCount(buf);
			
			buf = new byte[4*gi.count];
			reader.read(buf);
			bis = new BytesInputStream(buf);
			
			for (int i=0; i<gi.count; i++) {
				gi.add(bis.readInt());
			}
			
			mGradeAddr.set(grade, gi);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bis != null) bis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return gi;
	}
	
	private int readCount(byte[] buf) {
		return EndianUtils.le.getInt(buf, 0);
//		return 10;
	}
	
	public Char getChar(char ch) {
		Char mCh = null;
		IndexItem item = mSearchMgr.search(ch);
		if (item != null) {
			mCh = getChar(item.grade, item.order);
		}
		return mCh;
	}
	
	/** 
	 根据字和拼音获取Char，有可能没有
	 */
	public Char getChar(char ch, String spell) {
		List<IndexItem> items = mSearchMgr.searchItems(ch);
		if (ListUtils.isEmpty(items)) {
			return null;
		}
		for (IndexItem item:items) {
			Char chr = getChar(item.grade, item.order);
			if (chr != null) {
				if (chr.spell.equals(spell)) {
					return chr;
				}
			}
		}
		return null;
	}
	
	/** 
	 获取Char列表，有可能列表中只有一个，或者没有
	 */
	public List<Char> getChars(char ch) {
		List<Char> chars = new ArrayList<Char>();
		List<IndexItem> items = mSearchMgr.searchItems(ch);
		if (ListUtils.isEmpty(items)) {
			return chars;
		}
		for (IndexItem item:items) {
			Char chr = getChar(item.grade, item.order);
			if (chr != null) {
				if (!chars.contains(chr)) {//过滤掉字相同并且拼音相同的
					chars.add(chr);
				}
			}
		}
		return chars;
	}
	
	private int TAB_MAX = 3;
	public Char getChar(int grade, int index) {
		return getChar(grade, index, false);
	}
	
	public Char getChar(int grade, int index, boolean test) {
		Char mCh = null;
		
		GradeIndex gi = getGradeIndex(grade);
		
		BytesInputStream bis = null;
		byte[] buf = new byte[4];
		
		try {
			Char ch = new Char();
			
			int addr = mFileHeader.indexAddr + gi.get(index);
			ch.addr = addr;
			ch.order = index;
			
			reader.seek(addr);
			reader.read(buf);
			
			ch.length = EndianUtils.le.getInt(buf, 0);
			
			buf = new byte[ch.length];
			reader.read(buf);
			
			bis = new BytesInputStream(buf, mCharset);
			readBaseCharInfo(bis, buf, ch);
			
			String bishun = mDbHelper.getBishun(ch.ch);
			String msg = "grade:"+grade+", index:"+index+", "+ch.ch+"|"+bishun;
			ch.bishun = bishun;
			
			if (bishun == null) {
				showError(msg + ", get bishun failed!", test);
			} else {
				if (ch.strokeCount != bishun.length()) {
					showError(msg + ", "+ch.strokeCount+"!="+bishun.length(), test);
				}
			}
			
			for (int i=0; i<ch.strokeCount; i++) {
				ch.pointCounts.add(bis.readShort());
			}
			
			for (int i=0; i<ch.strokeCount; i++) {
				int count = ch.pointCounts.get(i);
				Stroke stroke = readStroke(bis, bis.getPostion(), count);
				patch1(ch.ch, i, stroke);
				stroke.bishun = bishun == null ? 'a' : bishun.charAt(i%bishun.length());
				ch.add(stroke);
			}
			
			patch3_tong_error(ch);
			
//			Log.i(TAG, ch.toString());
		
			mCh = ch;//OK
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (bis != null) bis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return mCh;
	}
	
	private void showError(String msg, boolean test) {
		String text = "error: " + msg;
		if (test) {
			throw new RuntimeException(text);
		} else {
			System.err.println(text);
		}
	}
	
	private String editSpell(byte[] buf) {
		String spell = Transcode.getSpell(buf);
		return spell;
	}
	
	public int getCount(int grade) {
		GradeIndex gi = getGradeIndex(grade);
		return gi.count;
	}
	
	public boolean hasVoice(Char ch) {
		return (ch.spellVoiceAddr != -1);
	}
	
	public byte[] getCharVoice(Char ch) {
		byte[] voiceBytes = null;
		BytesInputStream bis = null;
		
		if (!hasVoice(ch)) {
			return null;
		}
		
		voiceBytes = patch2_qiao_vioce(ch);
		if (!ArrayUtils.isEmpty(voiceBytes)) {
			return voiceBytes;
		}
		
		try {
			byte[] buf = new byte[4];
			
			int addr = mFileHeader.voiceAddr + ch.spellVoiceAddr;
			reader.seek(addr);
			reader.read(buf);
			
			int length = EndianUtils.le.getInt(buf, 0);
			
			buf = new byte[length];
			reader.read(buf);
			
			voiceBytes = buf; //OK
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bis != null) bis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return voiceBytes;
	}
	
	private Stroke readStroke(BytesInputStream bis, int pos, int count) {
		bis.setPostion(pos);
		Stroke stroke = new Stroke();
		for (int j=0; j<count; j++) {
			int x = bis.read();
			int y = bis.read();
			stroke.add(new CPoint(x, y));
		}
		return stroke;
	}
	
	public List<String> getChars(int grade) {
		List<String> chars = new ArrayList<String>();
		byte[] buf = new byte[2];
		
		try {
			GradeIndex gi = getGradeIndex(grade);
			
			for (int i=0; i<gi.size(); i++) {
				int addr = mFileHeader.indexAddr + gi.get(i);
				reader.seek(addr+4);
				reader.read(buf);
				chars.add(new String(buf, mCharset));
			}
			
//			Log.i(TAG, chars.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
		}
		
		return chars;
	}
	
	public Char getCharForTest(byte[] buf, int grade, int index) 
			throws IOException {
		return getChar(grade, index, true);
	}
	
	private void readBaseCharInfo(BytesInputStream bis, byte[] buf, Char ch)
			throws IOException {
		
		ch.length = buf.length;
		ch.ch = bis.readChar();
		ch.grade = bis.read();
		
		int start = bis.getPostion();
		int end = 0;
		
		int tabCount = 0;
		int pyPos = 0;
		for (int i=start; i<start+50 && i<buf.length; i++) {
			if (buf[i] == '\t') {
				tabCount++;
				end = i;
				if (tabCount >= TAB_MAX) {
					break;
				}
				if (tabCount == 2) {
					pyPos = i;
				}
			}
		}
		TAB_MAX = tabCount;
		
//		Log.i(TAG, ""+start+" --> " + end);
		String temp = new String(buf, start, end-start, mCharset);
		String[] strs = temp.split("\t");
		ch.radical = strs[0];
		ch.structure = strs[1];
		
		byte[] spBytes = Arrays.copyOfRange(buf, pyPos+1, end);
		ch.spell = editSpell(spBytes);
//		ch.spell = TAB_MAX >= 3 ? strs[2] : "<no spell>";
		ch.spell = ch.spell.replace("--", "-");
		
		bis.setPostion(end+1);
		ch.spellVoiceAddr = bis.readInt();
		ch.strokeCount = bis.read();
	}
	
	//-----------------
	/**<pre> 补丁1：进入“汉字学习”，点击搜索框输入字“然”，
	 * 进入此字描红界面，书写“犬”上的点始终书写不正确；
	 * 这个点的顺序反了，这里在程序中反转过来
	</pre> */
	private void patch1(char ch, int index, Stroke stroke) {
		if (ch == '然') {
			if (index == 7) {
				stroke.reverse();
			}
		}
	}
	
	
	/**<pre> 补丁2：
	 三年级第452个字"俏"的发音有歧义，在程序中替换掉
	 2362|俏|2|451|亻|左右|q-i-ào-qiào|0x017e75c5|9|sffksfrjj
	 六年级第112个字"俏"的发音有歧义，在程序中替换掉
	 2362|俏|5|111|亻|左右|q-i-ào-qiào|0x026c37b6|9|sffksfrjj
	 </pre> */
	private byte[] patch2_qiao_vioce(Char ch) {
		if ((ch.grade == 2 && ch.order == 451)
				|| (ch.grade == 5 && ch.order == 111)) {
			return qiaoVoiceBytes;
		}
		return null;
	}
	
	private byte[] qiaoVoiceBytes;
	private void initQiaoVoiceBytes(Context context) {
		if (qiaoVoiceBytes == null) {
			qiaoVoiceBytes = RawUtils.readRawToBuffer(
					context.getResources(), R.raw.patch_2_qiao);
		}
	}
	
	/**<pre> 
	 补丁3：汉字学习“童”字倒数2、3笔画描红顺序错误
	 补丁4：汉字学习“密”字第7、8笔画描红顺序错误
	 补丁5：汉字学习“匹”字第2、3、4笔画描红顺序错误
	 补丁6：汉字学习“片”字第2、3笔画描红顺序错误
	 补丁7：汉字学习“墨”字第6、7笔画描红顺序错误
	</pre> */
	private void patch3_tong_error(Char ch) {
		if (ch.ch == '童') {
			ch.patch3_swap_stroke();
		} else if (ch.ch == '密') {
			ch.patch4_swap_stroke();
		} else if (ch.ch == '匹') {
			ch.patch5_swap_stroke();
		} else if (ch.ch == '片') {
			ch.patch6_swap_stroke();
		} else if (ch.ch == '墨') {
			ch.patch7_swap_stroke();
		}
	}
}
