package com.cybertron.hanzitrace.parse;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Parcelable;
import android.util.Log;

import com.cybertron.account.book.Book;
import com.cybertron.account.util.ListUtils;
import com.cybertron.account.util.NetUtils;
import com.cybertron.encdes.EncDes;
import com.cybertron.hanzitrace.utils.StaticFinalUtil;

import java.util.ArrayList;
import java.util.List;

public class HanZiHelper {
	
	private static final boolean ISDUG = true;
	
	private static final String TAG = "HanZiHelper";
	
	private static HanZiHelper mHanZiHelper;

	private Context mContext;
	
	private List<Book> hzBooks;

	/**字库文件路径**/
	private String mTtfPath;
	
	/**汉字生字库book**/
	private Book phraseBk;
	
	/**汉字语音库book**/
	private Book charVoiceBk;
	
	/** 汉字硬笔书法索引*/
	private SQLiteDatabase mHPCSqLiteDatabase;
	
	public static HanZiHelper newIntance(Context context,List<Book> datas){
		if(mHanZiHelper == null){
			mHanZiHelper = new HanZiHelper(context,datas);
		}
		return mHanZiHelper;
	}
	
	public static HanZiHelper getIntance(){
		if(mHanZiHelper == null){
			throw new RuntimeException("please init HanZiHelper first!!");
		}
		return mHanZiHelper;
	}
	
	private HanZiHelper(Context context, List<Book> datas) {
		mContext = context;
		hzBooks = datas;
		check();
	}

	public void check() {
		checkWithInitHanziData();
		
		/**
		 * 检测汉字动画数据 
		 */
		new Thread(){
			public void run() {
				if(checkHanziFlashData()){
					logd("==汉字学习动画数据检测通过");
					initHanziFlashData();
				}
			};
		}.start();
	}

	/**
	 * 检测汉字学习数据
	 */
	private void checkWithInitHanziData() {
		List<Book> missbook = null;
		if(!ListUtils.isEmpty(hzBooks)){
			missbook = new ArrayList<Book>();
			for (int i = 0; i < hzBooks.size(); i++) {
				Book book = hzBooks.get(i);
				
				if(!book.getResName().equals("汉字动画库") && !book.isExists()){
					missbook.add(book);
				}else{
					if (book.getSuffix().equalsIgnoreCase(".ttf")) {
						mTtfPath = book.getLocalPath();
						logd("==ttf 数据检测通过");
					}
					
					if (HZDataParser.isUseNewDb()) {
						if (book.getResName().equals("汉字学习描红库")) {
							String key = book.getResKey();
							String path = book.getLocalPath();
							HZDataParser.initialize(mContext, path, key);
							logd("==HZDataParser 汉字学习描红库 初始化完成");
						}
					} else {
						if (book.getSuffix().equalsIgnoreCase(".bin")) {
							String binkey = book.getResKey();
							String binlocalpath = book.getLocalPath();
							HZDataParser.initialize(mContext, binlocalpath, binkey);
							logd("==HZDataParser 初始化完成");
						}
					}
					
					if (book.getResName().equals("汉字生字库") || book.getResName().equals("totalnewchnwords")) {
						phraseBk = book;
						logd("==汉字生字库检测通过");
					}
					if (book.getResName().equals("汉字动画库索引")) {
						String flashdbpath = book.getLocalPath();
						HZFlashParser.initialize(mContext, flashdbpath);
						logd("==HZFlashParser 初始化完成");
					}
					if (book.getResName().equals("汉字语音库")) {
						charVoiceBk = book;
						logd("==汉字语音库检测通过");
					}
					if(book.getResName().equals("汉字硬笔书法")){
						String hardPenCallGraillphyDbPath = book.getLocalPath();
						mHPCSqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(hardPenCallGraillphyDbPath, null);
						logd("==汉字硬笔书法索引检测通过");
					}
				}
			}
			if(missbook.size() > 0){
				startStoreDownload(missbook);
			}
		}
	}
	
	
	
	/**
	 *	检测汉字动画数据
	 * @return
	 */
	protected boolean checkHanziFlashData() {
		if(!ListUtils.isEmpty(hzBooks)){
			for (int i = 0; i < hzBooks.size(); i++) {
				Book bk = hzBooks.get(i);
				if(bk.getResName().equals("汉字动画库") && bk.isExists()){
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 初始化汉字动画数据
	 */
	protected void initHanziFlashData() {
		for (int i = 0; i < hzBooks.size(); i++) {
			Book book = hzBooks.get(i);
			if(book.getResName().equals("汉字动画库")){
				String flashbaskey = book.getResKey();
				String flashbaspath = book.getLocalPath();
				try {
					if(HZFlashParser.getInstance() != null){
						HZFlashParser.getInstance().initFlashBasinfo(flashbaskey, flashbaspath);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**获取字体TTF路径*/
	public String getTtfPath() {
		return mTtfPath;
	}

	/**
	 * 获取汉字语音库资源book
	 * @return
	 */
	public Book getCharVoiceBook() {
		return charVoiceBk;
	}
	
	/**
	 * 获取汉字生字库资源book
	 * @return
	 */
	public Book getPhraseBook() {
		return phraseBk;
	}
	
	/**
	 * 是否存在汉字硬笔书法视频
	 * 
	 * @param word
	 * @return
	 */
	public boolean existHardPenCalligraphyData(String word) {
		boolean exist = false;
		if (mHPCSqLiteDatabase != null) {
			Cursor cursor = null;
			try {
				String sql = "select " + StaticFinalUtil.TAB_COURSE_VIDEO + " from sf_courseTable where "
						+ StaticFinalUtil.TAB_COURSE_NAME + " = '" + word + "'";
				cursor = mHPCSqLiteDatabase.rawQuery(sql, null);
				if (cursor.moveToNext()) {
					int count = cursor.getCount();
					if (count > 0) {
						exist = true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
		}
		return exist;
	}
	
	public String getHardPenCalligraphyData(int index){
		String word = null;
		if (mHPCSqLiteDatabase != null) {
			Cursor cursor = null;
			try {
				String sql = "select " + StaticFinalUtil.TAB_COURSE_NAME + " from sf_courseTable where idx = '" + index + "'";
				Log.i(TAG, "sql :"+sql);
				cursor = mHPCSqLiteDatabase.rawQuery(sql, null);
				int count = cursor.getCount();
				Log.i(TAG, "count :"+count);
				if (count > 0) {
					while (cursor.moveToNext()) {
						word = cursor.getString(cursor.getColumnIndex(StaticFinalUtil.TAB_COURSE_NAME));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
		}
		return word;
	}
	
	/**
	 * 获取汉字硬笔书法视频地址
	 * 
	 * @param word
	 *            查询汉字
	 * @return
	 */
	public String getHardPenCalligraphyVideoPath(String word) {
		String videopath = null;
		if (mHPCSqLiteDatabase != null) {
			Cursor cursor = null;
			try {
				String sql = "select " + StaticFinalUtil.TAB_COURSE_VIDEO + " from sf_courseTable where "
						+ StaticFinalUtil.TAB_COURSE_NAME + " = '" + word + "'";
				cursor = mHPCSqLiteDatabase.rawQuery(sql, null);
				int count = cursor.getCount();
				if (count > 0) {
					while (cursor.moveToNext()) {
						byte[] buf = cursor.getBlob(cursor.getColumnIndex(StaticFinalUtil.TAB_COURSE_VIDEO));
						EncDes.decryptBuffer(buf,buf.length, StaticFinalUtil.DICT_DB_KEY);
						videopath = new String(buf,"UTF-8");
					}	
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
		}
		return videopath;
	}
	
	/**
	 * 获取汉字硬笔书法封面图片地址
	 * 
	 * @param word
	 * @return
	 */
	public String getHardPenCalligraphyScreenShotPath(String word) {
		String screenshotpath = null;
		if (mHPCSqLiteDatabase != null) {
			Cursor cursor = null;
			try {
				String sql = "select " + StaticFinalUtil.TAB_COURSE_SCREENSHOT + " from sf_courseTable where "
						+ StaticFinalUtil.TAB_COURSE_NAME + " = '" + word + "'";
				cursor = mHPCSqLiteDatabase.rawQuery(sql, null);
				int count = cursor.getCount();
				if (count > 0) {
					while (cursor.moveToNext()) {
						byte[] buf = cursor.getBlob(cursor.getColumnIndex(StaticFinalUtil.TAB_COURSE_SCREENSHOT));
						EncDes.decryptBuffer(buf,buf.length, StaticFinalUtil.DICT_DB_KEY);
						screenshotpath = new String(buf, "UTF-8");
					}	
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
		}
		return screenshotpath;
	}
	
	/**
	 * 跳转书城下载
	 * @param missbook
	 */
	private void startStoreDownload(List<Book> missbook) {
		try {
			if(NetUtils.isNetworkAvailable(mContext)){
				Intent intent = new Intent();
				intent.setAction("cybertron.intent.action.BOOKSTORE_DOWNLOAD");
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.putParcelableArrayListExtra("books",(ArrayList<? extends Parcelable>) missbook);
				mContext.startActivity(intent);	
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void close(){
		try {
			HZDataParser.getInstance().close();
			HZFlashParser.getInstance().closeDataBase();
			if (mHPCSqLiteDatabase != null) {
				mHPCSqLiteDatabase.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		mHanZiHelper = null;
	}
	
	private void logd(String msg){
		if(ISDUG){
			Log.i(TAG, msg);
		}
	}
}
