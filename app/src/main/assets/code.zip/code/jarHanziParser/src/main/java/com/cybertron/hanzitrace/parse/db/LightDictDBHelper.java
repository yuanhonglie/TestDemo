package com.cybertron.hanzitrace.parse.db;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;

import com.cybertron.account.book.Book;
import com.cybertron.account.book.BookUtils;
import com.cybertron.encdes.EncDes;

/**
 * 数据库常用操作的封装类
 * 
 */
public class LightDictDBHelper {
	private static final String TAG = "LightDictDBHelper";

	private SQLiteDatabase mSqLiteDatabase;
	
	private static LightDictDBHelper sLightDbHelper;
	
	/** 词典DB路径**/
	public static  String dbLoaclPath;		
	
	/**
	 * 初始化数据库
	 * @param context
	 * @param db_path		词典DB路径
	 * @param key	
	 */
	private LightDictDBHelper(Context context, String db_path, String key) {
		this.mSqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(db_path, null);
	}

	public static LightDictDBHelper newInstance(Context context,List<Book> appDatas) {
		if (sLightDbHelper == null) {
			initPath(appDatas);

			if (!TextUtils.isEmpty(dbLoaclPath) && new File(dbLoaclPath).exists()) {
				sLightDbHelper = new LightDictDBHelper(context, dbLoaclPath, null);
			}

		}
		return sLightDbHelper;
	}
	
	public boolean existDictData() {
		if (sLightDbHelper != null) {
			return true;
		}
		return false;
	}
	
	/**
	 * 初始化词典相关文件路径
	 * @param books
	 */
	private static void initPath(List<Book> books) {
		if(books != null && books.size() > 0){
			debug("==cidian 数据记录数 :"+books.size());
			List<Book> missbook = new ArrayList<Book>();
			for (int i = 0; i < books.size(); i++) {
				Book book = books.get(i);
				String localpath = book.getLocalPath();
				if(book.isZip()){
					if(BookUtils.isZipUp2Date(book)){
						File pFile = new File(localpath);
						File[] contents = pFile.listFiles();
						for (int j = 0; j < contents.length; j++) {
							if(contents[j].getAbsolutePath().contains("dict.db")){
								dbLoaclPath = contents[j].getAbsolutePath();  
							}
						}
						
						if(!TextUtils.isEmpty(dbLoaclPath)){
							File dblocalfile = new File(dbLoaclPath);
							if(!dblocalfile.exists()){
								BookUtils.deleteMd5File(localpath);
								missbook.add(book);
							}
						} else {
							BookUtils.deleteMd5File(localpath);
							missbook.add(book);
						}
					}
				}
			}
			debug("==cidian DB path:"+dbLoaclPath);
		}
	}
	
	public static LightDictDBHelper getInstance(){
		if (sLightDbHelper == null) {
			throw new RuntimeException("please init LightDictDBHelper first!!");
		}
		return sLightDbHelper;
	}
		
	/**
	 * 判断某张表是否存在
	 * 
	 * @param tableName
	 *            表名
	 * @return
	 */
	public boolean isTableExist(String tableName) {
		boolean result = false;
		if (tableName == null || mSqLiteDatabase == null) {
			return false;
		}
		try {
			Cursor cursor = null;
			String sql = "select count(1) as c from sqlite_master where type ='table' and name ='"
					+ tableName.trim() + "'";
			cursor = mSqLiteDatabase.rawQuery(sql, null);
			if (cursor.moveToNext()) {
				int count = cursor.getInt(0);
				if (count > 0) {
					result = true;
				}
			}
			cursor.close();
		} catch (Exception e) {
		}
		return result;
	}


	/**
	 * 关闭数据库
	 */
	public void closeDatabase() {
		if(mSqLiteDatabase != null) {
			mSqLiteDatabase.close();
			mSqLiteDatabase = null;
		}
		sLightDbHelper = null;
	}
	
	/**
	 * 查询单词，汉字或成语解释
	 * @param word 将要查询的词
	 * @param tablename  表
	 * @return
	 */
	public String getExplain(String word, String tablename) {
		String explain = null;
		Cursor mCursor = null;
		String sql = null;
		boolean isExist = isTableExist(tablename);
		debug("=======isTableExist("+tablename+")="+isExist+", word="+word);
		if (word != null && isExist) {
			ArrayList<String> explainlist = null;
			sql = "select explain from " + tablename+ " where word like " + "'" + word + "'";
			try {
				mCursor = mSqLiteDatabase.rawQuery(sql, null);
				int count  = mCursor.getCount();
				if(count > 0){
					explainlist = new ArrayList<String>();
					while (mCursor.moveToNext()) {
						byte[] buf = mCursor.getBlob(mCursor.getColumnIndex("explain"));
						EncDes.decryptBuffer(buf,buf.length, "2D367F67");
						String exp = new String(buf,"utf16-le");
						explainlist.add(exp.trim().toString());
					}
					
					explain = applyListToSting(explainlist);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(mCursor != null)
					mCursor.close();	
			}
		}
		return explain;
	}

	/**
	 * 将查询到的所有解释 合成
	 * @param list
	 * @return
	 */
	private String applyListToSting(ArrayList<String> list) {
		StringBuilder sb = new StringBuilder();
		if(list != null){
			for (int i = 0; i < list.size(); i++) {
				sb.append(list.get(i)+"\n");
			}
		}
		return sb.toString();
	}
	
	private static void debug(String msg){
		Log.i(TAG, msg);
	}
}
