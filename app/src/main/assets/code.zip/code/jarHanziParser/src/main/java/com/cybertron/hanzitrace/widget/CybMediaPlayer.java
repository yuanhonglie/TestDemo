package com.cybertron.hanzitrace.widget;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

import com.cybertron.account.util.AssetUtils;
import com.cybertron.account.util.FileUtils;
import com.cybertron.hanzitrace.parse.Config;
import com.cybertron.hanzitrace.parse.HZDataParser;
import com.cybertron.hanzitrace.parse.newdb.HZDataParserDb;

import android.content.Context;
import android.media.MediaPlayer;
import android.text.TextUtils;
import android.util.Log;

public class CybMediaPlayer extends MediaPlayer {
	
	private static final String TAG = CybMediaPlayer.class.getSimpleName();
	
//	private static CybMediaPlayer mMediaPlayer = new CybMediaPlayer();
	private OnCompletionListener mListener;
	public CybMediaPlayer() {
		super();
	}

//	public static CybMediaPlayer getInstance() {
//		return mMediaPlayer;
//	}
	
	public void stopAudio() {
		if (isPlaying()) {
			stop();
			try {
				prepare();
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public boolean playAudio(Context ctx, int resid) {
		String name = getAssetName(resid);
		
		//在P16上随机出现如下错误，这里打个补丁，重试3次；
		//06-29 13:58:13.600: I/CybMediaPlayer(9128): playAudio error2 = setDataSourceFD failed.: status=0x80000000
		int code, count = 0;
		do {
			code = playAudioHint(ctx, name);
			count++;
		} while (code == PlayerCode.ERROR_DATA_SOURCE && (count < 3));
		
		return code == PlayerCode.OK;
	}
	
	public boolean playAudio(Context ctx, char stroke) {
		char [] data = {stroke};
		String key = new String(data);
		String name = getStrokeAudioName(key);
		
		//在P16上随机出现如下错误，这里打个补丁，重试3次；
		//06-29 13:58:13.600: I/CybMediaPlayer(9128): playAudio error2 = setDataSourceFD failed.: status=0x80000000
		int code, count = 0;
		do {
			code = playAudioStroke(ctx, name, stroke);
			count++;
		} while (code == PlayerCode.ERROR_DATA_SOURCE && (count < 3));
		
		return code == PlayerCode.OK;
	}
	
	interface PlayerCode {
		int OK = 0;
		int ERROR_FILE_NAME_EMPTY = -1;
		int ERROR_FILE_COPY = -2;
		int ERROR_PLAYER_ILLEGAL_STATE = -3;
		int ERROR_DATA_SOURCE = -4;
		int ERROR_UNKNOWN = -5;
	}
	
	private int playAudioHint(Context ctx, String name) {
		if (TextUtils.isEmpty(name)) {
			return PlayerCode.ERROR_FILE_NAME_EMPTY;
		}
		String filePath = Config.ROOT_DIR+name;
		File file = new File(filePath);
		if (!file.exists()) {
			if(!AssetUtils.copyFile(ctx.getAssets(), name, filePath)) {
				Log.i(TAG, "copy failed");
				return PlayerCode.ERROR_FILE_COPY;
			}
		}
		return playFile(file);
	}

	public static File getStrokeAudioFile(Context ctx, char stroke) {
		char [] data = {stroke};
		String key = new String(data);
		String name = getStrokeAudioName(key);
		return getStrokeAudioFile(ctx, name, stroke);
	}

	private static File getStrokeAudioFile(Context ctx, String name, char stroke) {
		String filePath = Config.ROOT_DIR+name;
		File file = new File(filePath);
		if (!file.exists()) {
			if (HZDataParser.isUseNewDb()) {
				HZDataParserDb parserDb = (HZDataParserDb) HZDataParser.getInstance();
				if (parserDb == null) {
					Log.i(TAG, "copy failed: (parserDb == null)");
					return null;
				}

				byte[] vbytes = parserDb.getStrokeVoice(stroke);
				if (vbytes==null || vbytes.length<=0) {
					Log.i(TAG, "copy failed: (vbytes==null || vbytes.length<=0)");
					return null;
				}

				if (!FileUtils.writeFile(filePath, vbytes)) {
					Log.i(TAG, "copy failed: writeFile failed");
					return null;
				}
			} else {
				if(!AssetUtils.copyFile(ctx.getAssets(), name, filePath)) {
					Log.i(TAG, "copy failed");
					return null;
				}
			}
		}
		return file;
	}

	private int playAudioStroke(Context ctx, String name, char stroke) {
		if (TextUtils.isEmpty(name)) {
			return PlayerCode.ERROR_FILE_NAME_EMPTY;
		}

		File file = getStrokeAudioFile(ctx, name, stroke);
		if (file == null) {
			return PlayerCode.ERROR_FILE_COPY;
		}
		return playFile(file);
	}
	
	private int playFile(File file) {
		int retCode = PlayerCode.OK;
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			reset();
			setDataSource(fis.getFD());
			prepare();
			start();
			Log.i(TAG, "playAudio mListener = " + mListener);
			if (mListener != null) {
				setOnCompletionListener(mListener);
			}
		} catch (IllegalStateException e) {
			Log.e(TAG, "playAudio error1 = "+e.getMessage());
			retCode = PlayerCode.ERROR_PLAYER_ILLEGAL_STATE;
		} catch (IOException e) {
			String msg = e.getMessage();
			Log.e(TAG, "playAudio error2 = " + msg);
			retCode = PlayerCode.ERROR_UNKNOWN;
			//在P16上随机出现如下错误
			//06-29 13:58:13.600: I/CybMediaPlayer(9128): playAudio error2 = setDataSourceFD failed.: status=0x80000000
			if (msg.equals("setDataSourceFD failed.: status=0x80000000")) {
				retCode = PlayerCode.ERROR_DATA_SOURCE;
			}
		} finally {
			try {
				if (fis != null) fis.close();
			} catch (IOException e) {}
		}
		return retCode;
	}
	
	public void setOnCompletedListener(OnCompletionListener listener) {
		mListener = listener;
	}
	
	
	public static int getErrorTipAudioId() {
		return 403;
	}
	
	public static int getStartWriteTipAudioId() {
		return 501;
	}
	
	public static int getCompletedWriteAudioId() {
		return 201;
	}
	
	private static HashMap<Integer, String> mTipAudioMap = new HashMap<Integer, String>();
	static {
		mTipAudioMap.put(201, "sound/stroke201.mp3");
		mTipAudioMap.put(403, "sound/stroke403.mp3");
		mTipAudioMap.put(501, "sound/stroke501.mp3");
	}
	
	private static String getAssetName(int id) {
		return mTipAudioMap.get(id);
	}
	
	
	private static HashMap<String, String> mStrokeAudioMap = new HashMap<String, String>();
	static {
		mStrokeAudioMap.put("a", "strokes/a.mp3");
		mStrokeAudioMap.put("b", "strokes/b.mp3");
		mStrokeAudioMap.put("c", "strokes/c.mp3");
		mStrokeAudioMap.put("d", "strokes/d.mp3");
		mStrokeAudioMap.put("e", "strokes/e.mp3");
		mStrokeAudioMap.put("f", "strokes/f.mp3");
		mStrokeAudioMap.put("g", "strokes/g.mp3");
		mStrokeAudioMap.put("h", "strokes/h.mp3");
		mStrokeAudioMap.put("i", "strokes/i.mp3");
		mStrokeAudioMap.put("j", "strokes/j.mp3");
		mStrokeAudioMap.put("k", "strokes/k.mp3");
		mStrokeAudioMap.put("l", "strokes/l.mp3");
		mStrokeAudioMap.put("m", "strokes/m.mp3");
		mStrokeAudioMap.put("n", "strokes/n.mp3");
		mStrokeAudioMap.put("o", "strokes/o.mp3");
		mStrokeAudioMap.put("p", "strokes/p.mp3");
		mStrokeAudioMap.put("q", "strokes/q.mp3");
		mStrokeAudioMap.put("r", "strokes/r.mp3");
		mStrokeAudioMap.put("s", "strokes/s.mp3");
		mStrokeAudioMap.put("t", "strokes/t.mp3");
		mStrokeAudioMap.put("u", "strokes/u.mp3");
		mStrokeAudioMap.put("v", "strokes/v.mp3");
		mStrokeAudioMap.put("w", "strokes/w.mp3");
		mStrokeAudioMap.put("x", "strokes/x.mp3");
		mStrokeAudioMap.put("y", "strokes/y.mp3");
		mStrokeAudioMap.put("z", "strokes/z.mp3");
		mStrokeAudioMap.put("0", "strokes/0.mp3");
		mStrokeAudioMap.put("1", "strokes/1.mp3");
		mStrokeAudioMap.put("2", "strokes/2.mp3");
		mStrokeAudioMap.put("3", "strokes/3.mp3");
		mStrokeAudioMap.put("4", "strokes/4.mp3");
		mStrokeAudioMap.put("5", "strokes/5.mp3");
		mStrokeAudioMap.put("6", "strokes/6.mp3");
	}
	
	private static String getStrokeAudioName(String stroke) {
		return mStrokeAudioMap.get(stroke);
	}
}
