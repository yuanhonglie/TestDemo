package com.cybertron.hanzitrace.parse.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by yhl on 2017/12/21.
 */
public class BishunNameHelper extends SQLiteOpenHelper {

    public static final String TABLE = "names";
    private static final int DATABASE_VERSION = 7;

    public BishunNameHelper(Context context, String dbPath) {
        super(context, dbPath, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }


    public List<Bishun> getAllBishun() {
        List<Bishun> bishunList = new ArrayList<>(35);
        SQLiteDatabase db = getReadableDatabase();
        try {
            Cursor c = db.rawQuery("select * from " + TABLE, new String[0]);
            if (c != null) {
                if (c.moveToFirst()) {
                    do {
                        String idx = c.getString(c.getColumnIndex("idx"));
                        String name = c.getString(c.getColumnIndex("name"));
                        Bishun bs = new Bishun(idx, name);
                        bishunList.add(bs);
                    } while (c.moveToNext());
                }
                c.close();
            }
        } catch (Exception e) {
//			e.printStackTrace();
        } finally {
            if (db != null) {
                db.close();
            }
        }

        return bishunList;
    }

    public Map<String, Bishun> getBishunMap() {
        Map<String, Bishun> map = new HashMap<>();

        List<Bishun> bsList = getAllBishun();
        for (Bishun bs : bsList) {
            map.put(bs.getId(), bs);
        }

        return map;
    }

}
