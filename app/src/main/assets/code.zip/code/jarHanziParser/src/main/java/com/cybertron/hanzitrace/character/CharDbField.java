package com.cybertron.hanzitrace.character;

public interface CharDbField {
	String _id 			= "_id";
	String word 		= "word";
	String phonetic 	= "phonetic";
	String phrase 		= "phrase";
	String idioms 		= "idioms";
	String TJYC 		= "TJYC";
	String FYC 			= "FYC";
	String sentence 	= "sentence";
	String explain 		= "explain";
}
