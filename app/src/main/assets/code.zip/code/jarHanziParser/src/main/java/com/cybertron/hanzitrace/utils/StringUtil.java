package com.cybertron.hanzitrace.utils;

import java.util.LinkedList;
import java.util.List;

public class StringUtil {

	private static long lastClickTime;
	
	/**
	 * 去掉数组中重复的元素
	 * @param a
	 * @return
	 */
	public static String[] array_unique(String[] a){
		List<String> list = new LinkedList<String>();
		for(int i = 0; i < a.length; i++){
			if(!list.contains(a[i])) {
				list.add(a[i]);
			}
		} 
		return (String[])list.toArray(new String[list.size()]);
	}
	
	/**
	 * 获取list列表中某项的下标
	 * @param list
	 * @param object
	 * @return
	 */
	public static int getArrayIndex(List<String> list,String object){
		int index = 0;
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).equals(object)){
				index = i;
			}
		}
		return index;
	}
	
	/**
	 * 按钮是否双击
	 * @return
	 */
    public static boolean isFastDoubleClick() {  
        long time = System.currentTimeMillis();  
        long timeD = time - lastClickTime;  
        if ( 0 < timeD && timeD < 1000) {     
            return true;     
        }     
        lastClickTime = time;     
        return false;     
    } 
}
