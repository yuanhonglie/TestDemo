package com.cybertron.hanzitrace.parse;

/**<pre>
自造码转unicode
转码范围[33, 126]

     unicode
33  0x0251  ɑ
34  0x0101  ā
35  0x00E1  á
36  0x01CE  ǎ
37  0x00E0  à
38  0x014D  ō
39  0x00F3  ó

40  0x014F  ŏ
41  0x00F2  ò
42  0x0113  ē
43  0x00E9  é
44  0x011B  ě
45  0x00E8  è
46  0x012B  ī
47  0x00ED  í
48  0x01D0  ǐ
49  0x00EC  ì

50  0x016B  ū
51  0x00FA  ú
52  0x01D4  ǔ
53  0x00F9  ù
54  0x00FC  ü
55  0x01D6  ǖ
56  0x01D8  ǘ
57  0x01DA  ǚ
58  0x01DC  ǜ
59  0x00EA  ê

60  0x
61  0x1EBF  ế
62  0x
63  0x1EC1  ề
64  0x
65  0x1E3F  ḿ
66  0x
67  0x      //Unicode 未收此字符，要用组合字符 m&#x300; 显示
68  0x
69  0x0144  ń

70  0x0148  ň
71  0x01F8  ǹ
72  0x0261
73  0x0100  Ā
74  0x00C1  Á
75  0x01CD  Ǎ
76  0x00C0  À
77  0x014C  Ō
78  0x00D2  Ó
79  0x014E  Ŏ

80  0x00D3  Ò
81  0x0112  Ē
82  0x00C9  É
83  0x011A  Ě
84  0x00C8  È
85  0x
86  0x
87  0x
88  0x
89  0x

90  0x
91  0x
92  0x
93  0x
94  0x
95  0x
96  0x

97  =0x61 a
98  =0x62 b
99  =0x63 c
100 =0x64 d
101 =0x65 e
102 =0x66 f
103 =0x67 g
104 =0x68 h
105 =0x69 i
106 =0x6A j
107 =0x6B k
108 =0x6C l
109 =0x6D m
110 =0x6E n
111 =0x6F o
112 =0x70 p
113 =0x71 q
114 =0x72 r
115 =0x73 s
116 =0x74 t
117 =0x75 u
118 =0x76 v
119 =0x77 w
120 =0x78 x
121 =0x79 y
122 =0x7A z
123 =0x7B {
124 =0x7C |
125 =0x7D }
126 =0x7E ~

 </pre>*/
public class Transcode {

	private Transcode() {}

	private static final char[] table = new char[] {
			0x0251, //  ɑ    33 
			0x0101, //  ā    34 
			0x00E1, //  á    35 
			0x01CE, //  ǎ    36 
			0x00E0, //  à    37 
			0x014D, //  ō    38 
			0x00F3, //  ó    39 
			0x014F, //  ŏ    40 
			0x00F2, //  ò    41 
			0x0113, //  ē    42 
			0x00E9, //  é    43 
			0x011B, //  ě    44 
			0x00E8, //  è    45 
			0x012B, //  ī    46 
			0x00ED, //  í    47 
			0x01D0, //  ǐ    48 
			0x00EC, //  ì    49 
			0x016B, //  ū    50 
			0x00FA, //  ú    51 
			0x01D4, //  ǔ    52 
			0x00F9, //  ù    53 
			0x00FC, //  ü    54 
			0x01D6, //  ǖ    55 
			0x01D8, //  ǘ    56 
			0x01DA, //  ǚ    57 
			0x01DC, //  ǜ    58 
			0x00EA, //  ê    59 
			0     , //       60 
			0x1EBF, //  ế    61 
			0     , //       62 
			0x1EC1, //  ề    63 
			0     , //       64 
			0x1E3F, //  ḿ    65 
			0     , //       66 
			0     , //       67
			0     , //       68 
			0x0144, //  ń    69 
			0x0148, //  ň    70 
			0x01F8, //  ǹ    71 
			0x0261, //       72 
			0x0100, //  Ā    73 
			0x00C1, //  Á    74 
			0x01CD, //  Ǎ    75 
			0x00C0, //  À    76 
			0x014C, //  Ō    77 
			0x00D2, //  Ó    78 
			0x014E, //  Ŏ    79   
			0x00D3, //  Ò    80 
			0x0112, //  Ē    81 
			0x00C9, //  É    82 
			0x011A, //  Ě    83 
			0x00C8, //  È    84 
			0     , //       85 
			0     , //       86 
			0     , //       87 
			0     , //       88 
			0     , //       89 
			0     , //       90 
			0     , //       91 
			0     , //       92 
			0     , //       93 
			0     , //       94 
			0     , //       95 
			0     , //       96    
			0x0061, // a     97 
			0x0062, // b     98 
			0x0063, // c     99 
			0x0064, // d     100
			0x0065, // e     101
			0x0066, // f     102
			0x0067, // g     103
			0x0068, // h     104
			0x0069, // i     105
			0x006A, // j     106
			0x006B, // k     107
			0x006C, // l     108
			0x006D, // m     109
			0x006E, // n     110
			0x006F, // o     111
			0x0070, // p     112
			0x0071, // q     113
			0x0072, // r     114
			0x0073, // s     115
			0x0074, // t     116
			0x0075, // u     117
			0x0076, // v     118
			0x0077, // w     119
			0x0078, // x     120
			0x0079, // y     121
			0x007A, // z     122
			0x007B, // {     123
			0x007C, // |     124
			0x007D, // }     125
			0x007E, // ~     126
	}; 
	
	private static final int START = 33;
	private static final int END = START+table.length;
	
	/**<pre>
	 * 自造码转unicode 
	 * 转码范围[33, 126]</pre>
	 * @param a 自造码 byte
	 * @return unicode char; 如果失败则返回0
	 */
	public static char get(int a) {
		if (a < START || a >= END) {
			return 0;
		}
		
		a -= START;
		return table[a];
	}
	
	/**
	 * @param in 自造码
	 * @return unicode String
	 */
	public static String get(byte[] in) {
		if (in == null) {
			return null;
		}
		
		if (in.length == 0) {
			return null;
		}
		
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<in.length; i++) {
			char ch = get(in[i]);
			if (ch == 0) {
				sb.append((char)in[i]);
			} else {
				sb.append(ch);
			}
		}
		
		return sb.toString().trim();
	}
	
	private static final int FLAG = 0x7;
	/**
	 * 需转码的自造字标记：'0x7'<自造码>'0x7'
	 * @param in 自造码
	 * @return unicode String
	 */
	public static String getSpell(byte[] in) {
		if (in == null) {
			return null;
		}
		
		if (in.length == 0) {
			return null;
		}
		
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<in.length; i++) {
			if (in[i] == FLAG) {
				char ch = get(in[i+1]);
				if (ch == 0) {
					sb.append((char)in[i+1]);
				} else {
					sb.append(ch);
				}
				i+=2;
			} else {
				sb.append((char)in[i]);
			}
		}
		
		return sb.toString().trim();
	}
}
