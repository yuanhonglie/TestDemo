package com.cybertron.hanzitrace.parse.db;

public interface Name {
	String id = "_id";
	String idx = "idx";
	String name = "name";
}
