package com.cybertron.hanzitrace.parse.newdb;

public interface StrokeFlag {
	/** 旧格式 */
	int OLD = 1;
	/** 新格式 */
	int NEW = 2;
}
