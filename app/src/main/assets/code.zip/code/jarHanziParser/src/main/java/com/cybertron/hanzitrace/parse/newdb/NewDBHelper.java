package com.cybertron.hanzitrace.parse.newdb;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.util.SparseArray;

import com.cybertron.account.util.BytesInputStream;
import com.cybertron.encdes.EncDes;
import com.cybertron.hanzitrace.parse.CPoint;
import com.cybertron.hanzitrace.parse.Char;
import com.cybertron.hanzitrace.parse.Config;
import com.cybertron.hanzitrace.parse.HZDataParser;
import com.cybertron.hanzitrace.parse.Stroke;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
新的汉字学习数据库
----------------------------------------------------------
Table [CharacterInfo]       //描红数据，一部分字的数据还没有制作完成
        [_id]: INTEGER
        [character]: TEXT   //字符
        [radical]: TEXT     //部首
        [structure]: TEXT   //结构
        [spell]: TEXT       //拼音，多音字的多个拼音用分号分隔，例如色 s-è-sè;sh-ǎi-shǎi，拼音对应的语音数据，从专门的数据库获取相关信息
        [strokeCount]: INT  //笔画数
        [bishun]: TEXT      //笔顺，通过Stroke.idx查找对应的语音
        [strokes]: BLOB     //BOLD 描红数据：笔画1点数N1(2B)+笔画2点数N2(2B)+...+笔画n点数NN(2B)+笔画1笔点的坐标信息(N1*2B[x,y])+...+笔画N笔点的坐标信息(NN*2B[x,y])
        [flag]: INTEGER     //新旧格式数据标志，1-旧数据，2-新数据
------------------------------------------------------------
Table [Display]             //显示列表，大分组按年级分，组内按照笔画简单到复杂排列，可能重复，列表里面的所有字都要求在CharacterInfo有信息
        [_id]: INTEGER
        [grade]: INT        //年级
        [_order]: INT       //在本年级中的顺序
        [character]: TEXT   //字符
        [spell]: TEXT       //拼音
        [flag]: INTEGER     //新旧格式数据标志，1-旧数据，2-新数据
------------------------------------------------------------
Table [Stroke]
        [_id]: INTEGER
        [idx]: TEXT         //序号，[0-9a-z]，相关字段CharacterInfo.bishun
        [strokeName]: TEXT
        [strokeVoice]: BLOB //语音数据
------------------------------------------------------------
 */

@SuppressLint("UseSparseArrays")
public class NewDBHelper extends SQLiteOpenHelper {
	private static final String TAG = "NewDBHelper";
	private static final boolean DEBUG = false;
	
	private static final int DATABASE_VERSION = 1;
	
	public static final String TABLE_Display = "Display";
	public static final String TABLE_Stroke = "Stroke";
	public static final String TABLE_CharacterInfo = "CharacterInfo";
	
	private Charset mCharset = Config.charset;
	
	private static final boolean isEncrypt = true;
	
	public NewDBHelper(Context context, String dbPath) {
		super(context, dbPath, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		//不需要创建，直接打开已经生成好的数据
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		//不需要处理，直接打开已经生成好的数据
	}
	
	public Cursor query(String table, String[] columns, String selection,
			String[] selectionArgs, String groupBy, String having, String orderBy) {
		
		if (DEBUG) {
			StringBuffer sb = new StringBuffer();
			sb.append("query "+table);
			if (selection != null) {
				sb.append("selection="+selection);
			}
			if (selectionArgs != null) {
				sb.append("selectionArgs="+Arrays.toString(selectionArgs));
			}
			Log.i(TAG, sb.toString());
		}
		
		SQLiteDatabase db = getReadableDatabase();
		Cursor c = db.query(table, columns, selection, selectionArgs, groupBy, having, orderBy);
		if (c!=null && c.getCount()>0) {
			c.moveToFirst();
		}
		return c;
	}
	
	public Cursor query(String table, String[] columns, String selection, String[] selectionArgs) {
		return query(table, columns, selection, selectionArgs, null, null, null);
	}
	
	private Cursor queryStroke(char stroke) {
    	String selection = StrokeField.idx+"=?";
    	String[] selectionArgs = new String[]{""+stroke};
		return query(TABLE_Stroke, null, selection, selectionArgs, null, null, null);
	}
	
    private Cursor queryChar(String selection, String[] selectionArgs) {
    	return query(TABLE_CharacterInfo, null, selection, selectionArgs, null, null, null);
    }
    
    public Char getChar(char ch) {
    	try {
	    	TinyChar tc = getTinyChar(ch);
	    	if (tc == null) {
	    		return null;
	    	}
    		String selection = CharField.character+"=?";
    		String[] selectionArgs = new String[]{""+ch};
    		Cursor c = queryChar(selection, selectionArgs);
    		if (c != null) {
				Char chr = getChar(c);
				if (chr != null) {
					chr.grade = tc.getGrade();
					chr.order = tc.getOrder();
				}
				c.close();
				return chr;
			}
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return null;
    }
    
    public Char getChar(int grade, int index) {
    	Char ch = null;
    	
    	try {
	    	TinyChar tc = getTinyChar(grade, index);
	    	if (tc == null) {
	    		return null;
	    	}
	    	
	       	SQLiteDatabase db = getReadableDatabase();
	    	String sql = "SELECT * FROM "+TABLE_CharacterInfo+" WHERE "+CharField.character+"=\'"+tc.getChar()+"\'";
	    	Log.i(TAG, "[getChar] sql="+sql);
	    	
	    	Cursor c = db.rawQuery(sql, null);
	    	if (c != null) {
	    		if (c.getCount()>0) {
	    			c.moveToFirst();
	    			ch = getChar(c);
	    			if (ch != null) {
		    			ch.grade = tc.getGrade();
		    			ch.order = tc.getOrder();
	    			}
	    		}
	    		c.close();
	    	}
    	} catch (Exception e) {
    		ch = null;
    		e.printStackTrace();
		}
    	
    	return ch;
    }
    
    private Char getChar(Cursor c) {
    	try {
    		if (c == null) {
    			Log.e(TAG, "getChar, cursor is null");
    			return null;
    		}
    		if (c.getCount() <= 0) {
    			Log.e(TAG, "getChar, cursor.getCount() <= 0");
    			return null;
    		}
    		
    		Char cr = new Char();
    		
    		cr.addr    = 0;
    		String c1  = c.getString(c.getColumnIndex(CharField.character));
    		cr.ch      = c1.charAt(0);
    		cr.radical = c.getString(c.getColumnIndex(CharField.radical));
    		cr.structure = c.getString(c.getColumnIndex(CharField.structure));
    		cr.spell   = c.getString(c.getColumnIndex(CharField.spell));
    		cr.strokeCount = c.getInt(c.getColumnIndex(CharField.strokeCount));
    		cr.bishun  = c.getString(c.getColumnIndex(CharField.bishun));
    		
    		int idx = c.getColumnIndex(CharField.flag);
    		if (idx != -1) {
    			cr.flag = c.getInt(idx);
    		}
    		
    		byte[] ss = c.getBlob(c.getColumnIndex(CharField.strokes));
    		BytesInputStream bis = new BytesInputStream(ss, mCharset);
    		
//    		int judgeEncrypt = EndianUtils.le.getShort(ss, 0);
//    		Log.i(TAG, "judgeEncrypt = "+judgeEncrypt);
//    		if (judgeEncrypt<0 || judgeEncrypt>999) { //初步判断，超出范围时，认为是加密数据 }
    		if (isEncrypt) {
    			int key = (ss.length & 0xFFFFFFF0) | ((ss.length + 9) % 10);
    			EncDes enc = EncDes.create(ss.length, Integer.toHexString(key));
    			bis.setEncDes(enc);
    		}
    		
    		if (cr.flag == StrokeFlag.OLD) {
	    		for (int i=0; i<cr.strokeCount; i++) {
	    			cr.addPointCount(bis.readShort());
	    		}
	    		for (int i=0; i<cr.strokeCount; i++) {
	    			int count = cr.getPointCount(i);
	    			Stroke stroke = readStroke(bis, bis.getPostion(), count);
	    			char bishun = (cr.bishun == null ? 'a' : cr.bishun.charAt(i%cr.bishun.length()));
	    			stroke.setBishun(bishun);
	    			cr.add(stroke);
	    		}
    		} else if (cr.flag == StrokeFlag.NEW){
    			short stkCount = bis.readShort();
    			List<Short> stkOffsets = new ArrayList<Short>();
    			for (short i=0; i<stkCount; i++) {
    				stkOffsets.add(bis.readShort());
    			}
    			for (int i=0; i<stkOffsets.size(); i++) {
    				bis.seek(stkOffsets.get(i));
    				NewStroke stroke = readNewStroke(bis);
	    			char bishun = (cr.bishun == null ? 'a' : cr.bishun.charAt(i%cr.bishun.length()));
	    			stroke.setBishun(bishun);
	    			cr.add(stroke);
    			}
    		} else {
    			Log.e(TAG, "unknown stroke flag: " +cr.flag);
    		}
    		bis.close();
    		
    		
    		
    		return cr;
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return null;
    }
    
    private SparseArray<Integer> countCache = new SparseArray<Integer>();
    
    /** 获取指定年级的汉字数目  */
    public int getCount(int grade) {
    	int count = 0;
    	
    	if (isInvalidGrade(grade)) {
    		return 0;
    	}
    	
    	count = countCache.get(grade, 0);//从缓存直接获取查询结果
    	if (count > 0) {
    		return count;
    	}
    	
    	SQLiteDatabase db = getReadableDatabase();
    	String asField = "gradeCount";
    	String sql = "SELECT COUNT(*) AS "+asField+" FROM "+TABLE_Display+" WHERE "+DisplayField.grade+"="+grade;
    	sql =  appendFlag(sql);
    	Log.i(TAG, "[getCount] sql="+sql);
    	
    	Cursor c = db.rawQuery(sql, null);
    	if (c != null) {
    		if (c.getCount()>0) {
    			c.moveToFirst();
    			count = c.getInt(c.getColumnIndex(asField));
    		}
    		c.close();
    	}
    	if (count > 0) {
    		countCache.put(grade, count);//缓存查询结果
    	}
    	return count;
    }
    
    public List<TinyChar> getTinyChars(int grade) {
    	List<TinyChar> chars = new ArrayList<TinyChar>();
    	
    	if (isInvalidGrade(grade)) {
    		return chars;
    	}
    	
    	SQLiteDatabase db = getReadableDatabase();
    	String sql = "SELECT * FROM "+TABLE_Display+" WHERE "+DisplayField.grade+"="+grade;
    	sql = appendOrder(appendFlag(sql));
    	Log.i(TAG, "[getTinyChars] sql="+sql);
    	
    	Cursor c = db.rawQuery(sql, null);
    	if (c != null) {
    		if (c.getCount()>0) {
    			c.moveToFirst();
    			do {
    				TinyChar tc = TinyChar.valueOf(c);
    				chars.add(tc);
    			} while(c.moveToNext());
    		}
    		c.close();
    	}
    	
    	return chars;
    }
    
    public TinyChar getTinyChar(int grade, int order) {
    	String sql = "SELECT * FROM "+TABLE_Display+" WHERE "+DisplayField.grade+"="+grade+" AND "+DisplayField.order+"="+order;
    	return getTinyCharBySql(sql);
    }
    
    public TinyChar getTinyChar(char ch) {
    	String sql = "SELECT * FROM "+TABLE_Display+" WHERE "+DisplayField.character+"=\'"+ch+"\'";
    	return getTinyCharBySql(sql);
    }

    private TinyChar getTinyCharBySql(String sql) {
    	TinyChar tc = null;
    	
    	sql = appendFlag(sql);
    	
    	SQLiteDatabase db = getReadableDatabase();
    	Log.i(TAG, "[getTinyCharBySql] sql="+sql);
    	
    	Cursor c = db.rawQuery(sql, null);
    	if (c != null) {
    		if (c.getCount()>0) {
    			c.moveToFirst();
	    		tc = TinyChar.valueOf(c);
	    		if (tc != null) {
	    			Log.i(TAG, tc.toString());
	    		}
    		}
    		c.close();
    	}
    	
    	return tc;
    }
    
    private String appendFlag(String sql) {
    	if (!HZDataParser.SHOW_NEW_DATA) {
    		sql += " AND "+DisplayField.flag+"=1";//仅显示旧格式数据
    	}
    	return sql;
    }
    
    private String appendOrder(String sql) {
    	sql += " ORDER BY "+DisplayField.order+" ASC";
    	return sql;
    }
    
    private boolean isInvalidGrade(int grade) {
    	if (grade>=0 && grade<=5) {//1-6年级[0-5]
    		return false;
    	}
    	Log.e(TAG, "[isInvalidGrade] grade out of range: "+grade);
    	return true;
    }

    //========================
    /** 
        获取新数据(flag=2)
     */
    public List<TinyChar> getNewTinyChars() {
    	List<TinyChar> chars = new ArrayList<TinyChar>();
    	
    	String sql = "SELECT * FROM "+TABLE_Display+" WHERE "+DisplayField.flag+"=2";
    	
    	SQLiteDatabase db = getReadableDatabase();
    	Log.i(TAG, "[getNewTinyChars] sql="+sql);
    	
    	Cursor c = db.rawQuery(sql, null);
    	if (c != null) {
    		if (c.getCount()>0) {
    			c.moveToFirst();
    			do {
    				TinyChar tc = TinyChar.valueOf(c);
		    		if (tc != null) {
		    			chars.add(tc);
		    		}
    			} while(c.moveToNext());
    		}
    		c.close();
    	}
    	
    	return chars;
    }
    
    public Char getChar(TinyChar tc) {
    	Char ch = null;
    	
    	try {
	    	if (tc == null) {
	    		return null;
	    	}
	    	
	       	SQLiteDatabase db = getReadableDatabase();
	    	String sql = "SELECT * FROM "+TABLE_CharacterInfo+" WHERE "+CharField.character+"=\'"+tc.getChar()+"\'";
	    	Log.i(TAG, "[getChar] sql="+sql);
	    	
	    	Cursor c = db.rawQuery(sql, null);
	    	if (c != null) {
	    		if (c.getCount()>0) {
	    			c.moveToFirst();
	    			ch = getChar(c);
	    			if (ch != null) {
		    			ch.grade = tc.getGrade();
		    			ch.order = tc.getOrder();
	    			}
	    		}
	    		c.close();
	    	}
    	} catch (Exception e) {
    		ch = null;
    		e.printStackTrace();
		}
    	
    	return ch;
    }
    
    //========================
	private Stroke readStroke(BytesInputStream bis, int pos, int count) {
		bis.setPostion(pos);
		Stroke stroke = new Stroke();
		for (int j=0; j<count; j++) {
			int x = bis.read();
			int y = bis.read();
			stroke.add(new CPoint(x, y));
		}
		return stroke;
	}
	
	private NewStroke readNewStroke(BytesInputStream bis) throws IOException {
		short baseOft = (short) bis.getPostion();
		
		NewStroke stroke = new NewStroke();
		
		int x = bis.read();
		int y = bis.read();
		CPoint startPt = new CPoint(x, y);
		stroke.setStartPoint(startPt);
		
		short lineCount = bis.readShort();
		List<Short> lineOfts = new ArrayList<Short>();
		for (short i=0; i<lineCount; i++) {
			lineOfts.add(bis.readShort());
		}
		for (short oft:lineOfts) {
			bis.seek(baseOft+oft);
			StkLine line = readStkLine(bis);
			stroke.addLine(line);
		}
		return stroke;
	}
	
	private StkLine readStkLine(BytesInputStream bis) throws IOException {
		short type = bis.readShort();
		short ptCount = bis.readShort();
		
		StkLine line = new StkLine();
		line.setType(type);
		
		for (int j=0; j<ptCount; j++) {
			int x = bis.read();
			int y = bis.read();
			line.add(new CPoint(x, y));
		}
		return line;
	}
	
	public byte[] getStrokeVoice(char stroke) {
	   	try {
	    	Cursor c = queryStroke(stroke);
	    	if (c == null) {
	    		Log.e(TAG, "[getStrokeVoice] cursor is null");
	    		return null;
	    	}
	    	if (c.getCount() <= 0) {
	    		Log.e(TAG, "[getStrokeVoice] cursor.getCount() <= 0");
	    		c.close();
	    		return null;
	    	}
	    	byte[] voice = c.getBlob(c.getColumnIndex(StrokeField.strokeVoice));
	    	c.close();
	    	return voice;
    	} catch (Exception e) {
    		e.printStackTrace();
		}
    	return null;
	}
}
