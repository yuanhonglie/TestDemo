package com.cybertron.hanzitrace.parse.newdb;

import android.graphics.Path;

import java.util.ArrayList;
import java.util.List;

import com.cybertron.hanzitrace.parse.CPoint;
import com.cybertron.hanzitrace.widget.Spline;

public class StkLine {
	
	private int type = LineType.line;
	
	private List<CPoint> points;
	
	public StkLine() {
		points = new ArrayList<CPoint>();
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void add(CPoint point) {
		points.add(point);
	}

	public CPoint get(int index) {
		return points.get(index);
	}
	
	public List<CPoint> getPoints() {
		return points;
	}
	
	public int getCount() {
		return points.size();
	}

	public Path getPath(Path path, float scale) {
		if (type == LineType.spline) {
			return splineUp(path, scale);
		} else {
			return lineUp(path, scale);
		}
	}

	private Path lineUp(Path path, float scale) {
		for (int i = 0; i < points.size(); i++) {
			CPoint next = points.get(i).scale(scale);
			if (path.isEmpty()) {
				path.moveTo(next.x, next.y);
			}
			path.lineTo(next.x, next.y);
		}

		return path;
	}

	private Path splineUp(Path path, float scale) {
		return Spline.getSplinePath(path, points, scale);
	}

	@Override
	public String toString() {
		return "StkLine["+type+"|"+points.toString()+"]";
	}
}
