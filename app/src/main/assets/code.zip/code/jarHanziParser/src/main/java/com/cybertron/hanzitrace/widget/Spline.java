package com.cybertron.hanzitrace.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;

import com.cybertron.hanzitrace.parse.CPoint;
import com.cybertron.hanzitrace.parse.CPointF;

import java.util.ArrayList;
import java.util.List;


/**
 * 样条曲线。每根样条曲线包含4个控制点
 */
public class Spline {
    private static final String TAG = "Spline";
    /**样点数。在点Pk和Pk+1之间，将会生成若干个样点。所以"u"将会从0.00F增长到0.05F.*/
    private static final int SAMPLE_POINT_COUNT = 20;
    /**在基数算法中的t*/
    private static final float TENSION = 0.5F;
    /**"Pk-1"点(起始控制点)*/
    private PointF mStartControlPoint;
    /**"Pk"点(起始点)*/
    private PointF mStartPoint;
    /**"Pk+1"点(结束点)*/
    private PointF mEndPoint;
    /**"Pk+2"点(结束控制点)*/
    private PointF mEndControlPoint;
    /**曲线点(控制点及模拟的样点)*/
    private PointF[] mCtrlPoints;

    /**
     * 标识当前样条曲线是否是第一条，如果是m_startControlPoint 和 m_startPoint将会相同。
     * 因为在Pk和Pk+1之间需要4个点来决定样条曲线，所以我们需要在Pk-1点前手动添加一个点。
     * 这样我们才能在Pk-1和Pk+1之间绘制样条曲线。
     * 同样的，最后一根样条曲线的Pk+2点会与它的"Pk+1"点相同，
     * 这样我们才能在Pk+1和Pk+2之间绘制样条曲线。
     */
    private boolean isFirst = false;


    public Spline() {
        mStartControlPoint = new PointF();
        mStartPoint = new PointF();
        mEndPoint = new PointF();
        mEndControlPoint = new PointF();
        mCtrlPoints = new PointF[SAMPLE_POINT_COUNT + 1];
        for (int i = 0; i < mCtrlPoints.length; i++) {
            mCtrlPoints[i] = new PointF();
        }
    }

    /**
     * 添加关节。将新控制点添加到控制点列表中，并更新前面的样条曲线。
     *
     * @param prevSpline   前一根样条曲线
     * @param currentPoint 当前点
     */
    public void addJoint(Spline prevSpline, PointF currentPoint) {
        //前一根样条曲线(prevSpline)为null，说明控制点列表中只有一个点，所以4个控制点样同。
        //当第2个及之后的控制点添加到控制点列表中时，那第1根样条曲线的Pk+1和Pk+2点需要更新
        if (null == prevSpline) {
            this.mStartControlPoint = currentPoint;
            this.mStartPoint = currentPoint;
            this.mEndPoint = currentPoint;
            this.mEndControlPoint = currentPoint;
            this.isFirst = true;
        } else//前一根样条曲线不为null，所以更新前一根样条曲线的控制点列表，同时更新当前样条曲线的控制点列表。
        {
            //前一根样条曲线是第1根样条曲线，更新它的Pk+1和Pk+2点
            if (true == prevSpline.isFirst) {
                this.mStartControlPoint = prevSpline.mStartControlPoint;
                this.mStartPoint = prevSpline.mStartPoint;
                this.mEndPoint = currentPoint;
                this.mEndControlPoint = currentPoint;
                generateSamplePoint();
                return;
            } else///前一根样条曲线不是第1根样条曲线，仅更新它的Pk+2点
            {
                prevSpline.mEndControlPoint = currentPoint;
                prevSpline.generateSamplePoint();

                //模拟当前样条曲线的样点
                this.mStartControlPoint = prevSpline.mStartPoint;
                this.mStartPoint = prevSpline.mEndPoint;
                this.mEndPoint = currentPoint;
                this.mEndControlPoint = currentPoint;
                generateSamplePoint();
            }
        }
    }

    /**
     * 使用基数算法生成样点
     */
    public void generateSamplePoint() {
        PointF startControlPoint = this.mStartControlPoint;
        PointF startPoint = this.mStartPoint;
        PointF endPoint = this.mEndPoint;
        PointF endControlPoint = this.mEndControlPoint;
        float step = 1.0F / (float) SAMPLE_POINT_COUNT;
        float uValue = 0.00F;

        for (int i = 0; i < SAMPLE_POINT_COUNT; i++) {
            PointF pointNew = generateSimulatePoint(uValue, startControlPoint, startPoint, endPoint, endControlPoint);
            mCtrlPoints[i] = pointNew;
            uValue += step;
        }
        mCtrlPoints[mCtrlPoints.length - 1] = endPoint;
    }

    /**
     * 绘制样条曲线
     *
     * @param g
     * @param pen
     */
    public void draw(Canvas g, Paint pen) {
        for (int i = 0; i < mCtrlPoints.length - 1; i++) {
            PointF lastPoint = mCtrlPoints[i];
            PointF nextPoint = mCtrlPoints[i + 1];
            g.drawLine(lastPoint.x, lastPoint.y, nextPoint.x, nextPoint.y, pen);
        }
    }

    public Path getPath(Path path) {
        for (int i = 1; i < mCtrlPoints.length; i++) {
            if (path.isEmpty()) {
                path.moveTo(mCtrlPoints[i].x, mCtrlPoints[i].y);
            }
            path.lineTo(mCtrlPoints[i].x, mCtrlPoints[i].y);
        }
        return path;
    }

    /**
     * 生成曲线模拟点，该点在startPoint和endPoint之间
     *
     * @param u                 介于0和1之间的变量
     * @param startControlPoint 起始点startPoint之前的控制点, 协助确定曲线的外观
     * @param startPoint        目标曲线的起始点startPoint,当u=0时，返回结果为起始点startPoint
     * @param endPoint          目标曲线的结束点endPoint, 当u=1时,返回结果为结束点endPoint
     * @param endControlPoint   在起结点startPoint之后的控制点, 协助确定曲线的外观
     * @return 返回介于startPoint和endPoint的点
     */
    private PointF generateSimulatePoint(float u,
                                         PointF startControlPoint,
                                         PointF startPoint,
                                         PointF endPoint,
                                         PointF endControlPoint) {
        float s = (1 - TENSION) / 2;
        PointF resultPoint = new PointF();
        resultPoint.x = calculateAxisCoordinate(startControlPoint.x, startPoint.x, endPoint.x, endControlPoint.x, s, u);
        resultPoint.y = calculateAxisCoordinate(startControlPoint.y, startPoint.y, endPoint.y, endControlPoint.y, s, u);
        return resultPoint;
    }

    /**
     * 计算轴坐标
     *
     * @param a
     * @param b
     * @param c
     * @param d
     * @param s
     * @param u
     * @return
     */
    private float calculateAxisCoordinate(float a, float b, float c, float d, float s, float u) {
        float result = 0.0F;
        result = a * (2 * s * u * u - s * u * u * u - s * u)
                + b * ((2 - s) * u * u * u + (s - 3) * u * u + 1)
                + c * ((s - 2) * u * u * u + (3 - 2 * s) * u * u + s * u)
                + d * (s * u * u * u - s * u * u);
        return result;
    }

    /**
     * 获取样条曲线上的点
     *
     * @param points
     * @return
     */
    public List<PointF> fetchPoints(PointF[] points) {
        if (points == null || points.length <= 0) {
            return null;
        }

        List<Spline> splines = new ArrayList<Spline>();
        Spline splineNew = null;
        Spline lastNew = null;
        for (PointF nowPoint : points) {
            if (null == splines || 0 == splines.size()) {
                splineNew = new Spline();
                splineNew.addJoint(null, nowPoint);
                splines.add(splineNew);
            } else {
                splineNew = new Spline();
                lastNew = splines.get(splines.size() - 1);
                splineNew.addJoint(lastNew, nowPoint);
                splines.add(splineNew);
            }
        }

        List<PointF> outPoints = new ArrayList<PointF>();
        for (Spline spline : splines) {
            if (spline.isFirst) {
                continue;
            }
            for (PointF point : spline.mCtrlPoints) {
                if (outPoints.contains(point)) {
                    continue;
                }

                outPoints.add(point);
            }
        }
        return outPoints;
    }

    public static Path getSplinePath(Path path, CPoint[] points) {
        return getSplinePath(path, points, 1.0f);
    }

    public static Path getSplinePath(Path path, CPointF[] points) {
        return getSplinePath(path, points, 1.0f);
    }

    public static Path getSplinePath(Path path, CPoint[] points, float scale) {
        CPointF[] pfs = new CPointF[points.length];
        for (int i = 0 ; i < points.length; i++) {
            pfs[i] = new CPointF(points[i].x, points[i].y);
        }
        return getSplinePath(path, pfs, scale);
    }

    public static Path getSplinePath(Path path, List<CPoint> points, float scale) {
        CPointF[] pfs = new CPointF[points.size()];
        for (int i = 0 ; i < points.size(); i++) {
            pfs[i] = new CPointF(points.get(i).x, points.get(i).y);
        }
        return getSplinePath(path, pfs, scale);
    }

    /**
     * 绘制样条曲线
     * @param points
     * @param scale
     * @return
     */
    public static Path getSplinePath(Path path, CPointF[] points, float scale) {
        if (points == null || points.length <= 0) {
            return path;
        }
        List<Spline> splines = new ArrayList<Spline>();
        Spline splineNew = null;
        Spline lastNew = null;
        for (CPointF point : points) {
            CPointF nowPoint = point.scale(scale);
            if (null == splines || 0 == splines.size()) {
                splineNew = new Spline();
                splineNew.addJoint(null, nowPoint);
                splines.add(splineNew);
            } else {
                splineNew = new Spline();
                lastNew = splines.get(splines.size() - 1);
                splineNew.addJoint(lastNew, nowPoint);
                splines.add(splineNew);
            }
        }


        Spline spline = null;
        for (int i = 0; i < splines.size(); i++) {
            spline = splines.get(i);
            if (spline.isFirst) {
                continue;
            }
            //spline.draw(g, pen);
            //Log.i(TAG, "getSplinePath: spline = " + logArray(spline.mCtrlPoints));
            spline.getPath(path);
        }

        return path;
    }

    private static String logArray(PointF[] array) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (PointF point : array) {
            sb.append("(").append(point.x).append(",").append(point.y).append(")").append(", ");
            //sb.append(point).append(",");
        }
        sb.append("]");
        return sb.toString();
    }

}

