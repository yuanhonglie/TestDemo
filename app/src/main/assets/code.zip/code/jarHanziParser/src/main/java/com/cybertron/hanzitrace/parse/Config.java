package com.cybertron.hanzitrace.parse;

import java.io.File;
import java.nio.charset.Charset;

import android.os.Environment;

public class Config {
	public static final String charsetName = "GBK";
	public static final Charset charset = Charset.forName(charsetName);
	
	public static final String ROOT_DIR = Environment.getExternalStorageDirectory().getPath() + "/.cybertron/res/hanzi/";
	public static final String filePath = "/sdcard/.cybertron/res/0/0/0/0/__res__6d69616f686f6e67.bin";
	public static final File file = new File(filePath);
	
	public static final String dbName = "bishun.db";
	public static final String dbPath = ROOT_DIR + dbName;
	public static final File dbFile = new File(dbPath);
	
	/**汉字学习flash表名**/ 
	public static final String FLASH_DB_TABLE_NAME = "hzflashbank";
	/** 汉字学习flash开始地址**/
	public static final String FLASH_ADDR_BEGIN = "HZFlashAddrBeg";
	/** 汉字学习flash结束地址*/
	public static final String FLASH_ADDR_END = "HZFlashAddrEnd";
	/** 汉字学习flash封面开始地址**/
	public static final String FLASH_COVER_ADDR_BRGIN = "HZPictureAddrBeg";
	/** 汉字学习flash封面结束地址*/
	public static final String FLASH_COVER_ADDR_END = "HZPictureAddrEnd";
	
	/** 汉字学习flash数据库路径*/
	public static final String Flash_db_path = ROOT_DIR +"hzflashbankdb.db";
	/** 汉字学习flash数据路径*/
	public static final String Flash_bas_path = ROOT_DIR +"hzflashbank.bas";
	
	private Config() {}
}
