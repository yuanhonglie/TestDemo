package com.cybertron.hanzitrace.character;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class CharVoiceDbHelper extends SQLiteOpenHelper {
	public static final String TAG = "CharVoiceDbHelper";
	public static final String TABLE = "chnvoicetbl";
	private static final int DATABASE_VERSION = 1;
	public CharVoiceDbHelper(Context context, String dbPath) {
		super(context, dbPath, null, DATABASE_VERSION);
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		Log.i(TAG, "onUpgrade ---> oldVersion = " + oldVersion + ", newVersion = " + newVersion);
		onCreate(db);
	}
	
	@Override
	public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.i(TAG, "onDowngrade ---> oldVersion = " + oldVersion + ", newVersion = " + newVersion);
		onCreate(db);
	}
	
	public byte [] getReadVoiceBuffer(String phonetic) {
		byte [] buffer = null;
		SQLiteDatabase db = null;
		Cursor c = null;
		try {
			db = getReadableDatabase();
			phonetic = cutSpell(phonetic);
			String[] args = getPossiblePhonetics(phonetic);
			String selection = getSelection(args.length);
			Log.i(TAG, "getReadVoiceBuffer phonetic = " + phonetic);
			String[] columns = new String[]{CharVoiceDbField.readVoc, CharVoiceDbField.spellVoc};
			c = db.query(TABLE, columns, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					buffer = c.getBlob(0);
					if (buffer == null || buffer.length==0) {
						buffer = c.getBlob(1);
					}
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
//			e.printStackTrace();
		} finally {
			if (c != null) c.close();
			if (db != null) db.close();
		}
		
		return buffer;
	}
	
	/** 传入拼读形式的拼音时，要截取出最后一段: sh-ǎi-shǎi => shǎi*/
	private String cutSpell(String spell) {
		if (spell.indexOf(';') != -1) {
			throw new RuntimeException("no support spell: "+spell);
		}
		int pos = spell.lastIndexOf('-');
		if (pos != -1) {
			return spell.substring(pos+1);
		} else {
			return spell;
		}
	}
	
	public boolean hasReadVoice(String phonetic) {
		boolean findVoice = false;
		SQLiteDatabase db = null;
		Cursor c = null;
		try {
			db = getReadableDatabase();
			phonetic = cutSpell(phonetic);
			String[] args = getPossiblePhonetics(phonetic);
			String selection = getSelection(args.length);
			String[] columns = new String[]{CharVoiceDbField.readVoc, CharVoiceDbField.spellVoc};
			c = db.query(TABLE, columns, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					byte [] buffer = c.getBlob(0);
					findVoice = (buffer != null && buffer.length > 0);
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
//			e.printStackTrace();
		} finally {
			if (c != null) c.close();
			if (db != null) db.close();
		}
		return findVoice;
	}
	
	public byte [] getSpellVoiceBuffer(String phonetic) {
		byte [] buffer = null;
		SQLiteDatabase db = null;
		Cursor c = null;
		try {
			db = getReadableDatabase();
			phonetic = cutSpell(phonetic);
			String[] args = getPossiblePhonetics(phonetic);
			String selection = getSelection(args.length);
			String[] columns = new String[]{CharVoiceDbField.readVoc, CharVoiceDbField.spellVoc};
			c = db.query(TABLE, columns, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					buffer = c.getBlob(1);
					if (buffer == null || buffer.length==0) {
						buffer = c.getBlob(0);
					}
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
//			e.printStackTrace();
		} finally {
			if (c != null) c.close();
			if (db != null) db.close();
		}
		
		return buffer;
	}
	
	public boolean hasSpellVoice(String phonetic) {
		boolean findVoice = false;
		SQLiteDatabase db = null;
		Cursor c = null;
		try {
			db = getReadableDatabase();
			phonetic = cutSpell(phonetic);
			String[] args = getPossiblePhonetics(phonetic);
			String selection = getSelection(args.length);
			String[] columns = new String[]{CharVoiceDbField.readVoc, CharVoiceDbField.spellVoc};
			c = db.query(TABLE, columns, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					byte [] buffer = c.getBlob(1);
					findVoice = (buffer != null && buffer.length > 0);
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
//			e.printStackTrace();
		} finally {
			if (c != null) c.close();
			if (db != null) db.close();
		}
		return findVoice;
	}
	
	public boolean hasVoice(String phonetic) {
		boolean findVoice = false;
		SQLiteDatabase db = null;
		Cursor c = null;
		try {
			db = getReadableDatabase();
			phonetic = cutSpell(phonetic);
			String[] args = getPossiblePhonetics(phonetic);
			String selection = getSelection(args.length);
			String[] columns = new String[]{CharVoiceDbField.readVoc, CharVoiceDbField.spellVoc};
			c = db.query(TABLE, columns, selection, args, null, null, null);
			if (c != null) {
				if (c.getCount() > 0 && c.moveToFirst()) {
					byte [] buffer0 = c.getBlob(0);
					byte [] buffer1 = c.getBlob(1);
					findVoice = buffer0.length > 0 || buffer1.length > 0;
				}
				c.close();
			}
			db.close();
		} catch (Exception e) {
//			e.printStackTrace();
		} finally {
			if (c != null) c.close();
			if (db != null) db.close();
		}
		return findVoice;
	}
	
	private String [] getPossiblePhonetics(String phonetic) {
		List<String> phonetics = new ArrayList<String>();
		phonetics.add(phonetic);
		if (Pattern.compile(".*[aɑgɡŏ]+.*").matcher(phonetic).find()) {
			handleReplace(phonetic, phonetics, "a", "ɑ");
			handleReplace(phonetic, phonetics, "ɑ", "a");
			handleReplace(phonetic, phonetics, "g", "ɡ");
			handleReplace(phonetic, phonetics, "ɡ", "g");
			handleReplace(phonetic, phonetics, "ŏ", "ǒ");
		}
		//处理轻声
		if (Pattern.compile(".*[aɑoeui]+.*").matcher(phonetic).find()) {
			handleReplace(phonetic, phonetics, "a", "ā");
			handleReplace(phonetic, phonetics, "ɑ", "ā");
			handleReplace(phonetic, phonetics, "o", "ō");
			handleReplace(phonetic, phonetics, "e", "ē");
			handleReplace(phonetic, phonetics, "u", "ū");
			handleReplace(phonetic, phonetics, "i", "ī");
		}
		return phonetics.toArray(new String[0]);
	}
	
	private void handleReplace(String phonetic, List<String> outs, String regex, String replacement) {
		String output = phonetic.replaceAll(regex, replacement);
		if (!outs.contains(output)) {
			outs.add(output);
		}
	}
	
	private String getSelection(int argSize) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0 ; i < argSize; i++) {
			if (i > 0) {
				sb.append(" or ");
			}
			sb.append(CharVoiceDbField.Phonetic).append("=?");
		}
		
		return sb.toString();
	}
	
}
