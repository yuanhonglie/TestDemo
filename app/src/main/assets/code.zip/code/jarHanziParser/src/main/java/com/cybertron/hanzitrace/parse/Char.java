package com.cybertron.hanzitrace.parse;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.cybertron.hanzitrace.parse.newdb.StrokeFlag;

/**
 *  长度(4 byte) + 汉字内码(2 byte) + 年级(1 byte) 
 *  + 部首 + 0x09 + 结构 + 0x09 + 拼音 + 0x09 + 声音地址(4 byte, 0xffffffff表示无声音) 
 *  + 笔画(1 byte) + 每一笔点数(笔画 * 2 byte[每个占2字节]) 
 *  + 每一笔点的坐标信息(每笔点数 * 2 byte[x,y]) + …
 */
public class Char implements Serializable {
	private static final long serialVersionUID = -8528693063674379952L;
	
	public int addr;
	public int order;
	
	/*private*/ int length;
	public char ch;
	public int grade;
	public String radical;
	public String structure;
	public String spell;
	public int spellVoiceAddr;
	public int strokeCount;
	public String bishun;
	
	/*private*/ List<Short> pointCounts;
	
	public int flag = StrokeFlag.OLD;
	
	private List<Stroke> strokes;
	
	public Char() {
		strokes = new ArrayList<Stroke>();
		pointCounts = new ArrayList<Short>();
	}
	
	public void add(Stroke stroke) {
		strokes.add(stroke);
	}
	
	public Stroke get(int index) {
		return strokes.get(index);
	}
	
	public void addPointCount(short pointCount) {
		pointCounts.add(pointCount);
	}
	
	public short getPointCount(int position) {
		return pointCounts.get(position);
	}
	
	public void setPointCounts(List<Short> pointCounts) {
		this.pointCounts = pointCounts;
	}
	
	public List<Stroke> getStrokes() {
		return strokes;
	}
	
	public void setStrokes(List<Stroke> strokes) {
		this.strokes = strokes;
	}
	
	public int getCount() {
		return strokes.size();
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof Char) {
			Char c = (Char) o;
			if (c.ch != ch) {
				return false;
			} else if (!c.spell.equals(spell)) {
				return false;
			} else {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(length); sb.append("|");
		sb.append(ch); sb.append("|");
		sb.append(grade); sb.append("|");
		sb.append(order); sb.append("|");
		sb.append(radical); sb.append("|");
		sb.append(structure); sb.append("|");
		sb.append(spell); sb.append("|");
		if (spellVoiceAddr == -1) {
			sb.append("<no voice>"); sb.append("|");
		} else {
			sb.append(String.format("0x%08x", spellVoiceAddr)); sb.append("|");
		}
		sb.append(strokeCount); sb.append("|");
		sb.append(bishun);
		return sb.toString();
	}
	
	public void patch3_swap_stroke() {
		if (ch == '童') {
			int size = strokes.size();
			Stroke s1 = strokes.get(size-3);
			Stroke s2 = strokes.get(size-2);
			List<CPoint> pionts = s1.points;
			s1.points = s2.points;
			s2.points = pionts;
		}
	}
	
	public void patch4_swap_stroke() {
		if (ch == '密') {
			Stroke s1 = strokes.get(6);
			Stroke s2 = strokes.get(7);
			List<CPoint> pionts = s1.points;
			s1.points = s2.points;
			s2.points = pionts;
		}
	}
	
	public void patch5_swap_stroke() {
		if (ch == '匹') {
			Stroke s1 = strokes.get(1);
			Stroke s2 = strokes.get(2);
			Stroke s3 = strokes.get(3);
			List<CPoint> pionts = s1.points;
			s1.points = s2.points;
			s2.points = s3.points;
			s3.points = pionts;
		}
	}
	
	public void patch6_swap_stroke() {
		if (ch == '片') {
			int size = strokes.size();
			Stroke s1 = strokes.get(size-3);
			Stroke s2 = strokes.get(size-2);
			List<CPoint> pionts = s1.points;
			s1.points = s2.points;
			s2.points = pionts;
		}
	}
	
	public void patch7_swap_stroke() {
		if (ch == '墨') {
			Stroke s1 = strokes.get(5);
			Stroke s2 = strokes.get(6);
			List<CPoint> pionts = s1.points;
			s1.points = s2.points;
			s2.points = pionts;
		}
	}
	
	public Char clone() {
		Char chr = new Char();
		
		chr.addr   = addr;
		chr.order  = order;
		
		chr.length = length;
		chr.ch     = ch;
		chr.grade  = grade;

		chr.radical   = new String(radical);
		chr.structure = new String(structure);
		chr.spell     = new String(spell);
		chr.spellVoiceAddr = spellVoiceAddr;
		chr.strokeCount = strokeCount;
		chr.bishun = new String(bishun);

		chr.pointCounts = new ArrayList<Short>();
		chr.pointCounts.addAll(pointCounts);

		chr.flag = flag;

		chr.strokes = new ArrayList<Stroke>();
		chr.strokes.addAll(strokes);
		
		return chr;
	}
	
	public boolean isMultiSpells() {
		return (spell.indexOf(';') != -1);
	}
	
	public String getFirstSpell() {
		int pos = spell.indexOf(';');
		if (pos != -1) {
			return spell.substring(0, pos);
		} else {
			return spell;
		}
	}
	
	public List<String> getSpells() {
		List<String> spells = new ArrayList<String>();
		if (isMultiSpells()) {
			String[] spls = spell.split(";");
			for (int i=0; i<spls.length; i++) {
				spells.add(spls[i]);
			}
		} else {
			spells.add(spell);
		}
		return spells;
	}
}
