package com.cybertron.hanzitrace.widget;

import android.graphics.Bitmap;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.cybertron.hanzitrace.parse.CPoint;
import com.cybertron.hanzitrace.parse.newdb.NewStroke;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Administrator on 2017/7/26.
 */

public class DemonstrateStrokeTask implements Runnable {
    private static final String TAG = "DemonstrateStrokeTask";
    private final int DOTS_PER_DRAW;
    private final int SLEEP_TIME;
    private int mIndex = 0;
    private float mScale;
    private DemonstrateLayer mDisplay;
    private Bitmap mFloodFill;
    private int mFillColor;
    private Handler mHandler;
    private IDemonstrateStrategy mStrategy;
    private IDemonstrateCallback mListener;
    private CountDownLatch latch;
    private ExecutorService mExecutor = Executors.newCachedThreadPool();
    private WaitingTask mWaitingTask;
    private StrokeAudioTask mStrokeAudioTask;
    private boolean paused;
    private volatile boolean canceled;
    private volatile boolean onCancelInvoked;
    private boolean debugEnabled = false;
    private boolean skipStrokeAudio = false;
    private int DEBUG_BLOCK_SIZE = 0;
    private int[] debugBlockColors;
    private int counter = 0;

    public DemonstrateStrokeTask(int index, Handler handler, IDemonstrateStrategy strategy, IDemonstrateCallback listener) {
        mIndex = index;
        mStrategy = strategy;
        mScale = mStrategy.getScale();
        mDisplay = mStrategy.getDemonstrateLayer();
        mFloodFill = mStrategy.getFloodFillLayer();
        mFillColor = mStrategy.getFillColor();
        DOTS_PER_DRAW = mStrategy.getDotsOneDraw();
        SLEEP_TIME = mStrategy.getDrawIntervals();
        debugEnabled = mStrategy.isDebugEnabled();
        skipStrokeAudio = mStrategy.isSkipAudioMode();
        if (debugEnabled) {
            DEBUG_BLOCK_SIZE = mStrategy.getTestDotsSize();
            debugBlockColors = mStrategy.getDebugBlockColors();
        }
        mHandler = handler;
        mListener = listener;
        mWaitingTask = new WaitingTask();
        mStrokeAudioTask = new StrokeAudioTask();
        latch = new CountDownLatch(skipStrokeAudio ? 1 : 2);
    }

    public void execute() {
        mExecutor.execute(this);
        mExecutor.execute(mWaitingTask);
        if (!skipStrokeAudio) {
            mExecutor.execute(mStrokeAudioTask);
        }
        mExecutor.shutdown();
    }

    public int getIndex() {
        return mIndex;
    }

    @Override
    public void run() {
        onStart(mIndex);
        NewStroke stroke = mStrategy.getStroke(mIndex);
        List<CPoint> points;
        try {
            points = stroke.getStrokeFillPoints(mFloodFill, mStrategy);
        } catch (NewStroke.FloodFillException e) {
            onError(mIndex, e);
            return;
        }
        if (!canceled) {
            drawOutline(stroke);
            try {
                List<CPoint> subList;
                int start = 0, end, color = getFillColor();
                while (start < points.size() && !Thread.interrupted()) {
                    end = start + DOTS_PER_DRAW;
                    end = end > points.size() ? points.size() : end;
                    subList = points.subList(start, end);
                    for (CPoint point : subList) {
                        mDisplay.setPixel(point.x, point.y, color);
                    }
                    start += subList.size();
                    if (SLEEP_TIME > 0) {
                        Thread.sleep(SLEEP_TIME);
                    }
                    onRefresh(mIndex);
                    synchronized (this) {
                        while (paused) {
                            onPause(mIndex);
                            wait();
                            onResume(mIndex);
                        }
                    }
                }
                if (!canceled) {
                    latch.countDown();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.i(TAG, "DemonstrateStrokeTask.run: error = " + e.getMessage());
            }

            if (canceled) {
                onCancel(mIndex);
            }
        }
    }

    public int getFillColor() {
        if (!debugEnabled || debugBlockColors == null || DEBUG_BLOCK_SIZE == 0) {
            return mFillColor;
        }

        counter++;
        int blocks = counter/DEBUG_BLOCK_SIZE;
        int index = blocks % debugBlockColors.length;
        return debugBlockColors[index];
    }

    public boolean isPlaying() {
        return !paused;
    }

    public boolean isPaused() {
        return paused;
    }

    public synchronized void pause() {
        paused = true;
    }

    public synchronized void resume() {
        paused = false;
        notifyAll();
    }

    public void cancel() {
        //由于填充任务与语音任务结束顺序是不确定的，
        // 所以通过onCancelInvoked来辅助判断onCancel是否已经被调用，
        // 避免多次回调onCancel();
        Log.i(TAG, "cancel: strokeIndex = " + mIndex);
        canceled = true;
        if (!skipStrokeAudio) {
            mStrokeAudioTask.stopAudio();
        }
        if (mExecutor != null) {
            mExecutor.shutdownNow();
        }
    }

    private void drawOutline(NewStroke stroke) {
        float scale = mScale;
        if (mScale < NewStroke.MIN_SCALE_FACTOR) {
            scale = NewStroke.MIN_SCALE_FACTOR;
        }
        mDisplay.drawOutline(stroke, mStrategy.getOutlinePaint(), scale);
    }

    /**
     * 笔画语音任务
     */
    class StrokeAudioTask implements Runnable, MediaPlayer.OnCompletionListener {
        private MediaPlayer mPlayer;

        @Override
        public void run() {
            //在P16上随机出现如下错误，这里打个补丁，重试3次；
            //06-29 13:58:13.600: I/CybMediaPlayer(9128): playAudio error2 = setDataSourceFD failed.: status=0x80000000
            int code, count = 0;
            do {
                code = playStrokeAudio();
                count++;
            } while (code == -1 && (count < 3));
        }

        public int playStrokeAudio() {
            try {
                String path = mStrategy.getStrokeVoice(mIndex);
                if (!TextUtils.isEmpty(path)) {
                    mPlayer = new MediaPlayer();
                    mPlayer.reset();
                    mPlayer.setDataSource(mStrategy.getStrokeVoice(mIndex));
                    mPlayer.setOnCompletionListener(this);
                    mPlayer.prepare();
                    mPlayer.start();
                    synchronized (this) {
                        wait();
                    }
                }
                latch.countDown();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (SecurityException e) {
                e.printStackTrace();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
                String msg = e.getMessage();
                //在P16上随机出现如下错误
                //06-29 13:58:13.600: I/CybMediaPlayer(9128): playAudio error2 = setDataSourceFD failed.: status=0x80000000
                if (msg.equals("setDataSourceFD failed.: status=0x80000000")) {
                    return -1;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.i(TAG, "StrokeAudioTask.run: error = " + e.getMessage());
                if(canceled) {
                    onCancel(mIndex);
                }
            }

            return 0;
        }

        public void stopAudio() {
            if (mPlayer != null) {
                try {
                    if (mPlayer.isPlaying()) {
                        mPlayer.stop();
                    }
                    mPlayer.release();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        public void onCompletion(MediaPlayer mp) {
            mp.release();
            synchronized (this) {
                notifyAll();
            }
        }
    }

    /**
     * 等待演示任务与语音任务结束再执行的任务
     */
    class WaitingTask implements Runnable {

        @Override
        public void run() {
            try {
                latch.await();
                onFinish(mIndex);
            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.i(TAG, "WaitingTask.run: error = " + e.getMessage());
                if (canceled) {
                    onCancel(mIndex);
                }
            }
        }
    }

    private void onStart(final int index) {
        if (mHandler != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onStart(index);
                }
            });
        }
    }

    private void onPause(final int index) {
        if (mHandler != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onPause(index);
                }
            });
        }
    }

    private void onResume(final int index) {
        if (mHandler != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onResume(index);
                }
            });
        }
    }

    private void onCancel(final int index) {
        if (!onCancelInvoked) {
            onCancelInvoked = true;
        } else {
            return;
        }

        if (mHandler != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onCancel(index);
                }
            });
        }
    }

    private void onRefresh(final int index) {
        if (mHandler != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onRefresh(index);
                }
            });
        }
    }

    private void onFinish(final int index) {
        if (mHandler != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onFinish(index);
                }
            });
        }
    }

    private void onError(final int index, final Exception e) {
        if (mHandler != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onError(index, e);
                }
            });
        }
    }

    /**
     * 演示监听器
     */
    public interface IDemonstrateCallback {
        /**
         * 开始演示
         *
         * @param index 当前笔画序号
         */
        void onStart(int index);

        /**
         * 暂停演示
         *
         * @param index 当前笔画序号
         */
        void onPause(int index);

        /**
         * 继续演示
         *
         * @param index
         */
        void onResume(int index);

        /**
         * 取消演示
         *
         * @param index 当前笔画序号
         */
        void onCancel(int index);

        /**
         * 刷新演示
         *
         * @param index 当前笔画序号
         */
        void onRefresh(int index);

        /**
         * 演示完成
         *
         * @param index 当前笔画序号
         */
        void onFinish(int index);

        /**
         * 演示错误
         * @param index
         * @param e
         */
        void onError(int index, Exception e);
    }

    public interface IDemonstrateStrategy {

        /**
         * 获取当前笔画
         *
         * @param index
         * @return
         */
        NewStroke getStroke(int index);

        /**
         * 获取填充Bitmap
         *
         * @return
         */
        Bitmap getFloodFillLayer();

        /**
         * 获取演示Bitmap
         *
         * @return
         */
        DemonstrateLayer getDemonstrateLayer();

        /**
         * 获取绘制间隔
         *
         * @return
         */
        int getDrawIntervals();

        /**
         * 获取每次绘制的点阵数
         *
         * @return
         */
        int getDotsOneDraw();

        /**
         * 获取笔画语音
         *
         * @param index 笔画序号
         * @return
         */
        String getStrokeVoice(int index);

        /**
         * 获取演示轮廓的画笔
         *
         * @return
         */
        Paint getOutlinePaint();

        /**
         * 获取缩放系数
         *
         * @return
         */
        float getScale();

        /**
         * 获取填充颜色
         *
         * @return
         */
        int getFillColor();

        /**
         * 调试开关是否打开
         * @return
         */
        boolean isDebugEnabled();


        boolean isSkipAudioMode();

        /**
         * 获取一个块包含多少个点，用于调试书写判断
         * @return
         */
        int getTestDotsSize();

        /**
         * 获取调试块的颜色，为方便调试书写判断，描红演示采用两种颜色进行交替绘制
         * @return
         */
        int[] getDebugBlockColors();
    }
}
