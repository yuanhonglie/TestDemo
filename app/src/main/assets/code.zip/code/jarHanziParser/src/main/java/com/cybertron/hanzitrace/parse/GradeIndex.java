package com.cybertron.hanzitrace.parse;

import java.util.ArrayList;
import java.util.List;

/**
 * 字n索引地址: 相对于字索引库
     数量(4 byte) + 字1索引地址(4 byte) + 字2索引地址(4 byte) + …   
 */
public class GradeIndex {
	
	int count;
	private List<Integer> addrs;
	
	GradeIndex() {
		addrs = new ArrayList<Integer>();
	}
	
	public int size() {
		return addrs.size();
	}
	
	public int get(int index) {
		index = index % addrs.size();
		return addrs.get(index);
	}
	
	public void add(int addr) {
		addrs.add(addr);
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(count);sb.append("|");
		for (int i=0; i<addrs.size(); i++) {
			sb.append(addrs.get(i)); sb.append("|");
		}
		return sb.toString();
	}
}
