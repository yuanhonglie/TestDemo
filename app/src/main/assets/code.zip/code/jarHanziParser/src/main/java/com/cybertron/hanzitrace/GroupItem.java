package com.cybertron.hanzitrace;

import java.io.Serializable;


/**
 * 分组后每个小组的成员itme
 * @author Administrator
 *
 */
public class GroupItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int Grade;		// 年级
	
	private int Group;		// 小组
	
	private int GradeIndex;		// 汉字在整个年级中的下标 
	
	private int GroupIndex;	// 汉字在整个小组中的下标
	
	private String Hanzi;	// 汉字
	
	public GroupItem(int grade,int group,int gradeindex,String ch, int groupindex){
		super();
		this.Grade = grade;
		this.Group = group;		
		this.GradeIndex = gradeindex;
		this.Hanzi = ch;
		this.GroupIndex = groupindex;
	}

	/**
	 * 获取所在的年级
	 * @return
	 */
	public int getGrade() {
		return Grade;
	}

	public void setGrade(int grade) {
		Grade = grade;
	}

	/**
	 * 获取item所在的小组 
	 * @return
	 */
	public int getGroup() {
		return Group;
	}

	public void setGroup(int group) {
		Group = group;
	}

	/**
	 * 获取item在整个年级的
	 * @return
	 */
	public int getGradeIndex() {
		return GradeIndex;
	}

	public void setGradeIndex(int index) {
		GradeIndex = index;
	}

	/**
	 * 获取item的汉字
	 * @return
	 */
	public String getHanzi() {
		return Hanzi;
	}

	public void setHanzi(String hanzi) {
		Hanzi = hanzi;
	}

	/**
	 * 获取Item在小组中的下标
	 * @return
	 */
	public int getGroupIndex() {
		return GroupIndex;
	}

	public void setGroupIndex(int groupIndex) {
		GroupIndex = groupIndex;
	}

	
	
}
