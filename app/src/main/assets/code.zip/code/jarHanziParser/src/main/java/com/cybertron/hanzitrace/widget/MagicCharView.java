package com.cybertron.hanzitrace.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.cybertron.hanzitrace.parse.Char;
import com.cybertron.hanzitrace.parse.R;
import com.cybertron.hanzitrace.parse.newdb.StrokeFlag;

/**
 * 此控件为组合控件，继承自FrameLayout，用于处理新、旧描红数据的兼容问题。
 * 此控件下包含两个自定义控件:ScalableCharView和CharView，分别处理新、旧轮廓数据的描红演示。
 * 在调用{@link #setChar(Char)}时，此控件中会自动判断是哪种描红数据，选择对应的描红控件进行显示，
 * 调用方不用关心是何种轮廓数据。为了使MagicCharView、CharView和ScalableCharView三者的行为保持一致，
 * 这里将所有公共方法封装成ICharView接口，让三个控件去实现这个接口。
 * 这里需要注意是当从CharView切换到ScalableCharView或从ScalableCharView切换到CharView时，
 * 需要确保参数更新到当前描红控件中。
 */
public class MagicCharView extends FrameLayout implements ICharView {

    private ICharView mCharView;
    private CharView simpleCharView;
    private ScalableCharView scalableCharView;

    private CharViewParams mParams = new CharViewParams();

    class CharViewParams {
        StrokeDrawer.Mode mMode = StrokeDrawer.Mode.m1;
        StrokeDrawer.StrokeConfig mConfig = StrokeDrawer.StrokeConfig.demo;
        OnCompleteWritingListener mListener;
        int mColor;
        int mWidth;
        float mScale = 0;
        boolean enableOriginal;
        boolean enableOutline;
        boolean enableDebug;
        boolean skipStrokAudio;
        Bitmap mUserBitmap;
    }


    public MagicCharView(Context context) {
        super(context);
        initView();
    }

    public MagicCharView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public MagicCharView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initView();
    }

    private void initView() {
        View root = View.inflate(getContext(), R.layout.magic_char_view, this);
        simpleCharView = (CharView) root.findViewById(R.id.id_char_view);
        scalableCharView = (ScalableCharView) root.findViewById(R.id.id_scalable_char_view);
        showScalableCharView(false);
    }

    public void showScalableCharView(boolean show) {
        if (show) {
            simpleCharView.setVisibility(View.INVISIBLE);
            simpleCharView.stopAll();
            scalableCharView.setVisibility(View.VISIBLE);
            mCharView = scalableCharView;
        } else {
            simpleCharView.setVisibility(View.VISIBLE);
            scalableCharView.setVisibility(View.INVISIBLE);
            scalableCharView.stopAll();
            mCharView = simpleCharView;
        }
        mCharView.setParams(mParams);
    }

    public boolean isScalableCharView() {
        return mCharView instanceof ScalableCharView;
    }


    @Override
    public void setMode(StrokeDrawer.Mode m) {
        mCharView.setMode(m);
        mParams.mMode = m;
    }

    @Override
    public void setColor(int color) {
        mCharView.setColor(color);
        mParams.mColor = color;
    }

    @Override
    public void setWidth(int width) {
        mCharView.setWidth(width);
        mParams.mWidth = width;
    }

    @Override
    public void setChar(Char c) {
        if (c != null) {
            showScalableCharView(c.flag == StrokeFlag.NEW);
        }
        mCharView.setChar(c);
    }

    @Override
    public Char getChar() {
        return mCharView.getChar();
    }

    @Override
    public void setScale(float scale) {
        mCharView.setScale(scale);
        mParams.mScale = scale;
    }

    @Override
    public void setStrokeConfig(StrokeDrawer.StrokeConfig config) {
        mCharView.setStrokeConfig(config);
        mParams.mConfig = config;
    }

    @Override
    public StrokeDrawer.StrokeConfig getStrokeConfig() {
        return mCharView.getStrokeConfig();
    }

    @Override
    public void setEnableOriginal(boolean b) {
        mCharView.setEnableOriginal(b);
        mParams.enableOriginal = b;
    }

    @Override
    public void setenableOutline(boolean b) {
        mCharView.setenableOutline(b);
        mParams.enableOutline = b;
    }

    @Override
    public void demonstrateOneStroke() {
        mCharView.demonstrateOneStroke();
    }

    @Override
    public void demonstrateAllStrokes() {
        mCharView.demonstrateAllStrokes();
    }

    @Override
    public void pauseDemonstration() {
        mCharView.pauseDemonstration();
    }

    @Override
    public void resumeDemonstration() {
        mCharView.resumeDemonstration();
    }

    @Override
    public void resetDemonstration() {
        mCharView.resetDemonstration();
    }

    @Override
    public void clearDemonstration() {
        mCharView.clearDemonstration();
    }

    @Override
    public boolean isDemoStarted() {
        return mCharView.isDemoStarted();
    }

    @Override
    public boolean isDemoPlaying() {
        return mCharView.isDemoPlaying();
    }

    @Override
    public boolean isDemoPaused() {
        return mCharView.isDemoPaused();
    }

    @Override
    public boolean isPractising() {
        return mCharView.isPractising();
    }

    @Override
    public void practise() {
        mCharView.practise();
    }

    @Override
    public void stopAll() {
        mCharView.stopAll();
    }

    @Override
    public void stopPractise() {
        mCharView.stopPractise();
    }

    @Override
    public boolean isDemonstrationMode() {
        return mCharView.isDemonstrationMode();
    }

    @Override
    public boolean isPractiseMode() {
        return mCharView.isPractiseMode();
    }

    @Override
    public boolean isAdvanceMode() {
        return mCharView.isAdvanceMode();
    }

    @Override
    public Bitmap getUserInputBitmap() {
        return mCharView.getUserInputBitmap();
    }

    @Override
    public void setUsetInputBitmap(Bitmap bitmap) {
        mCharView.setUsetInputBitmap(bitmap);
        mParams.mUserBitmap = bitmap;
    }

    public void setImageBitmap(Bitmap bitmap) {
        ((ImageView)mCharView).setImageBitmap(bitmap);
    }

    @Override
    public void setOnCompleteWritingListener(OnCompleteWritingListener listener) {
        mCharView.setOnCompleteWritingListener(listener);
        mParams.mListener = listener;
    }

    @Override
    public void enableDebug(boolean enable) {
        mCharView.enableDebug(enable);
        mParams.enableDebug = enable;
    }

    @Override
    public void skipDemoAudioMode(boolean skip) {
        mCharView.skipDemoAudioMode(skip);
        mParams.skipStrokAudio = skip;
    }

    @Override
    public void setParams(CharViewParams params) {

    }

    @Override
    public StringBuilder getLogMsg() {
        return mCharView.getLogMsg();
    }

    public interface OnCompleteWritingListener {
        void onStartWriting(ICharView cv);

        /**
         * 用户完成描红书写
         * @param cv ICharView对象
         * @param score 用户的分数；
         * @return 是否重新开始书写，true重新开始，false停留在书写笔迹界面，不重新开始；
         */
        boolean onCompleteWriting(ICharView cv, int score);
        void onCompleteDemonstrating(ICharView cv);
    }
}
