package com.cybertron.hanzitrace.parse;

public class GradeAddr {
	private GradeIndex[] items;
	
	public GradeAddr() {
		items = new GradeIndex[FileHeader.GRADE_COUNT];
		clear();
	}

	public GradeIndex get(int grade) {
		grade = grade % items.length;
		return items[grade];
	}
	
	public void set(int grade, GradeIndex index) {
		grade = grade % items.length;
		items[grade] = index;
	}
	
	private void clear() {
		for (int i=0; i<items.length; i++) {
			items[i] = null;
		}
	}
	
	public void close() {
		clear();
	}
}
