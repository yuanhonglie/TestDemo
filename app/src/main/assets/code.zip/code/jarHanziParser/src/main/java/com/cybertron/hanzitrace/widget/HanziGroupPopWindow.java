package com.cybertron.hanzitrace.widget;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;

import com.cybertron.hanzitrace.parse.Char;
import com.cybertron.hanzitrace.parse.R;

public class HanziGroupPopWindow implements OnItemClickListener{

	private Context mContext;
	
	private HanziListAdapter hanziListAdapter;
	
	private PopupWindow popupWindow;
	
	private View mAnchorView;
	
	private View rootview;
	
	private LinearLayout mHanziListParentView;
	
	private ListView mHanziListView;
	
	public HanziGroupPopWindow(Context context,View anchorview){
		this.mAnchorView = anchorview;
		this.mContext = context;
		
		initWindow();
	}

	private void initWindow() {
		if(popupWindow == null){
			popupWindow = new PopupWindow(mContext);
			LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			rootview = layoutInflater.inflate(R.layout.hanzi_grouplist_float_window, null);
			
			mHanziListParentView = (LinearLayout) rootview.findViewById(R.id.float_hanzi_group_list);
			mHanziListParentView.setBackgroundResource(R.drawable.follow_dialog_bg);
			mHanziListView = (ListView) rootview.findViewById(R.id.polyphone_list);
			mHanziListView.setSelector(R.drawable.hanzi_grouplist_bg_selector);
			mHanziListView.setOnItemClickListener(this);
			popupWindow.setContentView(rootview);
		}
		
		popupWindow.setWidth(WindowManager.LayoutParams.WRAP_CONTENT);
		popupWindow.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
		popupWindow.setBackgroundDrawable(new BitmapDrawable());
		popupWindow.setOutsideTouchable(true);
		popupWindow.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss() {
				
			}
		});
	}
	
	public void show(List<Char> words){
		if(hanziListAdapter == null){
			hanziListAdapter = new HanziListAdapter(); 
			hanziListAdapter.updateListItem(words);
			mHanziListView.setAdapter(hanziListAdapter);
		}
		
		hanziListAdapter.updateListItem(words);
		hanziListAdapter.setSelectPosition(-1);
		hanziListAdapter.setTextColor(true);
		hanziListAdapter.notifyDataSetChanged();
		
		popupWindow.setFocusable(true);
		popupWindow.showAtLocation(mAnchorView, Gravity.CENTER, 0, 0);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		try {
			Char cha = (Char) hanziListAdapter.getItem(position);
			Intent intent = new Intent();
			intent.setAction("cybertron.intent.action.HANZISTUDY");
			intent.putExtra("copyValue", String.valueOf(cha.ch));
			intent.putExtra("valueSpell", cha.spell);
			mContext.startActivity(intent);	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	class HanziListAdapter extends BaseAdapter{

		private List<Char> chars;
		
		private int curSelectPosition;
		
		private boolean resetColor = false;
		
		@Override
		public int getCount() {
			return chars.size();
		}

		public void setTextColor(boolean reset) {
			resetColor = reset;
		}

		public void setSelectPosition(int position) {
			curSelectPosition = position;
		}

		public void updateListItem(List<Char> words) {
			chars = words;
		}

		@Override
		public Object getItem(int position) {
			return chars.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				convertView = LayoutInflater.from(mContext).inflate(R.layout.hanzi_polyphone_list_item, null);
				holder = new ViewHolder();
				holder.groupItem = (TextView) convertView.findViewById(R.id.trans_type_item);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			
			String charpolyphone =chars.get(position).ch +  chars.get(position).spell; 
			
			holder.groupItem.setText(charpolyphone);
			
			if ((curSelectPosition) == position) {
				holder.groupItem.setTextColor(Color.RED);
			} else {
				holder.groupItem.setTextColor(mContext.getResources().getColor(R.color.hanzi_polyphone_list_item_color));
			}
			
			if(resetColor){
				holder.groupItem.setTextColor(Color.WHITE);	
			}
			
			return convertView;
		}
	}
	
	class ViewHolder {
		TextView groupItem;
	}
	
}
