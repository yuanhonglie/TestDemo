package com.cybertron.hanzitrace.parse.newdb;

import java.io.Serializable;

import android.database.Cursor;

public class TinyChar implements Serializable {
	private static final long serialVersionUID = 6837865928329232833L;
	
	private int grade;
	private int order;
	private char ch;
	private String spell;
	private int flag = 1;
	
	public TinyChar(int grade, int order, char ch, String spell) {
		this(grade, order, ch, spell, 1);
	}
	
	public TinyChar(int grade, int order, char ch, String spell, int flag) {
		super();
		this.grade = grade;
		this.order = order;
		this.ch = ch;
		this.spell = spell;
		this.flag = flag;
	}
	
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	
	public char getChar() {
		return ch;
	}
	public void setChar(char ch) {
		this.ch = ch;
	}
	
	public String getSpell() {
		return spell;
	}
	public void setSpell(String spell) {
		this.spell = spell;
	}
	
	public int getFlag() {
		return flag;
	}
	
	public void setFlag(int flag) {
		this.flag = flag;
	}
	
	public static TinyChar valueOf(Cursor c) {
		int grade = c.getInt(c.getColumnIndex(DisplayField.grade));
		int order = c.getInt(c.getColumnIndex(DisplayField.order));
		String chStr = c.getString(c.getColumnIndex(DisplayField.character));
		char ch = chStr.charAt(0);
		String spell = c.getString(c.getColumnIndex(DisplayField.spell));
		
		int flag = StrokeFlag.OLD;
		int idx = c.getColumnIndex(DisplayField.flag);
		if (idx != -1) {
			flag = c.getInt(idx);
		}
		return new TinyChar(grade, order, ch, spell, flag);
	}
	
	@Override
	public String toString() {
		return "["+ch+"]"+grade+"-"+order+"|"+spell;
	}
}
