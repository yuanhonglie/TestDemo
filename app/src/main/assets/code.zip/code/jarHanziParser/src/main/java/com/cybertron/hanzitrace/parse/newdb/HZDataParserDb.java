package com.cybertron.hanzitrace.parse.newdb;

import java.util.ArrayList;
import java.util.List;

import com.cybertron.hanzitrace.character.CharacterVoice;
import com.cybertron.hanzitrace.parse.Char;
import com.cybertron.hanzitrace.parse.HZDataParser;

import android.content.Context;
import android.util.Log;

/*
从新的数据库读取描红信息
下面接口模仿了旧数据接口HZDataParserBin，多音字只返回第一个音
public Char getChar(char ch)
public Char getChar(char ch, String spell)
public List<Char> getChars(char ch)
public Char getChar(int grade, int index)
 * */
public class HZDataParserDb extends HZDataParser {
	private static final String TAG = HZDataParser.class.getSimpleName();

	private NewDBHelper dbHelper;
	
	private static final String DEFAULT_PATH = "/sdcard/NewCharacterStudy.db";
	
	//-------------------
	public HZDataParserDb(Context context, String path, String keyStr) {
		try {
			if (path==null || path.length()<=0) {
				path = DEFAULT_PATH;
			}
			if (path.endsWith(".bin")) {
				path = DEFAULT_PATH;
			}
			dbHelper = new NewDBHelper(context, path);
		} catch (Exception e) {
			e.printStackTrace();
			Log.e(TAG, "汉字学习数据异常!");
		}
	}
	
	public void close() {
		Log.i(TAG, "close()");
		dbHelper.close();
		super.close();
	}
	
	public Char getChar(char ch) {
		 Char chr = dbHelper.getChar(ch);
		 if (chr == null) {
			 Log.e(TAG, "1 [getChar] dbHelper.getChar("+ch+") match failed");
		 	return null;
		 }

		 if (chr.isMultiSpells()) {//多音字只返回第一个音
			 chr.spell = chr.getFirstSpell();
		 }
		 return chr;
	}
	
	/** 
	 根据字和拼音获取Char，有可能没有
	 */
	public Char getChar(char ch, String spell) {
		Char chr = dbHelper.getChar(ch);
		if (chr == null) {
			Log.e(TAG, "2 [getChar] dbHelper.getChar("+ch+") match failed");
			return null;
		}
		
		String allspl = chr.spell;
		if (allspl.indexOf(spell) == -1) {
			Log.e(TAG, "3 [getChar] "+ch+" "+spell+" match failed: "+allspl);
			return null;
		}

		//比如查询【色 sh-ǎi-shǎi】，要从s-è-sè;sh-ǎi-shǎi中把sh-ǎi-shǎi过滤出来
		chr.spell = spell;//这里简单处理，直接赋值spell
		return chr;
	}
	
	/** 
	 获取Char列表，有可能列表中只有一个，或者没有
	 */
	public List<Char> getChars(char ch) {
		List<Char> chars = new ArrayList<Char>();
		Char chr = dbHelper.getChar(ch);
		if (chr == null) {
			Log.e(TAG, "5 [getChar] dbHelper.getChar("+ch+") match failed");
			return null;
		}
		
		//多音字根据拼音生成多个Char
		if (chr.isMultiSpells()) {
			String[] spls = chr.spell.split(";");
			for (int i=0; i<spls.length; i++) {
				String spl = spls[i];
				Char chr2 = chr.clone();
				chr2.spell = spl;
				chars.add(chr2);
			}
		} else {
			chars.add(chr);
		}
		return chars;
	}
	
	public Char getChar(int grade, int index) {
		Char chr = dbHelper.getChar(grade, index);
		if (chr == null) {
			Log.e(TAG, "6 [getChar] grade="+grade+",index="+index+" match failed");
			return null;
		}

		if (chr.isMultiSpells()) {//多音字只返回第一个音
			chr.spell = chr.getFirstSpell();
		}
		return chr;
	}
	
	public int getCount(int grade) {
		return dbHelper.getCount(grade);
	}
	
    /** 
	    获取新数据(flag=2)
	 */
	public List<TinyChar> getNewTinyChars() {
		return dbHelper.getNewTinyChars();
	}

	public Char getChar(TinyChar tc) {
		return dbHelper.getChar(tc);
	}
	
	public boolean hasVoice(Char ch) {
		if (mCharVoice == null) {
			Log.e(TAG, "[hasVoice] mCharVoice is null");
			return false;
		}
		
		if (!mCharVoice.hasVoices(ch.getFirstSpell())) {
			Log.e(TAG, "[hasVoice] ["+ch.ch+","+ch.getFirstSpell()+"] not have voice");
			return false;
		}
		
		return true;
	}
	
	public byte[] getCharVoice(Char ch) {
		byte[] voiceBytes = null;
		try {
			if (mCharVoice == null) {
				Log.e(TAG, "[getCharVoice] mCharVoice is null");
				return null;
			}
			if (!hasVoice(ch)) {
				return null;
			}
			voiceBytes = mCharVoice.getCharSpellVoice(ch.getFirstSpell());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		return voiceBytes;
	}
	
	public List<String> getChars(int grade) {
		List<String> chars = new ArrayList<String>();
		try {
			List<TinyChar> tChars = dbHelper.getTinyChars(grade);
			for (int i=0; i<tChars.size(); i++) {
				TinyChar tc = tChars.get(i);
				chars.add(""+tc.getChar());
			}
//			Log.i(TAG, chars.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return chars;
	}
	
	//====================
	private CharacterVoice mCharVoice;
	
	public void setCharacterVoice(CharacterVoice charVoice) {
		mCharVoice = charVoice;
	}
	
	public String getCharsString(int grade) {
		StringBuffer sb = new StringBuffer();
		try {
			List<TinyChar> tChars = dbHelper.getTinyChars(grade);
			for (TinyChar tc:tChars) {
				sb.append(tc.getChar());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
	
	public byte[] getStrokeVoice(char stroke) {
		return dbHelper.getStrokeVoice(stroke);
	}
}
