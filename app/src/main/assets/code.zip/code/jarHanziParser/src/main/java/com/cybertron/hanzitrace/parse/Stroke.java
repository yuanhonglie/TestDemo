package com.cybertron.hanzitrace.parse;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Stroke implements Serializable {
	private static final long serialVersionUID = -4432375579516555422L;
	
	char bishun;
	List<CPoint> points;

	public Stroke() {
		points = new ArrayList<CPoint>();
	}

	public void add(CPoint point) {
		points.add(point);
	}

	public CPoint get(int index) {
		return points.get(index);
	}
	
	public List<CPoint> getPoints() {
		return points;
	}
	
	public int getCount() {
		return points.size();
	}
	
	public char getBishun() {
		return bishun;
	}
	
	public void setBishun(char ch) {
		bishun = ch;
	}
	
	public void reverse() {
		if (points.size() < 2) {
			return;
		}
		Collections.reverse(points);
	}
	
	@Override
	public String toString() {
		return ""+bishun+"|"+points.toString();
	}
}
