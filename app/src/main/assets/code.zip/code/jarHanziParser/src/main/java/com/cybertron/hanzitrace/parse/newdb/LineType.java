package com.cybertron.hanzitrace.parse.newdb;

public interface LineType {
    int polyline   = 1;//折线--1
    int spline     = 2;//曲线--2
    int line       = 3;//直线--3
}
