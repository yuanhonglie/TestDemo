package com.cybertron.hanzitrace.parse;

import android.graphics.PointF;

/**
 * Created by Administrator on 2017/8/4.
 */

public class CPointF extends PointF {

    public CPointF(float x, float y) {
        super(x, y);
    }

    public CPointF scale(float scale) {
        return new CPointF((int)(x*scale), (int)(y*scale));
    }
}
