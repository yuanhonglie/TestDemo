package com.cybertron.hanzitrace.parse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cybertron.account.util.EndianUtils;
import com.cybertron.account.util.RandomReader;
import com.cybertron.account.util.TimeStat;

public class SearchManager {
	
	public Map<String, List<IndexItem>> map;
	private RandomReader reader;
	private int searchAddr;
	
	public SearchManager(RandomReader reader, int searchAddr) {
		this.reader = reader;
		this.searchAddr = searchAddr;
	}
	
	private int binarySearch(RandomReader reader, int searchAddr, char keyChar)
			throws IOException {
		// to gbk and int type for match
		int key = EndianUtils.le.charToShort(keyChar, Config.charset);

		// get count and start addr
		byte[] buf = new byte[4];
		reader.seek(searchAddr);
		reader.read(buf);
		int count = EndianUtils.le.getInt(buf, 0);
//		System.out.println("count:" + count);
		long startAddr = reader.getFilePointer();

		int low = 0;
		int high = count - 1;
		byte[] itemBuf = new byte[6];

		while (low <= high) {
			int mid = (low + high) >>> 1;
			long addr = startAddr + 6 * mid;
			
			reader.seek(addr);
			reader.read(itemBuf);
			int midVal = EndianUtils.be.getShort(itemBuf, 0);

			int cmp = midVal - key;
			if (cmp < 0)
				low = mid + 1;
			else if (cmp > 0)
				high = mid - 1;
			else
				return mid; // key found
		}
		return -(low + 1); // key not found
	}
	
	private List<IndexItem> binarySearch(char keyChar)
			throws IOException {
		List<IndexItem> items = new ArrayList<IndexItem>();
		
		int index = binarySearch(reader, searchAddr, keyChar);
		if (index < 0) {
			return null;
		}
		
		byte[] itemBuf = new byte[6];
		int startAddr = searchAddr+4;
		int addr = startAddr + 6 * index;
		reader.seek(addr);
		reader.read(itemBuf);
		addr = EndianUtils.le.getInt(itemBuf, 2) + searchAddr;
		
		reader.seek(addr);
		int count = reader.read();
		
		int charSize = (1+2+4);
		int size = count * charSize;
		byte[] charBuf = new byte[size];
		reader.read(charBuf);
		for (int i=0; i<count; i++) {
			int grade = EndianUtils.le.getByte(charBuf,   i*charSize +0);
			int order = EndianUtils.le.getShort(charBuf,  i*charSize +1);
			int charAddr = EndianUtils.le.getInt(charBuf, i*charSize +3);
			items.add(new IndexItem(keyChar, grade, order, charAddr));
		}
		
		return items;
	}
	
	private TimeStat stat = new TimeStat();
	private Cache cache = new Cache();
	
	/*public*/ IndexItem search(char ch) {
		stat.startTime();
		stat.updateTimeMillis("search start...");
		
		IndexItem item = null;

		try {
			item = cache.get(ch);
			if (item == null) {
				List<IndexItem> items = binarySearch(ch);
				if (items != null) {
					item = items.get(0);
					cache.set(items);
				}
			} else {
				//do nothing
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		stat.updateTimeMillis("search end");
		return item;
	}
	
	private class Cache {
		char ch;
		int current;
		List<IndexItem> items;
		
		public Cache() {
			reset();
		}
		
		public IndexItem get(char ch) {
			IndexItem item = null;
			if (items != null) {
				if (this.ch == ch) {
					current = (current+1) % items.size();
					return items.get(current);
				}
			}
			reset();
			return item;
		}
		
		private void reset() {
			ch = 0;
			current = 0;
			items = null;
		}
		
		public void set(List<IndexItem> items) {
			this.items = items;
			this.ch = items.get(0).ch;
			current = 0;
		}
	}
	

	/*public*/ List<IndexItem> searchItems(char ch) {
		stat.startTime();
		stat.updateTimeMillis("searchItems start...");
		
		List<IndexItem> items = null;
		
		try {
			items = binarySearch(ch);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		stat.updateTimeMillis("searchItems end");
		return items;
	}
}
