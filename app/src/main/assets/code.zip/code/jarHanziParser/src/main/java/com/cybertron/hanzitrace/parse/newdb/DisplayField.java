package com.cybertron.hanzitrace.parse.newdb;

public interface DisplayField {
	String _id        = "_id";        //INTEGER primary key autoincrement 自增字段
	String grade      = "grade";      //INT 年级
	String order      = "_order";     //INT 在本年级的排序
	String character  = "character";  //TEXT 字
	String spell      = "spell";      //TEXT 拼音
	String flag       = "flag";       //新旧格式数据标志，1-旧数据，2-新数据
}
