package com.cybertron.hanzitrace.parse;

/** 
文件头（128 byte）	
    0x00	4	HZMH	标识
	0x04	8	V1.0	版本
	0x0c	4	0	文件类型,暂未用
	0x10	4		文件大小, 总文件大小
	0x14	4	0x80	文件头大小
	0x18	20		创建日期
	0x2c	4		暂未用
	0x30	4		暂未用
	0x34	16		暂未用
	0x44	60		预留
	
数据头(96 Byte)
	一年级索引库起始地址
	二年级索引库起始地址  
	三年级索引库起始地址  
	四年级索引库起始地址  
	五年级索引库起始地址  
	六年级索引库起始地址  
	索引库地址  
	声音库地址  
*/
public class FileHeader {
	
	public static final int ADDR = 0;
	/**  文件头（128 byte） */
	public static final int FILE_HEAD_SIZE = 128;
	public static final int DATA_HEAD_SIZE = 96;
	public static final int SIZE = FILE_HEAD_SIZE+DATA_HEAD_SIZE;
	
	/** 标识  */
	String iden;
	
	/** 版本  */
	String version;
	
	/** 文件类型,暂未用  */
	int type;
	
	/** 文件大小, 总文件大小  */
	int fileSize;
	
	/** 文件头大小  */
	int headSize;
	
	/** 创建日期 */
	String createDate;
	
	/** 一至六年级索引库起始地址  */
	static final int GRADE_COUNT = 6;
	private int[] gradeAddr = new int[GRADE_COUNT];
	
	/** 索引库地址   */
	int indexAddr;
	/** 声音库地址   */
	int voiceAddr;
	
	/** 汉字排序库  */
	int searchAddr;
	
	FileHeader() {}
	
	public int getAddr(int grade) {
		grade = grade % gradeAddr.length;
		return gradeAddr[grade];
	}
	
	public void setAddr(int grade, int addr) {
		grade = grade % gradeAddr.length;
		gradeAddr[grade] = addr;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(iden);sb.append("|");
		sb.append(version);sb.append("|");
		sb.append(type);sb.append("|");
		sb.append(fileSize);sb.append("|");
		sb.append(headSize);sb.append("|");
		sb.append(createDate);
		return sb.toString();
	}
	
	//--------------------
	public static final String ID      = "HZMH";
	public static final String VERSION = "V1.2";
	
	public boolean isValid() {
		boolean valid = false;
		if (iden.equals(ID)) {
//			if (version.equals(VERSION)) {
				valid = true;
//			}
		}
		return valid;
	}
}
