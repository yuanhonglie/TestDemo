/* -------------------------------------------------------------------------
 *
 *	$1 Java
 *
 * 	This is a Java port of the $1 Gesture Recognizer by
 *	Jacob O. Wobbrock, Andrew D. Wilson, Yang Li.
 * 
 *	"The $1 Unistroke Recognizer is a 2-D single-stroke recognizer designed for 
 *	rapid prototyping of gesture-based user interfaces."
 *	 
 *	http://depts.washington.edu/aimgroup/proj/dollar/
 *
 *	Copyright (C) 2009, Alex Olwal, www.olwal.com
 *
 *	$1 Java free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	$1 Java is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with $1 Java.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  -------------------------------------------------------------------------
 */

package com.cybertron.dollar;

import java.util.*;

public class Recognizer {
    private static final String TAG = "Recognizer";
    //
    // Recognizer class constants
    //
    int numTemplates = 33;
    public static final int NUM_POINTS = 64;
    public static final double SQUARE_SIZE = 250.0;
    private static final double HALF_DIAGONAL = 0.5 * Math.sqrt(250.0 * 250.0 + 250.0 * 250.0);
    private static final double ANGLE_RANGE = Math.toRadians(10.0);
    private static final double ANGLE_PRECISION = 2.0;
    public static final double PHI = 0.5 * (-1.0 + Math.sqrt(5.0)); // Golden Ratio

    public Point centroid = new Point(0, 0);
    public Rectangle boundingBox = new Rectangle(0, 0, 0, 0);
    int bounds[] = {0, 0, 0, 0};

    List<Template> templates = new ArrayList<>(numTemplates);
    private Map<String, List<Template>> templateMap = new HashMap<>();

    public static final int GESTURES_DEFAULT = 1;
    public static final int GESTURES_SIMPLE = 2;
    public static final int GESTURES_CIRCLES = 3;
    public static final int GESTURES_STROKES = 4;

    public Recognizer() {
        this(GESTURES_STROKES);
    }

    public Recognizer(int gestureSet) {
        switch (gestureSet) {
            case GESTURES_DEFAULT:
                loadTemplatesDefault();
                break;

            case GESTURES_SIMPLE:
                loadTemplatesSimple();
                break;

            case GESTURES_CIRCLES:
                loadTemplatesCircles();
                break;
            case GESTURES_STROKES:
                break;
        }
    }

    void loadTemplatesDefault() {
        templates.add(loadTemplate("triangle", TemplateData.trianglePoints));
        templates.add(loadTemplate("x", TemplateData.xPoints));
        templates.add(loadTemplate("rectangle CCW", TemplateData.rectanglePointsCCW));
        templates.add(loadTemplate("circle CCW", TemplateData.circlePointsCCW));
        templates.add(loadTemplate("check", TemplateData.checkPoints));
        templates.add(loadTemplate("caret CW", TemplateData.caretPointsCW));
        templates.add(loadTemplate("question", TemplateData.questionPoints));
        templates.add(loadTemplate("arrow", TemplateData.arrowPoints));
        templates.add(loadTemplate("leftSquareBracket", TemplateData.leftSquareBracketPoints));
        templates.add(loadTemplate("rightSquareBracket", TemplateData.rightSquareBracketPoints));
        templates.add(loadTemplate("v", TemplateData.vPoints));
        templates.add(loadTemplate("delete", TemplateData.deletePoints));
        templates.add(loadTemplate("leftCurlyBrace", TemplateData.leftCurlyBracePoints));
        templates.add(loadTemplate("rightCurlyBrace", TemplateData.rightCurlyBracePoints));
        templates.add(loadTemplate("star", TemplateData.starPoints));
        templates.add(loadTemplate("pigTail", TemplateData.pigTailPoints));
    }

    void loadTemplatesSimple() {
        templates.add(loadTemplate("circle CCW", TemplateData.circlePointsCCW));
        templates.add(loadTemplate("circle CW", TemplateData.circlePointsCW));
//		templates.add(loadTemplate("rectangle CCW", TemplateData.rectanglePointsCCW));
//		templates.add(loadTemplate("rectangle CW", TemplateData.rectanglePointsCW));
        templates.add(loadTemplate("caret CCW", TemplateData.caretPointsCCW));
        templates.add(loadTemplate("caret CW", TemplateData.caretPointsCW));
//		templates.add(loadTemplate("line left", TemplateData.lineToLeftPoints));
//		templates.add(loadTemplate("line right", TemplateData.lineToRightPoints));
        templates.add(loadTemplate("question", TemplateData.questionPoints));
    }

    void loadTemplatesCircles() {
        templates.add(loadTemplate("circle CCW", TemplateData.circlePointsCCW));
        templates.add(loadTemplate("circle CW", TemplateData.circlePointsCW));
    }

    void loadTemplatesPhoto() {
    }


    void loadTemplatesStrokes() {}


    Template loadTemplate(String name, int[] array) {
        return new Template(name, loadArray(array));
    }

    List<Point> loadArray(int[] array) {
        List<Point> v = new ArrayList<>(array.length / 2);
        for (int i = 0; i < array.length; i += 2) {
            Point p = new Point(array[i], array[i + 1]);
            v.add(p);
        }

        //	System.out.println(v.size() + " " + array.length);

        return v;
    }

    public Result recozgnize(List<Point> points) {
        points = Utils.resample(points, NUM_POINTS);
        points = Utils.rotateToZero(points, centroid, boundingBox);
        points = Utils.scaleToSquare(points, SQUARE_SIZE);
        points = Utils.translateToOrigin(points);

        bounds[0] = (int) boundingBox.x;
        bounds[1] = (int) boundingBox.y;
        bounds[2] = (int) boundingBox.x + (int) boundingBox.width;
        bounds[3] = (int) boundingBox.y + (int) boundingBox.height;

        int t = 0;

        double b = Double.MAX_VALUE;
        for (int i = 0; i < templates.size(); i++) {
            double d = Utils.distanceAtBestAngle(points, templates.get(i), -ANGLE_RANGE, ANGLE_RANGE, ANGLE_PRECISION);
            if (d < b) {
                b = d;
                t = i;
            }
        }
        double score = 1.0 - (b / HALF_DIAGONAL);
        return new Result((templates.get(t)).name, score, t, Utils.lastTheta);
    }

    public Result guestureCompare(String name, List<Point> points) {
        name = splitNameFromBishun(name);
        points = Utils.resample(points, NUM_POINTS);
        points = Utils.rotateToZero(points, centroid, boundingBox);
        points = Utils.scaleToSquare(points, SQUARE_SIZE);
        points = Utils.translateToOrigin(points);

        bounds[0] = (int) boundingBox.x;
        bounds[1] = (int) boundingBox.y;
        bounds[2] = (int) boundingBox.x + (int) boundingBox.width;
        bounds[3] = (int) boundingBox.y + (int) boundingBox.height;

        List<Template> templates = templateMap.get(name);
        int t = 0;
        double b = Double.MAX_VALUE;
        for (int i = 0; i < templates.size(); i++) {
            double d = Utils.distanceAtBestAngle(points, templates.get(i), -ANGLE_RANGE, ANGLE_RANGE, ANGLE_PRECISION);
            if (d < b) {
                b = d;
                t = i;
            }
        }

        double score = 1.0 - (b / HALF_DIAGONAL);
        return new Result((templates.get(t)).name, score, t, Utils.lastTheta);
    }

    public int addTemplate(String name, List<Point> points) {
        name = splitNameFromBishun(name);
        templates.add(new Template(name, points));
        return templates.size();
    }

    public Template getTemplate(String name) {
        name = splitNameFromBishun(name);
        Template template = null;
        for (int i = 0; i < templates.size(); i++) {
            Template temp = templates.get(i);
            if (temp.name.equals(name)) {
                template = temp;
            }
        }
        return template;
    }


    public int addTemplate2Map(String name, List<Point> points) {
        name = splitNameFromBishun(name);
        List<Template> templates = templateMap.get(name);
        if (templates == null) {
            templates = new ArrayList<>();
            templateMap.put(name, templates);
        }
        templates.add(new Template(name, points));
        return templates.size();
    }

    public void deleteTemplateListFromMap(String name) {
        name = splitNameFromBishun(name);
        templateMap.remove(name);
    }

    public List<Template> getTemplateList(String name) {
        name = splitNameFromBishun(name);
        return templateMap.get(name);
    }

    private String splitNameFromBishun(String name) {
        return name.split("-")[0];
    }

    public int deleteUserTemplates() {
        for (int i = templates.size() - numTemplates; i > 0; i--) {
            templates.remove(templates.size() - 1);
        }

        return templates.size();
    }

    public void deleteTemplate(String name) {
        name = splitNameFromBishun(name);
        Iterator<Template> iterator = templates.iterator();
        for (;iterator.hasNext();) {
            Template template = iterator.next();
            if (template.name.equals(name)) {
                iterator.remove();
            }
        }
    }

}
