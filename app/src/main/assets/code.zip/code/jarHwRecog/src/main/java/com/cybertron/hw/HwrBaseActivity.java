package com.cybertron.hw;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.widget.Toast;

import com.sinovoice.hcicloudsdk.api.HciCloudSys;
import com.sinovoice.hcicloudsdk.api.hwr.HciCloudHwr;
import com.sinovoice.hcicloudsdk.common.AuthExpireTime;
import com.sinovoice.hcicloudsdk.common.HciErrorCode;
import com.sinovoice.hcicloudsdk.common.InitParam;
import com.sinovoice.hcicloudsdk.common.Session;
import com.sinovoice.hcicloudsdk.common.hwr.HwrConfig;
import com.sinovoice.hcicloudsdk.common.hwr.HwrInitParam;
import com.sinovoice.hcicloudsdk.common.hwr.HwrRecogResult;
import com.sinovoice.hcicloudsdk.common.hwr.HwrRecogResultItem;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class HwrBaseActivity extends FragmentActivity {
    private static final String TAG = "HwrBaseActivity";
    /**
     * 加载用户信息工具类
     */
    protected LyAccount mAccount;
    private boolean hciInited = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAccount = LyAccount.getInstance();
        if (!mAccount.loadFromIntent(getIntent())) {
            boolean loadResult = mAccount.loadAccountInfo(this);
            if (!loadResult) {
                Log.i(TAG, "加载灵云账号失败！");
                Toast.makeText(this, R.string.handwriting_init_error, Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }

        Log.i(TAG, "onCreate: 加载灵云账号成功");

        // 加载信息,返回InitParam, 获得配置参数的字符串
        InitParam initParam = getInitParam();
        String strConfig = initParam.getStringConfig();

        // 初始化
        int errCode = HciCloudSys.hciInit(strConfig, this);
        if (errCode != HciErrorCode.HCI_ERR_NONE && errCode != HciErrorCode.HCI_ERR_SYS_ALREADY_INIT) {
            String error = HciCloudSys.hciGetErrorInfo(errCode);
            Log.i(TAG, "onCreate: hciInit error: " + error);
            Toast.makeText(this, R.string.handwriting_init_error, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Log.i(TAG, "onCreate: hciInit success");
        hciInited = true;

        // 获取授权/更新授权文件 :
        errCode = checkAuthAndUpdateAuth();
        if (errCode != HciErrorCode.HCI_ERR_NONE) {
            // 由于系统已经初始化成功,在结束前需要调用方法hciRelease()进行系统的反初始化
            String error = HciCloudSys.hciGetErrorInfo(errCode);
            Log.i(TAG, "onCreate: CheckAuthAndUpdateAuth error: " + error);
            Toast.makeText(this, R.string.handwriting_init_error, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
    }

    @Override
    public void finish() {
        if (hciInited) {
            // 释放HciCloudSys，当其他能力全部释放完毕后，才能调用HciCloudSys的释放方法
            HciCloudSys.hciRelease();
        }
        super.finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    /**
     * 加载初始化信息
     *
     * @return 系统初始化参数
     */
    private InitParam getInitParam() {
        String authDirPath = this.getFilesDir().getAbsolutePath();

        // 前置条件：无
        InitParam initparam = new InitParam();
        // 授权文件所在路径，此项必填
        initparam.addParam(InitParam.AuthParam.PARAM_KEY_AUTH_PATH, authDirPath);
        // 灵云云服务的接口地址，此项必填
        initparam.addParam(InitParam.AuthParam.PARAM_KEY_CLOUD_URL, mAccount.getCloudUrl());
        // 开发者Key，此项必填，由捷通华声提供
        initparam.addParam(InitParam.AuthParam.PARAM_KEY_DEVELOPER_KEY, mAccount.getDeveloperKey());
        // 应用Key，此项必填，由捷通华声提供
        initparam.addParam(InitParam.AuthParam.PARAM_KEY_APP_KEY, mAccount.getAppKey());

        // 配置日志参数
        String sdcardState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(sdcardState)) {
            String sdPath = Environment.getExternalStorageDirectory()
                    .getAbsolutePath();
            String packageName = this.getPackageName();

            String logPath = sdPath + File.separator + "sinovoice"
                    + File.separator + packageName + File.separator + "log"
                    + File.separator;

            // 日志文件地址
            File fileDir = new File(logPath);
            if (!fileDir.exists()) {
                fileDir.mkdirs();
            }

            // 日志的路径，可选，如果不传或者为空则不生成日志
            initparam.addParam(InitParam.LogParam.PARAM_KEY_LOG_FILE_PATH, logPath);
        }

        return initparam;
    }

    /**
     * 获取授权
     *
     * @return true 成功
     */
    private int checkAuthAndUpdateAuth() {
        // 获取系统授权到期时间
        int initResult;
        AuthExpireTime objExpireTime = new AuthExpireTime();
        initResult = HciCloudSys.hciGetAuthExpireTime(objExpireTime);
        if (initResult == HciErrorCode.HCI_ERR_NONE) {
            // 显示授权日期,如用户不需要关注该值,此处代码可忽略
            Date date = new Date(objExpireTime.getExpireTime() * 1000);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd",
                    Locale.CHINA);
            Log.i(TAG, "expire time: " + sdf.format(date));

            if (objExpireTime.getExpireTime() * 1000 > System
                    .currentTimeMillis()) {
                // 已经成功获取了授权,并且距离授权到期有充足的时间(>7天)
                Log.i(TAG, "checkAuth success");
                return initResult;
            }
        }

        // 获取过期时间失败或者已经过期
        initResult = HciCloudSys.hciCheckAuth();
        if (initResult == HciErrorCode.HCI_ERR_NONE) {
            Log.i(TAG, "checkAuth success");
        } else {
            Log.e(TAG, "checkAuth failed: " + initResult);
        }

        return initResult;
    }

    /**
     * 显示结果集合
     *
     * @param recogResult
     */
    protected String showRecogResultResult(HwrRecogResult recogResult) {
        StringBuilder sb = new StringBuilder();
        if (recogResult != null) {
            ArrayList<HwrRecogResultItem> recogItemList = recogResult
                    .getResultItemList();
            for (int index = 0; index < recogItemList.size() && index < 2; index++) {
                if (index != 0) {
                    sb.append(",");
                }
                String strTmp = recogItemList.get(index).getResult();
                //strResult = strResult.concat(strTmp).concat(";");
                //sb.append(index+1).append(".").append(strTmp);
                sb.append(strTmp);
            }
        }
        //showMessage(sb.toString());
        return sb.toString();
    }

    /**
     * 开始识别，此方法为非实时识别
     *
     * @param capkey
     * @param recogConfig
     * @param strokes
     */
    protected String recognize(String capkey, HwrConfig recogConfig, short[] strokes) {
        String recogText = "";
        int errCode = -1;
        HwrConfig sessionConfig = new HwrConfig();
        sessionConfig.addParam(HwrConfig.SessionConfig.PARAM_KEY_CAP_KEY, capkey);
        sessionConfig.addParam(HwrConfig.SessionConfig.PARAM_KEY_RES_PREFIX, "en_");

        Session session = new Session();
        showMessage("HciCloudHwr hciHwrSessionStart config " + sessionConfig.getStringConfig());
        // 开始会话
        errCode = HciCloudHwr.hciHwrSessionStart(sessionConfig.getStringConfig(), session);
        if (HciErrorCode.HCI_ERR_NONE != errCode) {
            showMessage("hciHwrSessionStart error:" + HciCloudSys.hciGetErrorInfo(errCode));
            return recogText;
        }
        showMessage("hciHwrSessionStart Success");

        HwrRecogResult recogResult = new HwrRecogResult();
        errCode = HciCloudHwr.hciHwrRecog(session, strokes, recogConfig.getStringConfig(),
                recogResult);
        if (HciErrorCode.HCI_ERR_NONE == errCode) {
            showMessage("hciHwrRecog Success");
            recogText = showRecogResultResult(recogResult);
        } else {
            showMessage("hciHwrRecog error:" + HciCloudSys.hciGetErrorInfo(errCode));
        }

        // 停止会话
        HciCloudHwr.hciHwrSessionStop(session);
        showMessage(")hciHwrSessionStop");
        return recogText;
    }

    public String recognize(short[] sShortData) {
        // HWR 初始化
        HwrInitParam hwrInitParam = new HwrInitParam();
        // 获取App应用中的lib的路径,使用lib下的资源文件,需要添加android_so的标记
        String hwrDirPath = getFilesDir().getAbsolutePath()
                .replace("files", "lib");
        hwrInitParam.addParam(HwrInitParam.PARAM_KEY_DATA_PATH, hwrDirPath);
        hwrInitParam.addParam(HwrInitParam.PARAM_KEY_FILE_FLAG, HwrInitParam.VALUE_OF_PARAM_FILE_FLAG_ANDROID_SO);
        hwrInitParam.addParam(HwrInitParam.PARAM_KEY_INIT_CAP_KEYS, mAccount.getCapKey());
        int errCode = HciCloudHwr.hciHwrInit(hwrInitParam.getStringConfig());
        if (errCode != HciErrorCode.HCI_ERR_NONE) {
            showMessage("hciHwrInit error:" + HciCloudSys.hciGetErrorInfo(errCode));
            return "";
        } else {
            showMessage("hciHwrInit Success");
        }

        /*
        short sShortData[] = {103, 283, 105, 283, 107, 283, 113, 283,
                120, 283, 129, 283, 138, 283, 146, 283, 156, 283, 162, 283, 165,
                283, 166, 283, -1, 0, 282, 245, 277, 247, 270, 251, 266, 255, 263,
                257, 259, 261, 254, 266, 250, 273, 246, 281, 243, 286, 240, 292,
                240, 294, 239, 296, 238, 297, 238, 298, -1, 0, 262, 271, 264, 272,
                266, 272, 268, 272, 270, 273, 272, 274, 275, 274, 278, 276, 280,
                278, 283, 279, 286, 281, 289, 282, 289, 283, 291, 284, 292, 285,
                292, 286, -1, 0, 268, 281, 268, 282, 268, 284, 270, 287, 270, 290,
                270, 294, 270, 297, 270, 299, 270, 301, 270, 303, 270, 304, 270,
                306, 270, 308, 269, 309, 269, 310, 269, 311, 269, 312, 269, 314,
                269, 316, 269, 318, 269, 319, 269, 321, 269, 322, 269, 323, 269,
                324, 268, 324, -1, 0, 382, 255, 382, 256, 382, 260, 382, 263, 381,
                267, 378, 274, 375, 278, 373, 282, 372, 287, 371, 291, 369, 294,
                368, 297, 367, 300, 367, 301, 366, 302, 365, 304, 364, 305, 364,
                306, 363, 308, 362, 308, 362, 309, 361, 310, 361, 311, 360, 311,
                -1, 0, 376, 289, 377, 290, 378, 290, 380, 291, 381, 292, 382, 293,
                384, 294, 385, 294, 387, 297, 388, 298, 390, 299, 393, 300, 394,
                301, 396, 302, 398, 303, 400, 305, 401, 306, 403, 307, 404, 309,
                405, 309, 407, 311, 408, 312, 409, 314, 410, 314, 411, 314, -1, 0,
                -1, -1};
        */

        HwrConfig recogConfig = new HwrConfig();
        String recogResult = recognize(mAccount.getCapKey(), recogConfig, sShortData);
        //HWR反初始化
        HciCloudHwr.hciHwrRelease();
        showMessage("hciHwrRelease");
        return recogResult;
    }

    /**
     * 显示消息
     *
     * @param message
     * @return
     */
    private void showMessage(String message){
        //mView.append(message + "\n");
        //Log.i(TAG, "showMessage: " + message);
    }

}
