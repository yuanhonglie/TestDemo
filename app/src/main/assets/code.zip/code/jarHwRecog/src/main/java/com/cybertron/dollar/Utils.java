/* -------------------------------------------------------------------------
 *
 *	$1 Java
 *
 * 	This is a Java port of the $1 Gesture Recognizer by
 *	Jacob O. Wobbrock, Andrew D. Wilson, Yang Li.
 * 
 *	"The $1 Unistroke Recognizer is a 2-D single-stroke recognizer designed for 
 *	rapid prototyping of gesture-based user interfaces."
 *	 
 *	http://depts.washington.edu/aimgroup/proj/dollar/
 *
 *	Copyright (C) 2009, Alex Olwal, www.olwal.com
 *
 *	$1 Java free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	$1 Java is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with $1 Java.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  -------------------------------------------------------------------------
 */

package com.cybertron.dollar;

//TODO: Most of the code here could be significantly optimized. This was a quick port from the C# version of the library


import java.util.ArrayList;
import java.util.List;

public class Utils {
    private Utils() {
    }

    public static double lastTheta;

    public static List<Point> resample(List<Point> points, int n) {
        double I = pathLength(points) / (n - 1); // interval length
        double D = 0.0;

        List<Point> srcPts = new ArrayList<Point>(points.size());
//        for (int i = 0; i < points.size(); i++)
//            srcPts.add(points.get(i));
        srcPts.addAll(points);

        List<Point> dstPts = new ArrayList<Point>(n);
        dstPts.add(srcPts.get(0));    //assumes that srcPts.size() > 0

        for (int i = 1; i < srcPts.size(); i++) {
            Point pt1 = srcPts.get(i - 1);
            Point pt2 = srcPts.get(i);

            double d = distance(pt1, pt2);
            if ((D + d) >= I) {
                double qx = pt1.x + ((I - D) / d) * (pt2.x - pt1.x);
                double qy = pt1.y + ((I - D) / d) * (pt2.y - pt1.y);
                Point q = new Point(qx, qy);
                dstPts.add(q); // append new point 'q'
                srcPts.add(i, q); // insert 'q' at position i in points s.t. 'q' will be the next i
                D = 0.0;
            } else {
                D += d;
            }
        }
        // somtimes we fall a rounding-error short of adding the last point, so add it if so
        if (dstPts.size() == n - 1) {
            dstPts.add(srcPts.get(srcPts.size() - 1));
        }

        return dstPts;
    }


    public static List<Point> rotateToZero(List<Point> points) {
        return rotateToZero(points, null, null);
    }


    public static List<Point> rotateToZero(List<Point> points, Point centroid, Rectangle boundingBox) {
        /*
        Point c = centroid(points);
        Point first = points.get(0);
        double theta = Trigonometric.atan2(c.y - first.y, c.x - first.x);

        if (centroid != null)
            centroid.copy(c);

        if (boundingBox != null)
            boundingBox(points, boundingBox);

        lastTheta = theta;

        return rotateBy(points, -theta);
        */
        return points;
    }

    public static List<Point> rotateBy(List<Point> points, double theta) {
        return rotateByRadians(points, theta);
    }

    // rotate the points by the given radians about their centroid
    public static List<Point> rotateByRadians(List<Point> points, double radians) {
        List<Point> newPoints = new ArrayList<Point>(points.size());
        Point c = centroid(points);

        double _cos = Math.cos(radians);
        double _sin = Math.sin(radians);

        double cx = c.x;
        double cy = c.y;

        for (int i = 0; i < points.size(); i++) {
            Point p = points.get(i);

            double dx = p.x - cx;
            double dy = p.y - cy;

            newPoints.add(
                    new Point(dx * _cos - dy * _sin + cx,
                            dx * _sin + dy * _cos + cy)
            );
        }
        return newPoints;
    }

    public static List<Point> scaleToSquare(List<Point> points, double size) {
        return scaleToSquare(points, size, null);
    }

    public static List<Point> scaleToSquare(List<Point> points, double size, Rectangle boundingBox) {
        Rectangle rect = boundingBox(points);
        double lw = rect.width > rect.height ? rect.width : rect.height;
        double scale = size / lw;
        List<Point> newpoints = new ArrayList<>(points.size());
        for (int i = 0; i < points.size(); i++) {
            Point p = points.get(i);
            double qx = p.x * scale;
            double qy = p.y * scale;
            newpoints.add(new Point(qx, qy));
        }

        if (boundingBox != null) //this will probably not be used as we are more interested in the pre-rotated bounding box -> see rotateToZero
            boundingBox.copy(rect);

        return newpoints;
    }

    public static List<Point> translateToOrigin(List<Point> points) {
        Point c = centroid(points);
        List<Point> newpoints = new ArrayList<Point>(points.size());
        for (int i = 0; i < points.size(); i++) {
            Point p = points.get(i);
            double qx = p.x - c.x;
            double qy = p.y - c.y;
            newpoints.add(new Point(qx, qy));
        }
        return newpoints;
    }

    public static double distanceAtBestAngle(List<Point> points, Template template, double a, double b, double threshold) {
        double phi = Recognizer.PHI;

        double x1 = phi * a + (1.0 - phi) * b;
        double f1 = distanceAtAngle(points, template, x1);
        double x2 = (1.0 - phi) * a + phi * b;
        double f2 = distanceAtAngle(points, template, x2);

        while (Math.abs(b - a) > threshold) {
            if (f1 < f2) {
                b = x2;
                x2 = x1;
                f2 = f1;
                x1 = phi * a + (1.0 - phi) * b;
                f1 = distanceAtAngle(points, template, x1);
            } else {
                a = x1;
                x1 = x2;
                f1 = f2;
                x2 = (1.0 - phi) * a + phi * b;
                f2 = distanceAtAngle(points, template, x2);
            }
        }
        return Math.min(f1, f2);
    }

    public static double distanceAtAngle(List<Point> points, Template template, double theta) {
        List<Point> newpoints = rotateBy(points, theta);
        return pathDistance(newpoints, template.points);
    }

//	#region Lengths and Rects	

    public static Rectangle boundingBox(List<Point> points) {
        double minX = Double.MAX_VALUE;
        double maxX = Double.MIN_VALUE;
        double minY = Double.MAX_VALUE;
        double maxY = Double.MIN_VALUE;

		for (Point p : points) {
            if (p.x < minX)
                minX = p.x;
            if (p.x > maxX)
                maxX = p.x;

            if (p.y < minY)
                minY = p.y;
            if (p.y > maxY)
                maxY = p.y;
        }

        return new Rectangle(minX, minY, maxX - minX, maxY - minY);
    }

    public static void boundingBox(List<Point> points, Rectangle dst) {
        double minX = Double.MAX_VALUE;
        double maxX = Double.MIN_VALUE;
        double minY = Double.MAX_VALUE;
        double maxY = Double.MIN_VALUE;


		for (Point p : points) {

            if (p.x < minX)
                minX = p.x;
            if (p.x > maxX)
                maxX = p.x;

            if (p.y < minY)
                minY = p.y;
            if (p.y > maxY)
                maxY = p.y;
        }

        dst.x = minX;
        dst.y = minY;
        dst.width = maxX - minX;
        dst.height = maxY - minY;
    }

    public static double distance(Point p1, Point p2) {
        double dx = p2.x - p1.x;
        double dy = p2.y - p1.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    // compute the centroid of the points given
    public static Point centroid(List<Point> points) {
        double xsum = 0.0;
        double ysum = 0.0;

		for(Point p : points) {
            xsum += p.x;
            ysum += p.y;
        }

        return new Point(xsum / points.size(), ysum / points.size());
    }

    public static double pathLength(List<Point> points) {
        double length = 0;
        for (int i = 1; i < points.size(); i++) {
            //length += distance((Point) points[i - 1], (Point) points[i]);
            length += distance((Point) points.get(i - 1), (Point) points.get(i));
        }
        return length;
    }

    // computes the 'distance' between two point paths by summing their corresponding point distances.
    // assumes that each path has been resampled to the same number of points at the same distance apart.
    public static double pathDistance(List<Point> path1, List<Point> path2) {
        double distance = 0;
        for (int i = 0; i < path1.size(); i++) {
            distance += distance((Point) path1.get(i), (Point) path2.get(i));
        }
        return distance / path1.size();
    }

}
