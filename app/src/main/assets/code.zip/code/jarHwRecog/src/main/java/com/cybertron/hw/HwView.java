package com.cybertron.hw;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.cybertron.dollar.Template;

import java.lang.ref.WeakReference;

/**
 * Created by yhl on 2017/12/8.
 */
public class HwView extends AppCompatImageView {
    private static final String TAG = "HandwritingView";
    private static final boolean DEBUG = false;
    private static final int PEN_UP_DETECT_TIME = 1000;
    private Bitmap bgBitmap;
    /**
     * 用户笔迹画笔
     */
    private Paint mUserPathPaint;
    private Paint mDisplayPaint;

    private Paint mDimMaskPaint;
    /**
     * 用户笔迹path
     */
    private UserStrokePath mUserStrokePath = new UserStrokePath();
    /**
     * 本控件中宽高值
     */
    private int mWidth, mHeight;

    private static final int MSG_RESET_USER_STROKES = 1;

    private boolean enableHandwriting = false;

    private boolean isReview = false;

    /**防止多次触发onFinish回调*/
    private boolean isHwStarted = false;

    private int displayStrokeColor = Color.BLACK;
    private int bgLineColor = Color.BLACK;
    private int bgLineWidth = 8;

    private Handler mHandler = new UiHandler(this);

    public HwView(Context context) {
        this(context, null);
    }

    public HwView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public HwView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr);
    }

    private void init(Context context, AttributeSet attrs, int defStyle) {
        int strokeColor = Color.BLACK;
        int userStroke = 10;
        int displayStroke = 4;
        int dimMaskColor = 0xbfffffff;
        displayStrokeColor = Color.BLACK;

        if (attrs != null) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.HwView, defStyle, 0);
            strokeColor = a.getColor(R.styleable.HwView_hwUserStrokeColor, strokeColor);
            userStroke = a.getDimensionPixelSize(R.styleable.HwView_hwUserStroke, userStroke);
            displayStroke = a.getDimensionPixelSize(R.styleable.HwView_hwDisplayStroke, displayStroke);
            displayStrokeColor = a.getColor(R.styleable.HwView_hwDisplayStrokeColor, displayStrokeColor);
            bgLineColor = a.getColor(R.styleable.HwView_hwBgLineColor, bgLineColor);
            bgLineWidth = a.getDimensionPixelSize(R.styleable.HwView_hwBgLineWidth, bgLineWidth);
            dimMaskColor = a.getColor(R.styleable.HwView_hwDimMaskColor, dimMaskColor);
            a.recycle();
        }

        mUserPathPaint = new Paint();
        mUserPathPaint.setColor(strokeColor);
        mUserPathPaint.setStyle(Paint.Style.STROKE);
        mUserPathPaint.setAntiAlias(true);
        mUserPathPaint.setStrokeWidth(userStroke);
        mUserPathPaint.setStrokeCap(Paint.Cap.ROUND);

        mDisplayPaint = new Paint(mUserPathPaint);
        mDisplayPaint.setStrokeWidth(displayStroke);
        mDisplayPaint.setColor(displayStrokeColor);

        mDimMaskPaint = new Paint();
        mDimMaskPaint.setColor(dimMaskColor);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Drawable drawable = getBackground();
        if (drawable == null) {
            drawBackground(canvas);
            if (!enableHandwriting) {
                canvas.drawRect(0, 0, mWidth, mHeight, mDimMaskPaint);
            }
        }
        if (mUserStrokePath != null) {
            if (enableHandwriting) {
                mUserStrokePath.draw(canvas, mUserPathPaint);
            } else {
                mUserStrokePath.draw(canvas, isReview ? mUserPathPaint : mDisplayPaint, mWidth, mHeight);
            }
        }
    }

    private void drawBackground(Canvas canvas) {
        if (bgBitmap != null && !bgBitmap.isRecycled()) {
            canvas.drawBitmap(bgBitmap, 0, 0, null);
        }
    }

    private Bitmap createBackgroudBitmap(int width, int height) {
        int borderLineWidth = bgLineWidth;
        int innerLineWidth = borderLineWidth / 2;

        int onInterval = borderLineWidth * 2;
        int offInterval = borderLineWidth;

        Paint paint = new Paint();
        paint.setStrokeWidth(borderLineWidth);
        paint.setAntiAlias(true);
        paint.setColor(bgLineColor);
        paint.setStyle(Paint.Style.STROKE);

        Bitmap bitmap = createLayer(width, height);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawRect(0, 0, width, height, paint);

        DashPathEffect pathEffect = new DashPathEffect(new float[] { onInterval, offInterval}, 2);
        paint.setStrokeWidth(innerLineWidth);
        paint.setPathEffect(pathEffect);

        int halfWidth = width/2, halfHeight = height/2;

        Path path = new Path();
        path.moveTo(halfWidth, 0);
        path.lineTo(halfWidth, height);
        path.moveTo(0, halfHeight);
        path.lineTo(width, halfHeight);
        canvas.drawPath(path, paint);

        return bitmap;
    }

    private Bitmap createLayer(int width, int height) {
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_4444);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w != mWidth || h != mHeight) {
            if (mUserStrokePath.getWidth() == 0 && mUserStrokePath.getHeight() == 0) {
                mUserStrokePath.setDimens(w, h);
            }
            mWidth = w;
            mHeight = h;
            recycleBitmap(bgBitmap);
            bgBitmap = createBackgroudBitmap(w, h);
        }
    }

    private void recycleBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            bitmap.recycle();
        }
    }

    public void setUserStrokePath(UserStrokePath userPath) {
        mUserStrokePath = userPath;
        enableHandwriting = isReview;
        invalidate();
    }

    public void setHwData(HwData hwData) {
        isReview = (hwData.getWidth() == mWidth && hwData.getHeight() == mHeight);
        UserStrokePath userStrokePath = new UserStrokePath(hwData);
        setUserStrokePath(userStrokePath);
    }

    public HwData getHwData() {
        return mUserStrokePath.getHwData();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!enableHandwriting) {
            return super.onTouchEvent(event);
        }

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                if (isReview) {
                    resetUserStrokePath();
                }
                touchDown(event);
            }
            break;
            case MotionEvent.ACTION_MOVE: {
                touchMove(event);
            }
            break;
            case MotionEvent.ACTION_UP: {
                touchUp(event);
            }
            break;
            default:
                break;
        }

        return true;
    }

    private void touchDown(MotionEvent event) {
        if (!isHwStarted) {
            isHwStarted = true;
        }
        removeResetMessage();
        mUserStrokePath.moveTo((int)event.getX(), (int)event.getY());
    }

    private void touchMove(MotionEvent event) {
        removeResetMessage();
        mUserStrokePath.lineTo((int)event.getX(), (int)event.getY(), false);
        invalidate();
    }

    private void touchUp(MotionEvent event) {
        removeResetMessage();
        if (isAutoDetectHwEnd()) {
            mHandler.sendEmptyMessageDelayed(MSG_RESET_USER_STROKES, PEN_UP_DETECT_TIME);
        }
    }

    private void removeResetMessage() {
        if (mHandler.hasMessages(MSG_RESET_USER_STROKES)) {
            mHandler.removeMessages(MSG_RESET_USER_STROKES);
        }
    }

    private void resetUserStrokePath() {
        isReview = false;
        mDisplayPaint.setColor(displayStrokeColor);
        if (!mUserStrokePath.isEmpty()) {
            mUserStrokePath.reset();
            invalidate();
        }
    }

    public void setDisplayColor(int color) {
        mDisplayPaint.setColor(color);
        invalidate();
    }

    public void enableHandwriting(boolean enable) {
        enableHandwriting = enable;
        invalidate();
    }

    public HwData handleHwEnd() {
        return handleHwEnd(true);
    }

    /**
     * 处理手写输入结束
     */
    public HwData handleHwEnd(boolean reset) {
        isHwStarted = false;
        mUserStrokePath.strokeEnd();
        HwData hwData = mUserStrokePath.getHwData();
        if (reset) {
            resetUserStrokePath();
        }
        return hwData;
    }

    /**
     * 判断手写是否结束；
     * @return
     */
    public boolean isHwEnd() {
        return !isHwStarted;
    }

    public boolean isEmpty() {
        return mUserStrokePath.isEmpty();
    }

    public void clear() {
        resetUserStrokePath();
    }

    private static class UiHandler extends Handler {
        private final WeakReference<HwView> mReference;

        public UiHandler(HwView hwView) {
            mReference = new WeakReference<>(hwView);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            HwView hwView = mReference.get();
            if (hwView == null) {
                return;
            }

            switch (msg.what) {
                case MSG_RESET_USER_STROKES:
                    if (hwView.isHwStarted) {
                        HwData hwData = hwView.handleHwEnd();
                        if (hwView.isAutoDetectHwEnd()) {
                            hwView.onFinishWriting(hwData);
                        }
                    }
                    break;
                default:
                    break;
            }
        }
    }

    private HwCallback mCallback;
    public void setHwCallback(HwCallback listener) {
        mCallback = listener;
    }

    private void onFinishWriting(HwData stkData) {
        if (mCallback != null) {
            mCallback.onFinishWriting(stkData);
        }
    }

    private boolean isAutoDetectHwEnd() {
        if (mCallback != null) {
            return mCallback.isAutoDetectHwEnd();
        }
        return false;
    }

    public interface HwCallback {
        void onFinishWriting(HwData hwData);
        boolean isAutoDetectHwEnd();
    }


    ///==============

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int widthSize =  MeasureSpec.getSize(widthMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize =  MeasureSpec.getSize(heightMeasureSpec);

        switch (widthMode) {
            case MeasureSpec.AT_MOST:
            case MeasureSpec.EXACTLY:
                widthSize = Math.min(widthSize, heightSize);
                break;
            case MeasureSpec.UNSPECIFIED:
                widthSize = Math.min(widthSize, heightSize);
                break;
            default:
                break;
        }

        setMeasuredDimension(widthSize, widthSize);
    }
}
