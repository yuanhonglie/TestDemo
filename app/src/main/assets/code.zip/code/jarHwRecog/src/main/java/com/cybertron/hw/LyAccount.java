package com.cybertron.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class LyAccount {

    private static LyAccount mInstance;

    private Map<String, String> mAccountMap;

    private LyAccount() {
        mAccountMap = new HashMap<String, String>();
    }

    public static LyAccount getInstance() {
        if (mInstance == null) {
            mInstance = new LyAccount();
        }
        return mInstance;
    }

    public void setCapKey(String capKey) {
        mAccountMap.put("capKey", capKey);
    }

    public void setDeveloperKey(String developerKey) {
        mAccountMap.put("developerKey", developerKey);
    }

    public void setAppKey(String appKey) {
        mAccountMap.put("appKey", appKey);
    }

    public void setCloudUrl(String cloudUrl) {
        mAccountMap.put("cloudUrl", cloudUrl);
    }

    public String getCapKey() {
        return mAccountMap.get("capKey");
    }

    public String getDeveloperKey() {
        return mAccountMap.get("developerKey");
    }

    public String getAppKey() {
        return mAccountMap.get("appKey");
    }

    public String getCloudUrl() {
        return mAccountMap.get("cloudUrl");
    }

    /**
     * 加载用户的注册信息
     *
     * @param context
     */
    public boolean loadAccountInfo(Context context) {
        boolean isSuccess = true;
        try {
            InputStream in = null;
            in = context.getResources().getAssets().open("AccountInfo.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(in, "utf-8");
            BufferedReader br = new BufferedReader(inputStreamReader);
            String temp;
            String[] sInfo;
            temp = br.readLine().trim();
            while (temp != null) {
                if (!temp.startsWith("#")) {
                    sInfo = temp.split("=");
                    if (sInfo.length == 2) {
                        if (sInfo[1] == null || sInfo[1].length() <= 0) {
                            isSuccess = false;
                            Log.e("LyAccount", sInfo[0] + "is null");
                            break;
                        }
                        mAccountMap.put(sInfo[0], sInfo[1]);
                    }
                }
                temp = br.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
            isSuccess = false;
        }

        return isSuccess;
    }


    public boolean loadFromIntent(Intent intent) {
        boolean ret = true;

        if (intent.hasExtra("capKey")) {
            setCapKey(intent.getStringExtra("capKey"));
        } else {
            ret = false;
        }

        if (intent.hasExtra("developerKey")) {
            setDeveloperKey(intent.getStringExtra("developerKey"));
        } else {
            ret = false;
        }

        if (intent.hasExtra("appKey")) {
            setAppKey(intent.getStringExtra("appKey"));
        } else {
            ret = false;
        }

        if (intent.hasExtra("cloudUrl")) {
            setCloudUrl(intent.getStringExtra("cloudUrl"));
        } else {
            ret = false;
        }


        return ret;
    }
}
