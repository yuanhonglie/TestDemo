package com.cybertron.hw;

import android.graphics.Path;

import com.cybertron.dollar.Point;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by yhl on 2017/12/12.
 */
public class HwData {

    private static final int MAX_INPUT_ARRAY_SIZE = 500;
    private int width, height;
    private List<Point> points = new ArrayList<>();
    private List<Integer> stkOffsets;

    public HwData(int w, int h) {
        width = w;
        height = h;
    }

    public HwData() {
        this(0, 0);
    }

    public void setDimens(int w, int h) {
        width = w;
        height = h;
    }

    public void moveTo(int x, int y) {
        if (!points.isEmpty()) {
            addToInputList(-1, 0);
        }

        addToInputList(x, y);
    }

    public void lineTo(int x, int y) {
        addToInputList(x, y);
    }

    public void hwEnd() {
        if (!isHwEnded() && !isEmpty()) {
            addToInputList(-1, 0);
            addToInputList(-1, -1);
        }
    }

    public void clear() {
        points.clear();
    }

    public boolean isEmpty() {
        return points.isEmpty();
    }

    private void addToInputList(int x, int y) {
        if (isControlPoint(x, y) || (points.size() < MAX_INPUT_ARRAY_SIZE)) {
            points.add(new Point(x, y));
        }
    }

    public static boolean isControlPoint(int x, int y) {
        return x == -1;
    }

    private boolean isControlPoint(Point point) {
        return isControlPoint((int) point.x, (int) point.y);
    }

    private boolean isHwEnded() {
        int size = points.size();
        if (size >= 2) {
            return isHwEndPoint(points.get(size - 1));
        }

        return false;
    }

    public static boolean isHwEndPoint(int x, int y) {
        return x == -1 && y == -1;
    }

    public static boolean isHwEndPoint(Point point) {
        return isHwEndPoint((int) point.x, (int) point.y);
    }

    public static boolean isStrokeEndPoint(int x, int y) {
        return x == -1 && y == 0;
    }

    public static boolean isStrokeEndPoint(Point point) {
        return isStrokeEndPoint((int) point.x, (int) point.y);
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setPoints(List<Point> points) {
        this.points = points;
    }

    public List<Point> getPoints() {
        return points;
    }

    public short[] getInputArray() {
        short[] inputArrays = new short[points.size() * 2];
        for (int i = 0; i < points.size(); i++) {
            Point point = points.get(i);
            inputArrays[i * 2] = (short) point.x;
            inputArrays[i * 2 + 1] = (short) point.y;
        }

        return inputArrays;
    }

    public int getStrokeCount() {
        int count = 0;
        stkOffsets = new ArrayList<>();
        stkOffsets.add(0);
        for (int i = 0; i < points.size(); i++) {
            Point point = points.get(i);
            if (isStrokeEndPoint(point)) {
                count++;
                stkOffsets.add(i + 1);
            }
        }

        return count;
    }

    public List<Point> getStroke(int index) {
        List<Point> stkPoints = new ArrayList<>();
        int offset = stkOffsets.get(index);
        for (int i = offset; i < points.size(); i++) {
            Point point = points.get(i);
            if (isStrokeEndPoint(point)) {
                break;
            }
            stkPoints.add(point);
        }
        return stkPoints;
    }

    public Path toPath() {
        Path path = new Path();
        boolean moveTo = true;
        for (Point point : points) {
            if (isControlPoint(point)) {
                moveTo = true;
            } else {
                if (moveTo) {
                    path.moveTo((float) point.x, (float) point.y);
                } else {
                    path.lineTo((float) point.x, (float) point.y);
                }
                moveTo = false;
            }
        }

        return path;
    }

    public List<Point> convertHwData2PointList() {
        short[] inputs = getInputArray();
        int size = inputs.length / 2;
        List<Point> points = new ArrayList<>(inputs.length / 2);

        for (int i = 0; i < size; i++) {
            short x = inputs[i * 2];
            short y = inputs[i * 2 + 1];
            if (isControlPoint(x, y)) {
                continue;
            }
            points.add(new Point(x, y));
        }

        return points;
    }

    public static HwData fromText(String text) {
        HwData hwData = new HwData();
        String[] parts = text.split(",");
        if (parts.length < 2 || parts.length % 2 != 0) {
            return hwData;
        }

        int width = Integer.parseInt(parts[0]);
        int height = Integer.parseInt(parts[1]);
        hwData.setWidth(width);
        hwData.setHeight(height);

        List<Point> points = new ArrayList<>(parts.length / 2);
        for (int i = 2; i < parts.length; i += 2) {
            double x = Double.parseDouble(parts[i]);
            double y = Double.parseDouble(parts[i + 1]);
            Point point = new Point(x, y);
            points.add(point);
        }
        hwData.setPoints(points);

        return hwData;
    }

    public String toText() {
        StringBuilder builder = new StringBuilder(800);
        builder.append(width).append(",").append(height);
        for (Point p : points) {
            builder.append(",").append(p.getX()).append(",").append(p.getY());
        }

        return builder.toString();
    }
}
