package com.cybertron.hw;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.text.TextPaint;

/**
 * Created by yhl on 2017/8/2.
 */
public class UserStrokePath {
    private static final String TAG = "UserStrokePath";
    private static final float TOUCH_TOLERANCE = 5;
    private long id;
    /**
     * 用户书写笔迹，会对笔迹进行平滑处理
     */
    private Path mUserStrokePath;
    private int width, height;
    /**
     * 用户真实书写笔迹
     */
    private int prevX, prevY;
    private int xOffset, yOffset;

    private Paint mTxtPaint;
    private HwData hwData;

    public UserStrokePath() {
        id = System.currentTimeMillis();
        mUserStrokePath = new Path();
        mTxtPaint = new TextPaint();
        mTxtPaint.setAntiAlias(true);
        mTxtPaint.setTextSize(20);
        mTxtPaint.setColor(Color.RED);
        hwData = new HwData();
    }

    public UserStrokePath(HwData hwData) {
        this();
        this.hwData = hwData;
        setDimens(hwData.getWidth(), hwData.getHeight());
        mUserStrokePath = hwData.toPath();
    }

    public void setDimens(int w, int h) {
        width = w;
        height = h;
        hwData.setDimens(w, h);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    /**
     * 获取书写笔迹id
     *
     * @return
     */
    public long getId() {
        return id;
    }

    public void setOffset(int x, int y) {
        xOffset = x;
        yOffset = y;
    }

    /**
     * 设置书写笔迹的起点
     *
     * @param x
     * @param y
     */
    public void moveTo(int x, int y) {
        x -= xOffset;
        y -= yOffset;
        //reset();
        mUserStrokePath.moveTo(x, y);
        prevX = x;
        prevY = y;
        hwData.moveTo(x, y);
    }

    /**
     * 将书写笔迹移动到指定点
     *
     * @param x
     * @param y
     * @param touchUp
     */
    public void lineTo(int x, int y, boolean touchUp) {
        int nx = x - xOffset;
        int ny = y - yOffset;
        int dx = Math.abs(nx - prevX);
        int dy = Math.abs(ny - prevY);

        if (mUserStrokePath.isEmpty()) {
            moveTo(x, y);
        } else {
            if (dx > TOUCH_TOLERANCE || dy > TOUCH_TOLERANCE) {
                mUserStrokePath.quadTo(prevX, prevY, (nx + prevX) / 2, (ny + prevY) / 2);
                prevX = nx;
                prevY = ny;
                hwData.lineTo(nx, ny);
            } else {
                if (touchUp) {
                    mUserStrokePath.lineTo(nx, ny);
                    hwData.lineTo(nx, ny);
                }
            }
        }
    }

    public void strokeEnd() {
        hwData.hwEnd();
    }

    /**
     * 清空书写笔迹
     */
    public void reset() {
        reset(xOffset, yOffset);
    }

    /**
     * 清空书写笔迹
     *
     * @param x 笔迹的起始坐标相对于View的原点x坐标偏移
     * @param y 笔迹的起始坐标相对于View的原点y坐标偏移
     */
    public void reset(int x, int y) {
        mUserStrokePath.reset();
        setOffset(x, y);
        hwData = new HwData(width, height);
    }

    /**
     * 判断书写笔迹是否为空
     *
     * @return
     */
    public boolean isEmpty() {
        return mUserStrokePath.isEmpty();
    }

    /**
     * 绘制书写笔迹
     *
     * @param canvas
     * @param paint
     */
    public void draw(Canvas canvas, Paint paint) {
        if (isEmpty()) {
            return;
        }

        canvas.drawPath(mUserStrokePath, paint);
    }

    public void draw(Bitmap bitmap, Paint paint) {
        if (bitmap != null && !bitmap.isRecycled()) {
            Canvas mCanvas = new Canvas(bitmap);
            draw(mCanvas, paint);
        }
    }

    public void draw(Canvas canvas, Paint paint, int mWidth, int mHeight) {
        if (isEmpty() || width == 0 || height == 0) {
            return;
        }

        float scaleX = (float) mWidth / this.width;
        float scaleY = (float) mHeight / this.height;
        Matrix matrix = new Matrix();
        matrix.setScale(scaleX, scaleY);
        Path dstPath = new Path();
        mUserStrokePath.transform(matrix, dstPath);
        canvas.drawPath(dstPath, paint);
    }

    public HwData getHwData() {
        return hwData;
    }

    public short[] getInputArray() {
        return hwData.getInputArray();
    }

}
